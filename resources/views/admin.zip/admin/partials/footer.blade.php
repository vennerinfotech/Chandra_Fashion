<footer class="bg-dark text-white text-center py-3 mt-auto shadow-sm">
    <div class="container">
        <p class="mb-0">&copy; {{ date('Y') }} Chandra Fashion | All rights reserved.</p>
    </div>
</footer>
