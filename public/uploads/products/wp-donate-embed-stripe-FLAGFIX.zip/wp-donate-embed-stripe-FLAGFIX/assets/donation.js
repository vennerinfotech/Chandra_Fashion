(function(){
  let stripe, card;
  const msg=(t,err=false)=>{const el=document.getElementById('payment-messages'); if(!el) return; el.style.color=err?'#c00':'#0a0'; el.textContent=t||'';};
  const q=s=>document.querySelector(s);
  const val=(arr)=>{for(const s of arr){const el=q(s); if(el&&'value' in el) return el.value;} return '';};
  function initStripe(){
    if(!window.Stripe){msg('Stripe.js failed to load.',true);return;}
    if(!window.WPD_STRIPE_PUBLISHABLE){msg('Stripe publishable key missing.',true);return;}
    stripe=Stripe(window.WPD_STRIPE_PUBLISHABLE);
    const elements=stripe.elements();
    card=elements.create('card');
    const mount=document.getElementById('card-element'); if(mount) card.mount(mount);
  }
  async function submit(e){
    e.preventDefault();
    if(!stripe||!card){msg('Stripe is not initialized.',true);return;}
    const amount=val(['#amount','[name=amount]']);
    const currency=(val(['#currency','[name=currency]'])||'USD').toUpperCase();
    const campaign_id=val(['#campaign_id','[name=campaign_id]']);
    const first_name=val(['#first_name','[name=first_name]']);
    const last_name=val(['#last_name','[name=last_name]']);
    const email=val(['#email','[name=email]']);
    if(!amount){msg('Please enter amount.',true);return;}
    msg('Creating payment…');
    try{
      const intent=await window.apiClient.createSinglePaymentIntent({amount:Number(amount),currency,campaign_id,donor:{first_name,last_name,email}});
      if(!intent||!intent.client_secret){msg('No client_secret from backend.',true);return;}
      const res=await stripe.confirmCardPayment(intent.client_secret,{payment_method:{card,billing_details:{name:((first_name||'')+' '+(last_name||'')).trim()||undefined,email:email||undefined}}});
      if(res.error){msg(res.error.message||'Payment failed.',true);}
      else if(res.paymentIntent&&res.paymentIntent.status==='succeeded'){msg('Payment successful! Thank you.');}
      else {msg('Payment status: '+(res.paymentIntent&&res.paymentIntent.status));}
    }catch(e){msg(e.message||'Error creating payment intent.',true);}
  }
  function boot(){
    initStripe();
    const form=document.getElementById('donation-form')||document.querySelector('form');
    if(form){form.addEventListener('submit',submit);}
  }
  if(document.readyState==='loading'){document.addEventListener('DOMContentLoaded',boot);} else {boot();}
})();