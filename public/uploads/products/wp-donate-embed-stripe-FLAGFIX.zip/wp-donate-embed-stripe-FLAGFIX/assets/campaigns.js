(function(){
  function $(s, r){ return (r||document).querySelector(s); }
  function $all(s, r){ return Array.prototype.slice.call((r||document).querySelectorAll(s)); }
  function ensureSelects(){
    let sels = $all('select#campaign_id, select[name="campaign_id"], select[name*="campaign"], select[id*="campaign"]');
    if (sels.length===0){
      const form = $('#donation-form') || $('form');
      if (form){
        const wrap=document.createElement('div'); wrap.style.margin='12px 0';
        const lab=document.createElement('label'); lab.textContent='Campaign'; lab.style.display='block'; lab.style.marginBottom='6px';
        const sel=document.createElement('select'); sel.id='campaign_id'; sel.name='campaign_id';
        sel.style.minWidth='240px'; sel.style.padding='8px'; sel.style.border='1px solid #ccc'; sel.style.borderRadius='8px';
        wrap.appendChild(lab); wrap.appendChild(sel); form.insertBefore(wrap, form.firstChild);
        sels=[sel];
      }
    }
    return sels;
  }
  function fillSelect(sel, list){
    if (!sel) return;
    sel.innerHTML='';
    const ph=document.createElement('option'); ph.value=''; ph.textContent='Select a campaign'; sel.appendChild(ph);
    (list||[]).forEach(c=>{
      const id=c.id||c._id||c.campaign_id||c.slug||c.uuid||c.value||'';
      const name=c.title||c.name||c.campaign_name||c.label||c.text||('Campaign '+(id||''));
      if(!id||!name) return;
      const opt=document.createElement('option'); opt.value=String(id); opt.textContent=String(name); sel.appendChild(opt);
    });
    sel.dispatchEvent(new Event('change',{bubbles:true}));
  }
  async function fetchCampaigns(){
    if (!window.apiClient) return [];
    try{
      const a=await window.apiClient.getCampaigns(); return a||[];
    }catch(e){ console.error(e); return []; }
  }
  async function run(){
    const list=await fetchCampaigns();
    const selects=ensureSelects();
    selects.forEach(s=>fillSelect(s,list));
  }
  if(document.readyState==='loading'){ document.addEventListener('DOMContentLoaded', run); } else { run(); }
})();