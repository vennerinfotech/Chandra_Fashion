// Form Validation Utilities
class FormValidator {
    constructor() {
        this.rules = {
            required: (value) => value && value.trim().length > 0,
            email: (value) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value),
            phone: (value) => /^\+?[\d\s\-\(\)]+$/.test(value) && value.replace(/\D/g, '').length >= 7,
            minLength: (value, min) => value && value.length >= min,
            maxLength: (value, max) => !value || value.length <= max,
            numeric: (value) => !isNaN(value) && !isNaN(parseFloat(value)),
            positive: (value) => parseFloat(value) > 0,
            postcode: (value) => /^[A-Za-z0-9]{2,4} [A-Za-z0-9]{3}$/.test(value),
            name: (value) => /^[a-zA-Z\s]+$/.test(value) && value.trim().length >= 2
        };
        
        this.messages = {
            required: 'This field is required',
            email: 'Please enter a valid email address',
            phone: 'Please enter a valid phone number',
            minLength: (min) => `Must be at least ${min} characters long`,
            maxLength: (max) => `Must be no more than ${max} characters long`,
            numeric: 'Must be a valid number',
            positive: 'Must be a positive number',
            postcode: 'Please enter a valid UK postcode (e.g., SW1A 1AA)',
            name: 'Name should only contain letters and spaces'
        };
    }
    
    validate(fieldName, value, rules) {
        const errors = [];
        
        for (const rule of rules) {
            const result = this.validateRule(rule, value);
            if (!result.valid) {
                errors.push(result.message);
            }
        }
        
        return {
            isValid: errors.length === 0,
            errors: errors
        };
    }
    
    validateRule(rule, value) {
        if (typeof rule === 'string') {
            // Simple rule name
            const validator = this.rules[rule];
            const message = this.messages[rule];
            
            if (!validator) {
                return { valid: true, message: '' };
            }
            
            return {
                valid: validator(value),
                message: typeof message === 'function' ? message() : message
            };
        } else if (typeof rule === 'object') {
            // Rule with parameters
            const { type, params } = rule;
            const validator = this.rules[type];
            const message = this.messages[type];
            
            if (!validator) {
                return { valid: true, message: '' };
            }
            
            const isValid = validator(value, ...params);
            const errorMessage = typeof message === 'function' ? message(...params) : message;
            
            return {
                valid: isValid,
                message: isValid ? '' : errorMessage
            };
        }
        
        return { valid: true, message: '' };
    }
    
    validateForm(formData, validationRules) {
        const errors = {};
        let isValid = true;
        
        for (const fieldName in validationRules) {
            const fieldRules = validationRules[fieldName];
            const fieldValue = formData[fieldName] || '';
            
            const validation = this.validate(fieldName, fieldValue, fieldRules);
            
            if (!validation.isValid) {
                errors[fieldName] = validation.errors;
                isValid = false;
            }
        }
        
        return {
            isValid: isValid,
            errors: errors
        };
    }
    
    // Specific validation methods
    validateEmail(email) {
        return this.validate('email', email, ['required', 'email']);
    }
    
    validatePhone(phone) {
        return this.validate('phone', phone, ['required', 'phone']);
    }
    
    validateName(name) {
        return this.validate('name', name, ['required', 'name']);
    }
    
    validateAmount(amount) {
        return this.validate('amount', amount, ['required', 'numeric', 'positive']);
    }
    
    validatePostcode(postcode) {
        return this.validate('postcode', postcode, ['required', 'postcode']);
    }
    
    validateRequired(value) {
        return this.validate('required', value, ['required']);
    }
    
    // Gift Aid specific validation
    validateGiftAidForm(formData) {
        const rules = {
            firstName: ['required', 'name'],
            lastName: ['required', 'name'],
            email: ['required', 'email'],
            mobile: ['required', 'phone'],
            title: ['required'],
            country: ['required'],
            addressLine1: ['required'],
            city: ['required'],
            postCode: ['required', 'postcode']
        };
        
        return this.validateForm(formData, rules);
    }
    
    // Personal details validation
    validatePersonalForm(formData, isGiftAid = false) {
        const baseRules = {
            firstName: ['required', 'name'],
            lastName: ['required', 'name'],
            email: ['required', 'email'],
            mobile: ['required', 'phone'],
            title: ['required'],
            country: ['required']
        };
        
        if (isGiftAid) {
            baseRules.addressLine1 = ['required'];
            baseRules.city = ['required'];
            baseRules.postCode = ['required', 'postcode'];
        }
        
        return this.validateForm(formData, baseRules);
    }
    
    // Donation form validation
    validateDonationForm(donationData) {
        const errors = {};
        let isValid = true;
        
        // Validate amount
        if (donationData.amount <= 0) {
            errors.amount = ['Please enter a valid donation amount'];
            isValid = false;
        }
        
        // Validate campaign selection for non-multi donations
        if (donationData.type !== 'multi' && !donationData.selectedCampaignId) {
            errors.campaign = ['Please select a campaign'];
            isValid = false;
        }
        
        // Validate multi donations
        if (donationData.type === 'multi') {
            if (donationData.multiDonations.length === 0) {
                errors.multiDonations = ['Please add at least one campaign to your donation'];
                isValid = false;
            }
            
            if (donationData.multiDonations.length > 5) {
                errors.multiDonations = ['You can add up to 5 campaigns to your donation'];
                isValid = false;
            }
        }
        
        return {
            isValid: isValid,
            errors: errors
        };
    }
    
    // Real-time validation for form fields
    validateField(fieldName, value, rules) {
        const validation = this.validate(fieldName, value, rules);
        return {
            isValid: validation.isValid,
            message: validation.errors[0] || ''
        };
    }
    
    // Sanitize input values
    sanitizeInput(value, type = 'text') {
        if (!value) return '';
        
        switch (type) {
            case 'email':
                return value.trim().toLowerCase();
            case 'phone':
                return value.replace(/[^\d\+\-\s\(\)]/g, '');
            case 'name':
                return value.trim().replace(/[^a-zA-Z\s]/g, '');
            case 'postcode':
                return value.trim().toUpperCase();
            case 'numeric':
                return value.replace(/[^\d\.]/g, '');
            default:
                return value.trim();
        }
    }
    
    // Format validation errors for display
    formatErrors(errors) {
        const formatted = {};
        
        for (const field in errors) {
            if (Array.isArray(errors[field])) {
                formatted[field] = errors[field][0]; // Show first error
            } else {
                formatted[field] = errors[field];
            }
        }
        
        return formatted;
    }
    
    // Check if form has any errors
    hasErrors(errors) {
        return Object.keys(errors).length > 0;
    }
    
    // Get first error message
    getFirstError(errors) {
        const firstField = Object.keys(errors)[0];
        return firstField ? errors[firstField] : '';
    }
    
    // Clear validation errors
    clearErrors(formElement) {
        const errorElements = formElement.querySelectorAll('.error-text, .error-message');
        errorElements.forEach(el => el.remove());
        
        const errorInputs = formElement.querySelectorAll('.error');
        errorInputs.forEach(input => input.classList.remove('error'));
    }
    
    // Show validation error
    showFieldError(fieldElement, message) {
        const formGroup = fieldElement.closest('.form-group');
        if (!formGroup) return;
        
        // Remove existing error
        const existingError = formGroup.querySelector('.error-text');
        if (existingError) {
            existingError.remove();
        }
        
        // Add error class to input
        fieldElement.classList.add('error');
        
        // Create error message
        const errorElement = document.createElement('span');
        errorElement.className = 'error-text';
        errorElement.textContent = message;
        formGroup.appendChild(errorElement);
    }
    
    // Clear field error
    clearFieldError(fieldElement) {
        const formGroup = fieldElement.closest('.form-group');
        if (!formGroup) return;
        
        // Remove error class
        fieldElement.classList.remove('error');
        
        // Remove error message
        const errorElement = formGroup.querySelector('.error-text');
        if (errorElement) {
            errorElement.remove();
        }
    }
}

// Global validator instance
window.formValidator = new FormValidator();

// Helper functions for easy access
window.validateEmail = (email) => window.formValidator.validateEmail(email);
window.validatePhone = (phone) => window.formValidator.validatePhone(phone);
window.validateName = (name) => window.formValidator.validateName(name);
window.validateAmount = (amount) => window.formValidator.validateAmount(amount);
window.validatePostcode = (postcode) => window.formValidator.validatePostcode(postcode);
window.validateRequired = (value) => window.formValidator.validateRequired(value);
window.sanitizeInput = (value, type) => window.formValidator.sanitizeInput(value, type);
