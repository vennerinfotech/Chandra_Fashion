// API Integration
class APIClient {
    constructor() {
        // ✅ backend nu asal URL mukvo
        this.baseURL = "https://backend-wf-donate.tecocraft.us";
        this.apiVersion = ""; // jo /api prefix hoy to "/api" mukvo
        this.timeout = 30000;
    }

    
async request(endpoint, options = {}) {
    const url = this.baseURL.replace(/\/+$/, "") + endpoint;

    const defaultOptions = {
        headers: {
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        }
    };

    const config = {
        ...defaultOptions,
        ...options,
        headers: {
            ...defaultOptions.headers,
            ...(options.headers || {})
        }
    };

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), this.timeout);

    try {
        const response = await fetch(url, { ...config, signal: controller.signal });
        clearTimeout(timeoutId);

        if (response.status === 204) {
            return null; // ✅ khali response
        }

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        return await response.json();
    } catch (error) {
        clearTimeout(timeoutId);
        if (error.name === 'AbortError') {
            throw new Error('Request timeout. Please try again.');
        }
        throw error;
    }
}

    
    // Campaigns API
   async getCampaigns() {
		try {
			const resp = await this.request("/campaigns?search=");
			if (!resp) return []; // ✅ handle null

			if (Array.isArray(resp)) return resp;
			if (resp.data && Array.isArray(resp.data)) return resp.data;
			if (resp.campaigns && Array.isArray(resp.campaigns)) return resp.campaigns;
			return [];
		} catch (error) {
			console.error("Failed to fetch campaigns:", error);
			return [];
		}
	}

    
    async getCampaign(campaignId) {
        try {
            const response = await this.request(`/campaigns/${campaignId}`);
            return response.data;
        } catch (error) {
            console.error('Failed to fetch campaign:', error);
            throw error;
        }
    }
    
    async getCampaignFields(campaignId) {
        try {
            const response = await this.request(`/campaigns/${campaignId}/fields`);
            return response.data || [];
        } catch (error) {
            console.error('Failed to fetch campaign fields:', error);
            return [];
        }
    }
    
    // Currencies API
    async getCurrencies() {
        try {
            const response = await this.request('/currencies');
            return response.data || [];
        } catch (error) {
            console.error('Failed to fetch currencies:', error);
            return [];
        }
    }
    
    async getEnabledCurrencies() {
        try {
            const response = await this.request('/currencies/enabled');
            return response.data || [];
        } catch (error) {
            console.error('Failed to fetch enabled currencies:', error);
            return [];
        }
    }
    
    async getExchangeRates() {
        try {
            const response = await this.request("/donations/currencies");
            return response.data || {};
        } catch (error) {
            console.error('Failed to fetch exchange rates:', error);
            return {};
        }
    }
    
    // Payment API
    async createSinglePaymentIntent(paymentData) {
        try {
            const response = await this.request('/donations/single-payment-intent', {
                method: 'POST',
                body: JSON.stringify(paymentData)
            });
            
            if (!response.success) {
                throw new Error(response.message || 'Failed to create payment intent');
            }
            
            return response.data;
        } catch (error) {
            console.error('Failed to create single payment intent:', error);
            throw error;
        }
    }
    
    async createMultiPaymentIntent(paymentData) {
        try {
            const response = await this.request('/donations/multi-payment-intent', {
                method: 'POST',
                body: JSON.stringify(paymentData)
            });
            
            if (!response.success) {
                throw new Error(response.message || 'Failed to create payment intent');
            }
            
            return response.data;
        } catch (error) {
            console.error('Failed to create multi payment intent:', error);
            throw error;
        }
    }
    
    async createSubscriptionPaymentIntent(paymentData) {
        try {
            const response = await this.request('/donations/subscription-payment-intent', {
                method: 'POST',
                body: JSON.stringify(paymentData)
            });
            
            if (!response.success) {
                throw new Error(response.message || 'Failed to create subscription payment intent');
            }
            
            return response.data;
        } catch (error) {
            console.error('Failed to create subscription payment intent:', error);
            throw error;
        }
    }
    
    async getPaymentDetails(paymentIntentId) {
        try {
            const response = await this.request(`/donations/payment-intent/${paymentIntentId}`);
            return response.data;
        } catch (error) {
            console.error('Failed to fetch payment details:', error);
            throw error;
        }
    }
    
    // User Location API
    async getUserLocation() {
        try {
            const response = await fetch('https://ipwho.is');
            if (!response.ok) {
                throw new Error('Failed to fetch user location');
            }
            const data = await response.json();
            
            // Check if the API response indicates success
            if (data.status === false) {
                throw new Error(data.message || 'Failed to get user location');
            }
            
            return data;
        } catch (error) {
            console.error('Failed to get user location:', error);
            return null;
        }
    }
    
    // Address Verification API
    async verifyAddress(addressData) {
        try {
            const response = await this.request('/address/verify', {
                method: 'POST',
                body: JSON.stringify(addressData)
            });
            
            return response.data;
        } catch (error) {
            console.error('Failed to verify address:', error);
            return { isValid: false, error: error.message };
        }
    }
    
    // Newsletter Subscription API
    async subscribeToNewsletter(email, personalInfo) {
        try {
            const response = await this.request('/newsletter/subscribe', {
                method: 'POST',
                body: JSON.stringify({
                    email,
                    firstName: personalInfo.firstName,
                    lastName: personalInfo.lastName,
                    country: personalInfo.country
                })
            });
            
            return response.success;
        } catch (error) {
            console.error('Failed to subscribe to newsletter:', error);
            return false;
        }
    }
    
    // Analytics API
    async trackEvent(eventName, eventData = {}) {
        try {
            await this.request('/analytics/track', {
                method: 'POST',
                body: JSON.stringify({
                    event: eventName,
                    data: eventData,
                    timestamp: new Date().toISOString(),
                    url: window.location.href,
                    userAgent: navigator.userAgent
                })
            });
        } catch (error) {
            console.error('Failed to track event:', error);
        }
    }
    
    // Error Reporting API
    async reportError(error, context = {}) {
        try {
            await this.request('/errors/report', {
                method: 'POST',
                body: JSON.stringify({
                    message: error.message,
                    stack: error.stack,
                    context: {
                        ...context,
                        url: window.location.href,
                        userAgent: navigator.userAgent,
                        timestamp: new Date().toISOString()
                    }
                })
            });
        } catch (reportError) {
            console.error('Failed to report error:', reportError);
        }
    }
    
    // Utility method to build query string
    buildQueryString(params) {
        const searchParams = new URLSearchParams();
        
        Object.keys(params).forEach(key => {
            if (params[key] !== null && params[key] !== undefined) {
                searchParams.append(key, params[key]);
            }
        });
        
        return searchParams.toString();
    }
    
    // Utility method to handle API errors
    handleApiError(error, context = '') {
        const errorMessage = error.message || 'An unexpected error occurred';
        console.error(`API Error${context ? ` in ${context}` : ''}:`, error);
        
        // Report error to monitoring service
        this.reportError(error, { context });
        
        return {
            success: false,
            message: errorMessage,
            error: error
        };
    }
    
    // Method to check API health
    async checkHealth() {
        try {
            const response = await this.request('/health');
            return response.status === 'ok';
        } catch (error) {
            console.error('API health check failed:', error);
            return false;
        }
    }
}

// Global API client instance
window.apiClient = new APIClient();

// Helper functions for easy access
window.getCampaigns = () => window.apiClient.getCampaigns();
window.getCurrencies = () => window.apiClient.getCurrencies();
window.getExchangeRates = () => window.apiClient.getExchangeRates();
window.getUserLocation = () => window.apiClient.getUserLocation();
window.verifyAddress = (addressData) => window.apiClient.verifyAddress(addressData);
window.trackEvent = (eventName, eventData) => window.apiClient.trackEvent(eventName, eventData);
