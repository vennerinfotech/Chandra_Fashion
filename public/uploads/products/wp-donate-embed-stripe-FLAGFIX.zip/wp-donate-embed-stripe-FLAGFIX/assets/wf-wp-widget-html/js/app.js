// Main Application JavaScript
class DonationWidget {
  constructor() {
    this.currentStep = 1;
    this.donationData = {
      type: "once",
      subscriptionType: "monthly",
      selectedCampaignId: "",
      amount: 20,
      customAmount: 20,
      currency: "GBP",
      coverFees: false,
      multiDonations: [],
      campaignFieldValues: {},
      personalInfo: {
        title: "",
        firstName: "",
        lastName: "",
        email: "",
        mobile: "",
        country: "United Kingdom",
        company: "",
        asOrganisation: false,
        giftAid: false,
        address: {
          line1: "",
          line2: "",
          city: "",
          postCode: "",
        },
      },
      paymentInfo: {},
      isSubscriber: false,
    };

    this.campaigns = [];
    this.currencies = [];
    this.enabledCurrencies = [];
    this.exchangeRates = {};
    this.userLocation = null;
    this.paymentIntentResponse = null;
    this.paymentDetails = null;
    
    // Constants
    this.MINIMUM_DONATION_GBP = 0.5;

    this.init();
  }

  validateMinimumAmount(amount, currency) {
    const convertedCurrency = this.convertCurrency({
      amount: this.MINIMUM_DONATION_GBP,
      rates: this.exchangeRates,
      toCurrency: currency,
    });
    return amount >= convertedCurrency;
  }

  async init() {
    this.showLoading("Loading...");

    try {
      // Check for payment intent URL parameters first
      const urlParams = new URLSearchParams(window.location.search);
      const paymentIntent = urlParams.get("payment_intent");
      const redirectStatus = urlParams.get("redirect_status");
      const paymentIntentClientSecret = urlParams.get("payment_intent_client_secret");

      if (paymentIntent && redirectStatus) {
        // Handle payment completion flow
        await this.handlePaymentCompletion(paymentIntent, redirectStatus);
        return;
      }

      // Load initial data for normal donation flow
//       await this.loadCampaigns();
//       await this.loadEnabledCurrencies();
//       await this.loadExchangeRates();
//       await this.getUserLocation();

try {
  await this.loadCampaigns();
  console.log("Campaigns loaded");
} catch (e) {
  console.error("loadCampaigns failed:", e);
}

try {
  await this.loadEnabledCurrencies();
  console.log("Currencies loaded");
} catch (e) {
  console.error("loadEnabledCurrencies failed:", e);
}

try {
  await this.loadExchangeRates();
  console.log("Exchange rates loaded");
} catch (e) {
  console.error("loadExchangeRates failed:", e);
}

try {
  await this.getUserLocation();
  console.log("User location loaded");
} catch (e) {
  console.error("getUserLocation failed:", e);
}


      // Initialize UI
      this.initializeEventListeners();
      this.updateCurrencySymbol();
      this.populateCampaignSelect();
      this.populateCurrencySelect();
      this.populateCountryCodeSelect();
      this.populateCountrySelect();
      this.updateGiftAidVisibility();
      this.updatePredefinedAmounts();
      
      // Initialize input field with customAmount value
      const customAmountInput = document.getElementById("custom-amount");
      if (customAmountInput) {
        customAmountInput.value = this.donationData.customAmount.toFixed(2);
        console.log("Initialized custom amount input with:", this.donationData.customAmount.toFixed(2));
      }
      
      console.log("Before syncPredefinedAmountSelection - amount:", this.donationData.amount, "customAmount:", this.donationData.customAmount);
      this.syncPredefinedAmountSelection();
      console.log("After syncPredefinedAmountSelection - amount:", this.donationData.amount, "customAmount:", this.donationData.customAmount);
      this.updateFees();
      this.updateDonationSummary();
      
      // Update multi-donation list if there are existing donations
      if (this.donationData.multiDonations.length > 0) {
        this.updateMultiDonationList();
      }

      this.hideLoading();
      this.showStep(1);
    } catch (error) {
      console.error("Failed to initialize:", error);
      this.hideLoading();
//       this.showError("Failed to load donation form. Please refresh the page.");
    }
  }

  showLoading(message = "Loading...") {
    const loadingScreen = document.getElementById("loading-screen");
    const loadingText = document.getElementById("loading-text");
    loadingText.textContent = message;
    loadingScreen.style.display = "flex";
    document.getElementById("app").style.display = "none";
  }

  hideLoading() {
    document.getElementById("loading-screen").style.display = "none";
    document.getElementById("app").style.display = "block";
  }

  showError(message) {
    // Create error overlay
    const errorDiv = document.createElement("div");
    errorDiv.className = "error-overlay";
    errorDiv.innerHTML = `
            <div class="error-content">
                <h2>Error</h2>
                <p>${message}</p>
                <button onclick="location.reload()">Retry</button>
            </div>
        `;
    document.body.appendChild(errorDiv);
  }

  showStep(step) {
    // Hide all steps
    const steps = document.querySelectorAll(".step-container");
    steps.forEach((stepEl) => (stepEl.style.display = "none"));

    // Show current step
    const stepMap = {
      1: "donation-form",
      2: "personal-details-form",
      3: "payment-form",
      4: "payment-confirmation",
    };

    const currentStepEl = document.getElementById(stepMap[step]);
    if (currentStepEl) {
      currentStepEl.style.display = "block";
      this.currentStep = step;
    }

    // Set up event listeners for confirmation page if showing step 4
    if (step === 4) {
      this.setupConfirmationEventListeners();
    }

    // Scroll to top
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  initializeEventListeners() {
    
    try {
      // Donation type buttons
      document.querySelectorAll(".donation-type-btn").forEach((btn) => {
        btn.addEventListener("click", (e) => {
          this.setDonationType(e.target.dataset.type);
        });
      });

    // Quick donation options
    document.querySelectorAll(".quick-option").forEach((option) => {
      option.addEventListener("click", (e) => {
        this.selectQuickCampaign(
          e.target.closest(".quick-option").dataset.campaign
        );
      });
    });
// Campaign selection
document
  .getElementById("campaign-select")
  .addEventListener("change", (e) => {
    this.setSelectedCampaign(e.target.value);
    console.log("Selected Campaign ID:", e.target.value);
    console.log("Current Data Object:", this); // Print all stored data
  });

// Amount buttons
document.addEventListener("click", (e) => {
  if (e.target.classList.contains("amount-btn")) {
    const amount = parseFloat(e.target.dataset.amount);
    if (!isNaN(amount)) {
      this.setAmount(amount);
      console.log("Selected Amount:", amount);
      console.log("Current Data Object:", this); // Print all stored data
    }
  }
});


    // Custom amount input
    document.getElementById("custom-amount").addEventListener("input", (e) => {
      console.log("Custom amount input changed to:", e.target.value);
      this.setCustomAmount(parseFloat(e.target.value) || 0);
    });

    // Add a change event listener to see if the input field is being cleared
    document.getElementById("custom-amount").addEventListener("change", (e) => {
      console.log("Custom amount input change event - value:", e.target.value);
    });

    // Currency selection
    document
      .getElementById("currency-select")
      .addEventListener("change", (e) => {
        this.setCurrency(e.target.value);
      });

    // Cover fees checkbox
    document.getElementById("cover-fees").addEventListener("change", (e) => {
      this.setCoverFees(e.target.checked);
    });

    // Add campaign button
    document
      .getElementById("add-campaign-btn")
      .addEventListener("click", () => {
        this.addCampaign();
      });

    // Donate button
    document.getElementById("donate-btn").addEventListener("click", () => {
      this.proceedToPersonalDetails();
    });

    // Personal details form
    document.getElementById("personal-form").addEventListener("submit", (e) => {
      e.preventDefault();
      this.submitPersonalDetails();
    });

    // Back button
    document.getElementById("back-btn").addEventListener("click", () => {
      this.goBack();
    });

    // Organisation checkbox
    document
      .getElementById("as-organisation")
      .addEventListener("change", (e) => {
        console.log("Organisation checkbox changed to:", e.target.checked);
        this.setAsOrganisation(e.target.checked);
        // Add a small delay to ensure DOM is updated
        setTimeout(() => {
          this.updateGiftAidVisibility();
        }, 10);
      });

    // Gift Aid checkbox
    document.getElementById("gift-aid").addEventListener("change", (e) => {
      this.setGiftAid(e.target.checked);
    });

    // Newsletter subscription
    document
      .getElementById("subscribe-newsletter")
      .addEventListener("change", (e) => {
        this.setNewsletterSubscription(e.target.checked);
      });

    // Country selection change
    document.getElementById("country").addEventListener("change", (e) => {
      // Country selection no longer affects Gift Aid visibility
      // Gift Aid is only shown based on user's actual location
    });

    // Payment form
    document.getElementById("stripe-form").addEventListener("submit", (e) => {
      e.preventDefault();
      this.submitPayment();
    });

    // Payment back button
    document
      .getElementById("payment-back-btn")
      .addEventListener("click", () => {
        this.goBack();
      });

    // Confirmation actions
    const shareBtn = document.getElementById("share-btn");
    console.log("🚀 ~ Share button element:", shareBtn);
    if (shareBtn) {
      shareBtn.addEventListener("click", () => {
        console.log("🚀 ~ Share button clicked!");
        this.showShareModal();
      });
    } else {
      console.error("Share button not found!");
    }

    document.getElementById("home-btn").addEventListener("click", () => {
      this.goHome();
    });

    // Share modal
    document
      .getElementById("close-share-modal")
      .addEventListener("click", () => {
        this.hideShareModal();
      });

    document.querySelectorAll(".social-btn").forEach((btn) => {
      btn.addEventListener("click", (e) => {
        this.shareOnSocial(e.target.dataset.platform);
      });
    });

    // Frequency buttons (for subscriptions)
    document.querySelectorAll(".frequency-btn").forEach((btn) => {
      btn.addEventListener("click", (e) => {
        this.setSubscriptionFrequency(e.target.dataset.frequency);
      });
    });

    // Predefined amount buttons
    document.querySelectorAll(".amount-btn").forEach((btn) => {
      btn.addEventListener("click", (e) => {
        const amount = parseFloat(e.target.getAttribute("data-amount"));
        console.log("Amount button clicked:", {
          buttonText: e.target.textContent,
          dataAmount: e.target.getAttribute("data-amount"),
          parsedAmount: amount,
          currentCurrency: this.donationData.currency,
          userLocation: this.userLocation?.country_code
        });
        this.setAmount(amount);
        this.syncPredefinedAmountSelection();
      });
    });
    
    } catch (error) {
      console.error("Error setting up event listeners:", error);
    }
  }

  setDonationType(type) {
    this.donationData.type = type;

    // Update UI
    document.querySelectorAll(".donation-type-btn").forEach((btn) => {
      btn.classList.remove("active");
    });
    document.querySelector(`[data-type="${type}"]`).classList.add("active");

    // Show/hide relevant sections
    const multiSection = document.getElementById("multi-donation-section");
    const subscriptionSection = document.getElementById(
      "subscription-frequency"
    );
    const addBtn = document.getElementById("add-campaign-btn");
    const multiInfo = document.getElementById("multi-info");

    if (type === "multi") {
      multiSection.style.display = "block";
      addBtn.style.display = "block";
      multiInfo.style.display = "none";
      subscriptionSection.style.display = "none";
      // Hide fees section initially for multi-donations
      const feesSection = document.querySelector(".cover-fees-section");
      if (feesSection) {
        feesSection.style.display = "none";
      }
      this.updateAddCampaignButton();
      this.updateMultiDonationList(); // Hide total initially when no campaigns
    } else if (type === "subscription") {
      multiSection.style.display = "none";
      addBtn.style.display = "none";
      multiInfo.style.display = "none";
      subscriptionSection.style.display = "block";
      // Show fees section for subscription donations
      const feesSection = document.querySelector(".cover-fees-section");
      if (feesSection) {
        feesSection.style.display = "block";
      }
    } else {
      multiSection.style.display = "none";
      addBtn.style.display = "none";
      multiInfo.style.display = "none";
      subscriptionSection.style.display = "none";
      // Show fees section for one-off donations
      const feesSection = document.querySelector(".cover-fees-section");
      if (feesSection) {
        feesSection.style.display = "block";
      }
    }

    this.updateFees();
    this.updateDonationSummary();
  }

  setSubscriptionFrequency(frequency) {
    this.donationData.subscriptionType = frequency;

    // Update UI
    document.querySelectorAll(".frequency-btn").forEach((btn) => {
      btn.classList.remove("active");
    });
    document
      .querySelector(`[data-frequency="${frequency}"]`)
      .classList.add("active");

    this.updateFees();
    this.updateDonationSummary();
  }

  selectQuickCampaign(campaignType) {
    const campaign = this.campaigns.find(
      (c) => c.title.toLowerCase() === campaignType.toLowerCase()
    );

    if (campaign) {
      this.setSelectedCampaign(campaign.campaign_id.toString());
      document.getElementById("campaign-select").value =
        campaign.campaign_id.toString();
      
      // Update quick donation button active state
      this.updateQuickCampaignButtons(campaignType);
    }
  }

  updateQuickCampaignButtons(selectedCampaignType) {
    // Remove active class from all quick donation button icons
    document.querySelectorAll(".quick-option-icon").forEach((icon) => {
      icon.classList.remove("active");
    });

    // Add active class to the selected campaign button icon
    const selectedButton = document.querySelector(`[data-campaign="${selectedCampaignType}"]`);
    if (selectedButton) {
      const icon = selectedButton.querySelector(".quick-option-icon");
      if (icon) {
        icon.classList.add("active");
      }
    }
  }

  setSelectedCampaign(campaignId) {
    this.donationData.selectedCampaignId = campaignId;

    // Load campaign fields if any
    this.loadCampaignFields(campaignId);

    // Check if selected campaign matches any quick donation option
    this.updateQuickCampaignButtonsFromDropdown(campaignId);

    this.updateDonationSummary();
  }

  updateQuickCampaignButtonsFromDropdown(campaignId) {
    // First clear all active states
    this.clearQuickCampaignButtons();

    // Find the selected campaign
    const selectedCampaign = this.campaigns.find(
      (campaign) => campaign.campaign_id.toString() === campaignId.toString()
    );

    if (selectedCampaign) {
      // Check if the selected campaign matches any quick donation option
      const quickCampaignTypes = ['khums', 'sadaqah', 'zakat', 'orphans'];
      
      for (const campaignType of quickCampaignTypes) {
        const campaign = this.campaigns.find(
          (c) => c.title.toLowerCase() === campaignType.toLowerCase()
        );
        
        if (campaign && campaign.campaign_id.toString() === campaignId.toString()) {
          // This is a quick donation campaign, apply active state
          this.updateQuickCampaignButtons(campaignType);
          break;
        }
      }
    }
  }

  clearQuickCampaignButtons() {
    // Remove active class from all quick donation button icons
    document.querySelectorAll(".quick-option-icon").forEach((icon) => {
      icon.classList.remove("active");
    });
  }

  setAmount(amount) {
    console.log("setAmount called with:", amount);
    console.log("Before setting - amount:", this.donationData.amount, "customAmount:", this.donationData.customAmount);
    this.donationData.amount = amount;
    this.donationData.customAmount = amount;
    console.log("After setting - amount:", this.donationData.amount, "customAmount:", this.donationData.customAmount);

    // Update UI
    const customAmountInput = document.getElementById("custom-amount");
    console.log("Custom amount input element:", customAmountInput);
    if (customAmountInput) {
      customAmountInput.value = amount.toFixed(2);
      console.log("Set input value to:", amount.toFixed(2));
    } else {
      console.error("Custom amount input not found!");
    }

    // Sync predefined amount selection
    this.syncPredefinedAmountSelection();
    console.log("After sync - amount:", this.donationData.amount, "customAmount:", this.donationData.customAmount);

    this.updateFees();
    this.updateDonationSummary();
  }

  setCustomAmount(amount) {
    this.donationData.customAmount = amount;
    this.donationData.amount = amount;

    // Sync predefined amount selection
    this.syncPredefinedAmountSelection();

    this.updateFees();
    this.updateDonationSummary();
  }

  setCurrency(currency) {
    console.log("setCurrency called with:", currency, "old currency:", this.donationData.currency);
    const oldCurrency = this.donationData.currency;
    this.donationData.currency = currency;

    // Convert amount if currency changed and we have an amount
    if (
      oldCurrency &&
      oldCurrency !== currency &&
      this.donationData.amount > 0
    ) {
      console.log("Converting amount from", oldCurrency, "to", currency, "amount:", this.donationData.amount);
      const convertedAmount = this.convertCurrency({
        amount: this.donationData.amount,
        rates: this.exchangeRates,
        toCurrency: currency,
        fromCurrency: oldCurrency,
      });

      if (convertedAmount > 0) {
        this.donationData.amount = convertedAmount;
        this.donationData.customAmount = convertedAmount;

        // Update the custom amount input
        const customAmountInput = document.getElementById("custom-amount");
        if (customAmountInput) {
          customAmountInput.value = convertedAmount.toFixed(2);
          console.log("Updated custom amount input to:", convertedAmount.toFixed(2));
        }
      }
    } else {
      console.log("No currency conversion needed");
    }

    // Update predefined amount buttons
    this.updatePredefinedAmounts();
    this.syncPredefinedAmountSelection();

    this.updateCurrencySymbol();
    this.updateExchangeRateInfo();
    this.updateFees();
    this.updateDonationSummary();
    
    // Update multi-donation list if in multi mode
    if (this.donationData.type === "multi") {
      this.updateMultiDonationList();
    }
  }

  setCoverFees(coverFees) {
    this.donationData.coverFees = coverFees;
    
    // Update fees for all existing multi-donation items
    if (this.donationData.type === "multi") {
      this.donationData.multiDonations.forEach(donation => {
        donation.fees = coverFees ? this.calculateFees(donation.amount) : 0;
      });
      // Update the multi-donation list to reflect the changes
      this.updateMultiDonationList();
    }
    
    this.updateFees();
    this.updateDonationSummary();
  }

  setAsOrganisation(asOrganisation) {
    this.donationData.personalInfo.asOrganisation = asOrganisation;

    const orgField = document.getElementById("organisation-field");
    if (asOrganisation) {
      orgField.style.display = "block";
    } else {
      orgField.style.display = "none";
      this.donationData.personalInfo.company = "";
    }

    // Force update Gift Aid visibility
    console.log("setAsOrganisation called with:", asOrganisation);
    this.updateGiftAidVisibility();
  }

  setGiftAid(giftAid) {
    this.donationData.personalInfo.giftAid = giftAid;

    const giftAidFields = document.getElementById("gift-aid-fields");
    if (giftAid) {
      giftAidFields.style.display = "block";
    } else {
      giftAidFields.style.display = "none";
    }
  }

  populateCurrencySelect() {
    const select = document.getElementById("currency-select");
    if (!select) return;

    // Clear existing options
    select.innerHTML = "";

    // Add enabled currencies
    this.enabledCurrencies.forEach((currency) => {
      const option = document.createElement("option");
      option.value = currency.code;
      option.textContent = `${currency.code} - ${currency.name}`;
      select.appendChild(option);
    });

    // Set current currency as selected
    select.value = this.donationData.currency;
  }

// populateCurrencySelect() {
//   const select = document.getElementById("currency-select");
//   if (!select) return;

//   // Clear existing options
//   select.innerHTML = "";

//   // Add enabled currencies
//   this.enabledCurrencies.forEach((currency) => {
//     const option = document.createElement("option");
//     option.value = currency.code;
//     option.textContent = `${currency.code} - ${currency.name}`;
//     select.appendChild(option);
//   });

//   // Set current currency as selected
//   select.value = this.donationData.currency || "";

//   // ✅ Handle .page-section background
//   const pageSection = document.querySelector(".page-section");
//   if (pageSection) {
//     // open dropdown → focus
//     select.addEventListener("focus", () => {
//       pageSection.style.backgroundColor = "rgba(19, 61, 114, 0.3)";
//     });

//     // close dropdown → blur
//     select.addEventListener("blur", () => {
//       pageSection.style.backgroundColor = "";
//     });
//   }
// }






  updateGiftAidVisibility() {
    const giftAidSection = document.getElementById("gift-aid-section");
    const giftAidFields = document.getElementById("gift-aid-fields");
    const asOrganisation = document.getElementById("as-organisation");
    
    if (!giftAidSection || !giftAidFields || !asOrganisation) {
      console.log("Missing elements:", { giftAidSection, giftAidFields, asOrganisation });
      return;
    }

    // Check if user is from UK based on location data only (not country selection)
    const isUKFromLocation = this.userLocation && this.userLocation.country_code === "GB";
    const isOrganisation = asOrganisation.checked;

    console.log("Gift Aid Visibility Check:", {
      userLocation: this.userLocation,
      isUKFromLocation,
      isOrganisation,
      shouldShow: isUKFromLocation && !isOrganisation
    });

    if (isUKFromLocation && !isOrganisation) {
      // Show Gift Aid section for UK individual donors (based on location only)
      console.log("Showing Gift Aid section - UK user, not organisation");
      giftAidSection.style.display = "block";
    } else {
      // Hide Gift Aid section for non-UK users or organisation donors
      console.log("Hiding Gift Aid section - not UK user or organisation donor");
      giftAidSection.style.display = "none";
      giftAidFields.style.display = "none";
      
      // Uncheck Gift Aid checkbox if it was checked
      const giftAidCheckbox = document.getElementById("gift-aid");
      if (giftAidCheckbox) {
        giftAidCheckbox.checked = false;
        this.setGiftAid(false);
      }
    }
  }

  setNewsletterSubscription(subscribe) {
    this.donationData.isSubscriber = subscribe;
  }

  // Test function to manually hide Gift Aid section
  testHideGiftAid() {
    const giftAidSection = document.getElementById("gift-aid-section");
    if (giftAidSection) {
      giftAidSection.style.display = "none";
      console.log("Gift Aid section manually hidden");
    } else {
      console.log("Gift Aid section not found");
    }
  }

  addCampaign() {
    // Check if we've reached the limit of 5 campaigns
    if (this.donationData.multiDonations.length >= 5) {
      this.showError("You can add up to 5 campaigns to your donation");
      return;
    }

    if (!this.donationData.selectedCampaignId) {
      this.showError("Please select a campaign");
      return;
    }

    if (this.donationData.amount <= 0) {
      this.showError("Please enter a valid donation amount");
      return;
    }

    // Validate minimum amount
    if (!this.validateMinimumAmount(this.donationData.amount, this.donationData.currency)) {
      const convertedCurrency = this.convertCurrency({
        amount: this.MINIMUM_DONATION_GBP,
        rates: this.exchangeRates,
        toCurrency: this.donationData.currency,
      });
      const minimumAmountInCurrentCurrency = convertedCurrency ?? 0;
      
      this.showError(
        `Minimum donation amount is ${this.getCurrencySymbol(
          this.donationData.currency
        )}${minimumAmountInCurrentCurrency.toFixed(2)}`
      );
      return;
    }

    const campaign = this.campaigns.find(
      (c) => c.campaign_id.toString() === this.donationData.selectedCampaignId
    );

    if (!campaign) return;

    const donation = {
      campaign: campaign,
      amount: this.donationData.amount,
      fees: this.donationData.coverFees
        ? this.calculateFees(this.donationData.amount)
        : 0,
      fieldValues: { ...this.donationData.campaignFieldValues },
    };

    this.donationData.multiDonations.push(donation);

    // Clear current selection
    this.donationData.selectedCampaignId = "";
    this.donationData.amount = 0;
    this.donationData.customAmount = 0;
    document.getElementById("campaign-select").value = "";
    document.getElementById("custom-amount").value = "";
    document.querySelectorAll(".amount-btn").forEach((btn) => {
      btn.classList.remove("active");
    });

    this.updateMultiDonationList();
    this.updateDonationSummary();
    this.updateAddCampaignButton();
    this.updateFees();
  }

  removeMultiDonation(index) {
    this.donationData.multiDonations.splice(index, 1);
    this.updateMultiDonationList();
    this.updateDonationSummary();
    this.updateAddCampaignButton();
    this.updateFees();
  }

  updateAddCampaignButton() {
    const addBtn = document.getElementById("add-campaign-btn");
    if (!addBtn) return;

    const isDisabled = this.donationData.multiDonations.length >= 5;
    addBtn.disabled = isDisabled;
    
    if (isDisabled) {
      addBtn.textContent = "Maximum 5 campaigns reached";
      addBtn.classList.add("disabled");
    } else {
      addBtn.textContent = "+ Add campaign";
      addBtn.classList.remove("disabled");
    }
  }

  updateMultiDonationList() {
    const list = document.getElementById("multi-donations-list");
    const totalEl = document.getElementById("multi-total-amount");
    const totalSection = document.querySelector(".multi-total");
    const feesSection = document.querySelector(".cover-fees-section");

    list.innerHTML = "";

    // Show/hide total section and fees section based on whether there are campaigns
    if (this.donationData.multiDonations.length === 0) {
      if (totalSection) {
        totalSection.style.display = "none";
      }
      if (feesSection && this.donationData.type === "multi") {
        feesSection.style.display = "none";
      }
      return;
    } else {
      if (totalSection) {
        totalSection.style.display = "block";
      }
      if (feesSection && this.donationData.type === "multi") {
        feesSection.style.display = "block";
      }
    }

    this.donationData.multiDonations.forEach((donation, index) => {
      const item = document.createElement("div");
      item.className = "multi-donation-item";
      
      // Check if campaign has an image, otherwise use fallback
      const imageUrl = donation.campaign.imageUrl || donation.campaign.image_url;
      const imageHtml = imageUrl
        ? `<div class="multi-donation-image-container"> <img src="${imageUrl}" alt="${donation.campaign.title}" class="multi-donation-image" /> </div>`
        : `<div class="multi-donation-image-container multi-donation-no-image-container"> <img src="assets/images/WF_Round.png" alt="WF Logo" class="multi-donation-image" /> </div>`;
      
      item.innerHTML = `
                <div class="multi-donation-content">
                    <div class="multi-donation-image-container">
                        ${imageHtml}
                    </div>
                    <div class="multi-donation-title">${
                      donation.campaign.title
                    }</div>
                    <div class="multi-donation-amount">${this.getCurrencySymbol()}${donation.amount.toFixed(
        2
      )}</div>
                </div>
                <button class="remove-donation-btn" onclick="app.removeMultiDonation(${index})">×</button>
            `;
      list.appendChild(item);
    });

    const total = this.donationData.multiDonations.reduce(
      (sum, d) => sum + d.amount,
      0
    );
    totalEl.textContent = `${this.getCurrencySymbol()}${total.toFixed(2)}`;
  }

  updateFees() {
    const amount =
      this.donationData.type === "multi"
        ? this.donationData.multiDonations.reduce((sum, d) => sum + d.amount, 0)
        : this.donationData.amount;

    const fees = this.calculateFees(amount);
    document.getElementById(
      "fee-amount"
    ).textContent = `${this.getCurrencySymbol()}${fees.toFixed(2)}`;
  }

  calculateFees(amount) {
    return amount * 0.05; // 5% fee like React version
  }

  updateCurrencySymbol() {
    const symbol = this.getCurrencySymbol();
    document.querySelector(".currency-symbol").textContent = symbol;
  }

  getCurrencySymbol(currencyCode = this.donationData.currency) {
    const formatted = new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: currencyCode,
      currencyDisplay: "symbol", // Ensures symbol is used
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(0);

    return formatted.replace(/[\d\s.,]/g, "").trim(); // Remove numbers, spaces, and dots
  }

  updatePredefinedAmounts() {
    const predefinedAmounts = [100, 50, 30, 20, 10, 5]; // Base amounts in GBP
    const amountButtons = document.querySelectorAll(".amount-btn");

    console.log("Updating predefined amounts:", {
      currency: this.donationData.currency,
      userLocation: this.userLocation?.country_code,
      exchangeRates: this.exchangeRates?.length || 0
    });

    amountButtons.forEach((button, index) => {
      if (index < predefinedAmounts.length) {
        const baseAmount = predefinedAmounts[index];
        let displayAmount = baseAmount;
        let currencySymbol = this.getCurrencySymbol();

        if (this.donationData.currency !== "GBP") {
          const convertedAmount = this.convertCurrency({
            amount: baseAmount,
            rates: this.exchangeRates,
            toCurrency: this.donationData.currency,
            fromCurrency: "GBP",
          });

          if (convertedAmount > 0) {
            displayAmount = convertedAmount;
          }
        }

        button.textContent = `${currencySymbol}${displayAmount.toFixed(2)}`;
        button.setAttribute("data-amount", displayAmount.toFixed(2));
        
        console.log(`Button ${index}:`, {
          baseAmount,
          displayAmount,
          currencySymbol,
          dataAmount: button.getAttribute("data-amount"),
          buttonText: button.textContent
        });
      }
    });
  }

  syncPredefinedAmountSelection() {
    // Clear all active states first
    document.querySelectorAll(".amount-btn").forEach((btn) => {
      btn.classList.remove("active");
    });

    // Find the button that matches the current amount
    const currentAmount = this.donationData.amount;
    const amountButtons = document.querySelectorAll(".amount-btn");
    
    amountButtons.forEach((button) => {
      const buttonAmount = parseFloat(button.getAttribute("data-amount"));
      if (buttonAmount && Math.abs(buttonAmount - currentAmount) < 0.01) {
        button.classList.add("active");
      }
    });
  }

  updateExchangeRateInfo() {
    if (this.donationData.currency === "GBP") {
      document.getElementById("exchange-rate-info").style.display = "none";
      return;
    }

    const convertedAmount = this.convertCurrency({
      amount: 1,
      rates: this.exchangeRates,
      toCurrency: this.donationData.currency,
      fromCurrency: "GBP",
    });

    if (convertedAmount > 0) {
      document.getElementById("exchange-rate-amount").textContent =
        convertedAmount.toFixed(2);
      document.getElementById("exchange-rate-currency").textContent =
        this.donationData.currency;
      document.getElementById("exchange-rate-info").style.display = "block";
    } else {
      document.getElementById("exchange-rate-info").style.display = "none";
    }
  }

//   updateDonationSummary() {
//     const title = document.getElementById("donation-summary-title");
//     if (!title) return;

//     const typeText =
//       this.donationData.type === "once"
//         ? "a One-off"
//         : this.donationData.type === "multi"
//         ? "Multiple"
//         : "a Recurring";

//     let amount =
//       this.donationData.type === "multi"
//         ? this.donationData.multiDonations.reduce((sum, d) => sum + d.amount + d.fees, 0)
//         : this.donationData.amount;

//     // Add fees if cover fees is enabled (only for non-multi donations)
//     if (this.donationData.type !== "multi" && this.donationData.coverFees) {
//       const fees = this.calculateFees(amount);
//       amount += fees;
//     }

//     const frequency =
//       this.donationData.type === "subscription"
//         ? `/${this.donationData.subscriptionType}`
//         : "";

//     title.textContent = `You're making ${typeText} donation of ${this.getCurrencySymbol()}${amount.toFixed(
//       2
//     )}${frequency}`;
//   }

// updateDonationSummary() {
//   const title = document.getElementById("donation-summary-title");
//   if (!title) return;

//   const typeText =
//     this.donationData.type === "once"
//       ? "a One-off"
//       : this.donationData.type === "multi"
//       ? "Multiple"
//       : "a Recurring";

//   let amount =
//     this.donationData.type === "multi"
//       ? this.donationData.multiDonations.reduce((sum, d) => sum + d.amount + d.fees, 0)
//       : this.donationData.amount;

//   // Add fees if cover fees is enabled (only for non-multi donations)
//   if (this.donationData.type !== "multi" && this.donationData.coverFees) {
//     const fees = this.calculateFees(amount);
//     amount += fees;
//   }

//   const frequency =
//     this.donationData.type === "subscription"
//       ? `/${this.donationData.subscriptionType}`
//       : "";

//   // Use innerHTML and add <span> with styles
//   title.innerHTML = `You're making 
//     <span style="color:#4B88B2">${typeText}</span> 
//     donation of 
//     <span style="color:#4B88B2">${this.getCurrencySymbol()}${amount.toFixed(
//       2
//     )}</span>
//     <span style="color:#4B88B2">${frequency}</span>`;
// }


updateDonationSummary() {
  const title = document.getElementById("donation-summary-title");
  if (!title) return;

  // Only keep the word that needs highlighting
  const typeText =
    this.donationData.type === "once"
      ? "One-off"
      : this.donationData.type === "multi"
      ? "Multiple"
      : "Recurring";

  let amount =
    this.donationData.type === "multi"
      ? this.donationData.multiDonations.reduce((sum, d) => sum + d.amount + d.fees, 0)
      : this.donationData.amount;

  // Add fees if cover fees is enabled (only for non-multi donations)
  if (this.donationData.type !== "multi" && this.donationData.coverFees) {
    const fees = this.calculateFees(amount);
    amount += fees;
  }

  const frequency =
    this.donationData.type === "subscription"
      ? `/${this.donationData.subscriptionType}`
      : "";

  //  Span only around typeText
  title.innerHTML = `You're making a 
    <span style="color:#4B88B2">${typeText}</span> 
    donation of 
    <span style="color:#4B88B2">${this.getCurrencySymbol()}${amount.toFixed(
      2
    )}</span>
    <span style="color:#4B88B2">${frequency}</span>`;
}


  proceedToPersonalDetails() {
    // Validate donation form
    if (!this.validateDonationForm()) {
      return;
    }

    this.showStep(2);
  }

  validateDonationForm() {
    let isValid = true;

    // Clear previous errors
    document.querySelectorAll(".error-message").forEach((el) => {
      el.style.display = "none";
    });

    // Validate amount based on donation type
    if (this.donationData.type === "multi") {
      // For multi donations, validate that we have at least one donation with valid amount
      if (this.donationData.multiDonations.length === 0) {
        this.showError("Please add at least one campaign to your donation");
        isValid = false;
      } else {
        // Check if all multi donations have valid amounts and meet minimum requirement
        const hasInvalidAmount = this.donationData.multiDonations.some(donation => {
          if (donation.amount <= 0) return true;
          if (!this.validateMinimumAmount(donation.amount, this.donationData.currency)) return true;
          return false;
        });
        
        if (hasInvalidAmount) {
          const convertedCurrency = this.convertCurrency({
            amount: this.MINIMUM_DONATION_GBP,
            rates: this.exchangeRates,
            toCurrency: this.donationData.currency,
          });
          const minimumAmountInCurrentCurrency = convertedCurrency ?? 0;
          
          this.showAmountError(
            `Please enter a valid donation amount for all campaigns. Minimum amount is ${this.getCurrencySymbol(
              this.donationData.currency
            )}${minimumAmountInCurrentCurrency.toFixed(2)}`
          );
          isValid = false;
        }
      }
    } else {
      // For single donations, validate the main amount
      if (this.donationData.amount <= 0) {
        this.showAmountError("Please enter a valid donation amount");
        isValid = false;
      } else if (!this.validateMinimumAmount(this.donationData.amount, this.donationData.currency)) {
        const convertedCurrency = this.convertCurrency({
          amount: this.MINIMUM_DONATION_GBP,
          rates: this.exchangeRates,
          toCurrency: this.donationData.currency,
        });
        const minimumAmountInCurrentCurrency = convertedCurrency ?? 0;
        
        this.showAmountError(
          `Minimum donation amount is ${this.getCurrencySymbol(
            this.donationData.currency
          )}${minimumAmountInCurrentCurrency.toFixed(2)}`
        );
        isValid = false;
      }
    }

    // Validate campaign selection for non-multi donations
    if (
      this.donationData.type !== "multi" &&
      !this.donationData.selectedCampaignId
    ) {
      this.showError("Please select a campaign");
      isValid = false;
    }

    // Validate campaign fields if applicable
    if (this.donationData.type !== "multi" && this.donationData.selectedCampaignId) {
      if (!this.validateAllCampaignFields()) {
        this.showError("Please fill in all required campaign fields");
        isValid = false;
      }
    }

    return isValid;
  }

  showAmountError(message) {
    const errorEl = document.getElementById("amount-error");
    errorEl.textContent = message;
    errorEl.style.display = "block";

    const inputContainer = document.querySelector(".custom-amount-input");
    inputContainer.classList.add("error");
  }

  showError(message) {
    // Simple error display - in production, use a proper notification system
    alert(message);
  }

//   submitPersonalDetails() {
//     // Collect form data
//     const formData = new FormData(document.getElementById("personal-form"));

//     // Get country code and phone number
//     const countryCode = document.getElementById("country-code").value;
//     const phoneNumber = formData.get("mobile") || "";
//     const fullPhoneNumber = countryCode + phoneNumber;

//     this.donationData.personalInfo = {
//       title: formData.get("title") || "",
//       firstName: formData.get("firstName") || "",
//       lastName: formData.get("lastName") || "",
//       email: formData.get("email") || "",
//       mobile: fullPhoneNumber,
//       country: formData.get("country") || "United Kingdom",
//       company: formData.get("company") || "",
//       asOrganisation: document.getElementById("as-organisation").checked,
//       giftAid: document.getElementById("gift-aid").checked,
//       address: {
//         line1: formData.get("addressLine1") || "",
//         line2: formData.get("addressLine2") || "",
//         city: formData.get("city") || "",
//         postCode: formData.get("postCode") || "",
//       },
//     };

//     // Validate form
//     if (!this.validatePersonalForm()) {
//       return;
//     }

//     // Proceed to payment
//     this.createPaymentIntent();
//   }


submitPersonalDetails() {
  // Collect form data
  const formData = new FormData(document.getElementById("personal-form"));

  // Get full mobile number (already includes dial code)
  const fullPhoneNumber = formData.get("mobile") || "";

  this.donationData.personalInfo = {
    title: formData.get("title") || "",
    firstName: formData.get("firstName") || "",
    lastName: formData.get("lastName") || "",
    email: formData.get("email") || "",
    mobile: fullPhoneNumber,
    country: formData.get("country") || "United Kingdom",
    company: formData.get("company") || "",
    asOrganisation: document.getElementById("as-organisation").checked,
    giftAid: document.getElementById("gift-aid").checked,
    address: {
      line1: formData.get("addressLine1") || "",
      line2: formData.get("addressLine2") || "",
      city: formData.get("city") || "",
      postCode: formData.get("postCode") || "",
    },
  };

  // Validate form
  if (!this.validatePersonalForm()) {
    return;
  }

  // Proceed to payment
  this.createPaymentIntent();
}


  validatePersonalForm() {
    const required = ["firstName", "lastName", "email", "mobile", "title"];
    let isValid = true;

    required.forEach((field) => {
      const input = document.getElementById(field);
      if (!input.value.trim()) {
        this.showFieldError(field, "This field is required");
        isValid = false;
      }
    });

    // Validate email
    const email = document.getElementById("email").value;
    if (email && !this.isValidEmail(email)) {
      this.showFieldError("email", "Please enter a valid email address");
      isValid = false;
    }

    // Validate phone
    const mobile = document.getElementById("mobile").value;
    if (mobile && !this.isValidPhone(mobile)) {
      this.showFieldError("mobile", "Please enter a valid phone number");
      isValid = false;
    }

    // Validate Gift Aid fields if enabled
    if (this.donationData.personalInfo.giftAid) {
      const giftAidRequired = ["addressLine1", "city", "postCode"];
      giftAidRequired.forEach((field) => {
        const input = document.getElementById(field);
        if (!input.value.trim()) {
          this.showFieldError(field, "This field is required for Gift Aid");
          isValid = false;
        }
      });
    }

    return isValid;
  }

  showFieldError(fieldName, message) {
    const input = document.getElementById(fieldName);
    const formGroup = input.closest(".form-group");

    formGroup.classList.add("error");

    let errorEl = formGroup.querySelector(".error-text");
    if (!errorEl) {
      errorEl = document.createElement("span");
      errorEl.className = "error-text";
      formGroup.appendChild(errorEl);
    }
    errorEl.textContent = message;
  }

  isValidEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
  }

  isValidPhone(phone) {
    const re = /^\+?[\d\s\-\(\)]+$/;
    return re.test(phone) && phone.replace(/\D/g, "").length >= 7;
  }

  async createPaymentIntent() {
    this.showLoading("Creating payment...");

    try {
      let response;

      if (this.donationData.type === "once") {
        response = await this.createSinglePaymentIntent();
      } else if (this.donationData.type === "multi") {
        response = await this.createMultiPaymentIntent();
      } else {
        response = await this.createSubscriptionPaymentIntent();
      }

      if (response.status) {
        // Store payment intent response in a separate variable
        this.paymentIntentResponse = response;
        this.donationData.paymentIntent = response;
        this.showStep(3);
        this.initializeStripe();
      } else {
        throw new Error(response.message || "Failed to create payment");
      }
    } catch (error) {
      console.error("Payment creation failed:", error);
      this.showError("Failed to create payment. Please try again.");
    } finally {
      this.hideLoading();
    }
  }

  async createSinglePaymentIntent() {
    const amount = this.donationData.amount;
    const fees = this.donationData.coverFees ? this.calculateFees(amount) : 0;
    const totalAmount = amount + fees;

    const selectedCampaign = this.campaigns.find(
      (c) => c.campaign_id.toString() === this.donationData.selectedCampaignId
    );

    const payload = {
      amount: totalAmount,
      currency: this.donationData.currency,
      is_subscriber: this.donationData.isSubscriber,
      metadata: {
        amount: totalAmount,
        fees: fees,
        campaign_id: this.donationData.selectedCampaignId
          ? parseInt(this.donationData.selectedCampaignId)
          : 0,
        campaign_name: selectedCampaign ? selectedCampaign.title : "",
        first_name: this.donationData.personalInfo.firstName,
        last_name: this.donationData.personalInfo.lastName,
        email: this.donationData.personalInfo.email,
        mobile: this.donationData.personalInfo.mobile,
        country: this.donationData.personalInfo.country,
        title: this.donationData.personalInfo.title,
        company: this.donationData.personalInfo.asOrganisation
          ? this.donationData.personalInfo.company
          : "",
        giftaid_city: this.donationData.personalInfo.address.city,
        giftaid_line_1: this.donationData.personalInfo.address.line1,
        giftaid_line_2: this.donationData.personalInfo.address.line2,
        giftaid_postcode: this.donationData.personalInfo.address.postCode,
        is_giftaid_claimed: this.donationData.personalInfo.giftAid,
        type: 1,
        additional_fields: JSON.stringify(
          Object.entries(this.donationData.campaignFieldValues)
            .map(([key, value]) => {
              return value.map((item) => ({
                campaign_field_id: Number(key),
                value: item,
              }));
            })
            .flat()
        ),
        donation_platform: 1,
      },
    };

    return await this.apiCall("/donations/single-payment-intent", {
      method: "POST",
      body: JSON.stringify(payload),
    });
  }

  async createMultiPaymentIntent() {
    const payload = {
      currency: this.donationData.currency,
      is_subscriber: this.donationData.isSubscriber,
      metadata: {
        first_name: this.donationData.personalInfo.firstName,
        last_name: this.donationData.personalInfo.lastName,
        email: this.donationData.personalInfo.email,
        mobile: this.donationData.personalInfo.mobile,
        country: this.donationData.personalInfo.country,
        title: this.donationData.personalInfo.title,
        company: this.donationData.personalInfo.asOrganisation
          ? this.donationData.personalInfo.company
          : "",
        giftaid_city: this.donationData.personalInfo.address.city,
        giftaid_line_1: this.donationData.personalInfo.address.line1,
        giftaid_line_2: this.donationData.personalInfo.address.line2,
        giftaid_postcode: this.donationData.personalInfo.address.postCode,
        is_giftaid_claimed: this.donationData.personalInfo.giftAid,
        type: 2,
        donation_platform: 1,
      },
      donations: this.donationData.multiDonations.map((donation) => ({
        campaign_id: donation.campaign.campaign_id,
        campaign_name: donation.campaign.title,
        amount:
          parseFloat(donation.amount.toString()) +
          parseFloat(donation.fees.toString()),
        fees: donation.fees,
        additional_fields: JSON.stringify(
          Object.entries(donation.fieldValues)
            .map(([key, value]) => {
              return value.map((item) => ({
                campaign_field_id: Number(key),
                value: item,
              }));
            })
            .flat()
        ),
      })),
    };

    return await this.apiCall("/donations/multi-payment-intent", {
      method: "POST",
      body: JSON.stringify(payload),
    });
  }

  async createSubscriptionPaymentIntent() {
    const amount = this.donationData.amount;
    const fees = this.donationData.coverFees ? this.calculateFees(amount) : 0;
    const totalAmount = amount + fees;

    const selectedCampaign = this.campaigns.find(
      (c) => c.campaign_id.toString() === this.donationData.selectedCampaignId
    );

    const frequencyMap = {
      weekly: 1,
      monthly: 2,
      quarterly: 3,
      yearly: 4,
    };

    const payload = {
      amount: totalAmount,
      currency: this.donationData.currency,
      is_subscriber: this.donationData.isSubscriber,
      frequency: frequencyMap[this.donationData.subscriptionType] || 2,
      metadata: {
        amount: totalAmount,
        fees: fees,
        campaign_id: this.donationData.selectedCampaignId
          ? parseInt(this.donationData.selectedCampaignId)
          : 0,
        campaign_name: selectedCampaign ? selectedCampaign.title : "",
        first_name: this.donationData.personalInfo.firstName,
        last_name: this.donationData.personalInfo.lastName,
        email: this.donationData.personalInfo.email,
        mobile: this.donationData.personalInfo.mobile,
        country: this.donationData.personalInfo.country,
        title: this.donationData.personalInfo.title,
        company: this.donationData.personalInfo.asOrganisation
          ? this.donationData.personalInfo.company
          : "",
        giftaid_city: this.donationData.personalInfo.address.city,
        giftaid_line_1: this.donationData.personalInfo.address.line1,
        giftaid_line_2: this.donationData.personalInfo.address.line2,
        giftaid_postcode: this.donationData.personalInfo.address.postCode,
        is_giftaid_claimed: this.donationData.personalInfo.giftAid,
        type: 3,
        additional_fields: JSON.stringify(
          Object.entries(this.donationData.campaignFieldValues)
            .map(([key, value]) => {
              return value.map((item) => ({
                campaign_field_id: Number(key),
                value: item,
              }));
            })
            .flat()
        ),
        donation_platform: 1,
      },
    };

    return await this.apiCall("/donations/subscription", {
      method: "POST",
      body: JSON.stringify(payload),
    });
  }

  buildPaymentData() {
    const amount =
      this.donationData.type === "multi"
        ? this.donationData.multiDonations.reduce((sum, d) => sum + d.amount, 0)
        : this.donationData.amount;

    const fees = this.donationData.coverFees ? this.calculateFees(amount) : 0;
    const totalAmount = amount + fees;

    return {
      amount: Math.round(totalAmount * 100), // Convert to cents
      currency: this.donationData.currency.toLowerCase(),
      type: this.donationData.type,
      subscriptionType: this.donationData.subscriptionType,
      campaignId: this.donationData.selectedCampaignId,
      multiDonations: this.donationData.multiDonations,
      personalInfo: this.donationData.personalInfo,
      metadata: {
        donation_platform: 1,
        type:
          this.donationData.type === "once"
            ? 1
            : this.donationData.type === "multi"
            ? 2
            : 3,
      },
    };
  }

  goBack() {
    if (this.currentStep > 1) {
      this.showStep(this.currentStep - 1);
    }
  }

  goHome() {
    // Reset form and go to step 1
    this.donationData = {
      type: "once",
      subscriptionType: "monthly",
      selectedCampaignId: "",
      amount: 20,
      customAmount: 0,
      currency: "GBP",
      coverFees: false,
      multiDonations: [],
      campaignFieldValues: {},
      personalInfo: {
        title: "",
        firstName: "",
        lastName: "",
        email: "",
        mobile: "",
        country: "United Kingdom",
        company: "",
        asOrganisation: false,
        giftAid: false,
        address: {
          line1: "",
          line2: "",
          city: "",
          postCode: "",
        },
      },
      paymentInfo: {},
      isSubscriber: false,
    };

    // Reset UI
    this.resetForm();
    window.location.href = "/";
    this.showStep(1);
  }

  resetForm() {
    // Reset all form inputs
    document.getElementById("personal-form").reset();
    document.getElementById("custom-amount").value = "";
    document.getElementById("campaign-select").value = "";
    document.querySelectorAll(".amount-btn").forEach((btn) => {
      btn.classList.remove("active");
    });
    document.querySelectorAll(".donation-type-btn").forEach((btn) => {
      btn.classList.remove("active");
    });
    document.querySelector('[data-type="once"]').classList.add("active");

    // Clear multi donations
    this.donationData.multiDonations = [];
    this.updateMultiDonationList();

    // Reset UI state
    document.getElementById("multi-donation-section").style.display = "none";
    document.getElementById("subscription-frequency").style.display = "none";
    document.getElementById("add-campaign-btn").style.display = "none";
    document.getElementById("multi-info").style.display = "none";
    document.getElementById("organisation-field").style.display = "none";
    document.getElementById("gift-aid-fields").style.display = "none";
  }

  showShareModal() {
    document.getElementById("share-modal").style.display = "flex";
  }

  hideShareModal() {
    document.getElementById("share-modal").style.display = "none";
  }

  shareOnSocial(platform) {
    const campaign =
      this.campaigns.find(
        (c) => c.campaign_id.toString() === this.donationData.selectedCampaignId
      ) || this.campaigns[0];

    const url = window.location.href;
    const text = `Please donate to ${campaign?.title || "this campaign"}. ${
      campaign?.description || ""
    } ${url}`;

    const shareUrls = {
      whatsapp: `https://api.whatsapp.com/send?text=${encodeURIComponent(
        text
      )}`,
      facebook: `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(
        url
      )}`,
      twitter: `https://twitter.com/intent/tweet?text=${encodeURIComponent(
        text
      )}`,
      linkedin: `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(
        url
      )}`,
      email: `mailto:?subject=${encodeURIComponent(
        campaign?.title || "Donation Campaign"
      )}&body=${encodeURIComponent(text)}`,
    };

    if (platform === "email") {
      window.location.href = shareUrls[platform];
    } else {
      window.open(
        shareUrls[platform],
        "_blank",
        "width=600,height=500,scrollbars=yes,resizable=yes"
      );
    }

    this.hideShareModal();
  }

  // API Methods
  async loadCampaigns() {
    try {
      const response = await this.apiCall("/campaigns");
      this.campaigns = response.data || [];
    } catch (error) {
      console.error("Failed to load campaigns:", error);
      this.campaigns = [];
    }
  }

  async loadCurrencies() {
    try {
      const response = await this.apiCall("/currencies");
      this.currencies = response.data || [];
    } catch (error) {
      console.error("Failed to load currencies:", error);
      this.currencies = [];
    }
  }

  async loadEnabledCurrencies() {
    try {
      const response = await this.apiCall("/currencies/enabled");
      this.enabledCurrencies = response.data || [];
    } catch (error) {
      console.error("Failed to load enabled currencies:", error);
      this.enabledCurrencies = [];
    }
  }

  async loadExchangeRates() {
    try {
      const response = await this.apiCall("/donations/currencies");
      this.exchangeRates = response.data || [];
    } catch (error) {
      console.error("Failed to load exchange rates:", error);
      this.exchangeRates = [];
    }
  }

  async getUserLocation() {
    try {
      const response = await fetch("https://ipwho.is");
      if (!response.ok) {
        throw new Error("Failed to fetch user location");
      }
      const data = await response.json();

      // Check if the API response indicates success
      if (data.status === false) {
        throw new Error(data.message || "Failed to get user location");
      }

      this.userLocation = data;

      // Set currency based on location
      if (data.country_code && this.enabledCurrencies.length > 0) {
        const currency = this.getCurrencyFromCountryCode(data.country_code);

        if (
          currency &&
          this.enabledCurrencies.some((c) => c.code.toUpperCase() === currency)
        ) {
          console.log("Setting currency to:", currency);
          this.setCurrency(currency);
          // Don't set the select value here - let populateCurrencySelect handle it
        } else {
          console.log(
            "Currency not found in enabled currencies or not supported"
          );
        }
      }

      // Update Gift Aid visibility based on location
      this.updateGiftAidVisibility();
    } catch (error) {
      console.error("Failed to get user location:", error);
    }
  }

  convertCurrency({ amount, rates, toCurrency, fromCurrency = "GBP" }) {
    const fromCurrencyRate = rates.find(
      (rate) => rate.currency === fromCurrency
    );
    const toCurrencyRate = rates.find((rate) => rate.currency === toCurrency);

    if (fromCurrencyRate && toCurrencyRate) {
      // First convert from source currency to EUR
      const amountInEUR = amount / parseFloat(fromCurrencyRate.rate);

      // Then convert from EUR to target currency
      const convertedAmount = amountInEUR * parseFloat(toCurrencyRate.rate);

      return Math.round(convertedAmount * 100) / 100;
    } else {
      return 0;
    }
  }

  getCurrencyFromCountryCode(countryCode) {
    // Ensure input is uppercase for consistency
    countryCode = countryCode.toUpperCase();

    // Map of country codes to their primary currency codes
    const countryCurrencyMap = {
      // A
      AD: "EUR", // Andorra
      AE: "AED", // United Arab Emirates
      AF: "AFN", // Afghanistan
      AG: "XCD", // Antigua and Barbuda
      AI: "XCD", // Anguilla
      AL: "ALL", // Albania
      AM: "AMD", // Armenia
      AO: "AOA", // Angola
      AR: "ARS", // Argentina
      AS: "USD", // American Samoa
      AT: "EUR", // Austria
      AU: "AUD", // Australia
      AW: "AWG", // Aruba
      AX: "EUR", // Åland Islands
      AZ: "AZN", // Azerbaijan

      // B
      BA: "BAM", // Bosnia and Herzegovina
      BB: "BBD", // Barbados
      BD: "BDT", // Bangladesh
      BE: "EUR", // Belgium
      BF: "XOF", // Burkina Faso
      BG: "BGN", // Bulgaria
      BH: "BHD", // Bahrain
      BI: "BIF", // Burundi
      BJ: "XOF", // Benin
      BL: "EUR", // Saint Barthélemy
      BM: "BMD", // Bermuda
      BN: "BND", // Brunei
      BO: "BOB", // Bolivia
      BQ: "USD", // Bonaire, Sint Eustatius and Saba
      BR: "BRL", // Brazil
      BS: "BSD", // Bahamas
      BT: "BTN", // Bhutan
      BV: "NOK", // Bouvet Island
      BW: "BWP", // Botswana
      BY: "BYN", // Belarus
      BZ: "BZD", // Belize

      // C
      CA: "CAD", // Canada
      CC: "AUD", // Cocos (Keeling) Islands
      CD: "CDF", // DR Congo
      CF: "XAF", // Central African Republic
      CG: "XAF", // Republic of the Congo
      CH: "CHF", // Switzerland
      CI: "XOF", // Côte d'Ivoire
      CK: "NZD", // Cook Islands
      CL: "CLP", // Chile
      CM: "XAF", // Cameroon
      CN: "CNY", // China
      CO: "COP", // Colombia
      CR: "CRC", // Costa Rica
      CU: "CUP", // Cuba
      CV: "CVE", // Cape Verde
      CW: "ANG", // Curaçao
      CX: "AUD", // Christmas Island
      CY: "EUR", // Cyprus
      CZ: "CZK", // Czech Republic

      // D
      DE: "EUR", // Germany
      DJ: "DJF", // Djibouti
      DK: "DKK", // Denmark
      DM: "XCD", // Dominica
      DO: "DOP", // Dominican Republic
      DZ: "DZD", // Algeria

      // E
      EC: "USD", // Ecuador
      EE: "EUR", // Estonia
      EG: "EGP", // Egypt
      EH: "MAD", // Western Sahara
      ER: "ERN", // Eritrea
      ES: "EUR", // Spain
      ET: "ETB", // Ethiopia

      // F
      FI: "EUR", // Finland
      FJ: "FJD", // Fiji
      FK: "FKP", // Falkland Islands
      FM: "USD", // Micronesia
      FO: "DKK", // Faroe Islands
      FR: "EUR", // France

      // G
      GA: "XAF", // Gabon
      GB: "GBP", // United Kingdom
      GD: "XCD", // Grenada
      GE: "GEL", // Georgia
      GF: "EUR", // French Guiana
      GG: "GBP", // Guernsey
      GH: "GHS", // Ghana
      GI: "GIP", // Gibraltar
      GL: "DKK", // Greenland
      GM: "GMD", // Gambia
      GN: "GNF", // Guinea
      GP: "EUR", // Guadeloupe
      GQ: "XAF", // Equatorial Guinea
      GR: "EUR", // Greece
      GS: "GBP", // South Georgia and the South Sandwich Islands
      GT: "GTQ", // Guatemala
      GU: "USD", // Guam
      GW: "XOF", // Guinea-Bissau
      GY: "GYD", // Guyana

      // H
      HK: "HKD", // Hong Kong
      HM: "AUD", // Heard Island and McDonald Islands
      HN: "HNL", // Honduras
      HR: "EUR", // Croatia
      HT: "HTG", // Haiti
      HU: "HUF", // Hungary

      // I
      ID: "IDR", // Indonesia
      IE: "EUR", // Ireland
      IL: "ILS", // Israel
      IM: "GBP", // Isle of Man
      IN: "INR", // India
      IO: "USD", // British Indian Ocean Territory
      IQ: "IQD", // Iraq
      IR: "IRR", // Iran
      IS: "ISK", // Iceland
      IT: "EUR", // Italy

      // J
      JE: "GBP", // Jersey
      JM: "JMD", // Jamaica
      JO: "JOD", // Jordan
      JP: "JPY", // Japan

      // K
      KE: "KES", // Kenya
      KG: "KGS", // Kyrgyzstan
      KH: "KHR", // Cambodia
      KI: "AUD", // Kiribati
      KM: "KMF", // Comoros
      KN: "XCD", // Saint Kitts and Nevis
      KP: "KPW", // North Korea
      KR: "KRW", // South Korea
      KW: "KWD", // Kuwait
      KY: "KYD", // Cayman Islands
      KZ: "KZT", // Kazakhstan

      // L
      LA: "LAK", // Laos
      LB: "LBP", // Lebanon
      LC: "XCD", // Saint Lucia
      LI: "CHF", // Liechtenstein
      LK: "LKR", // Sri Lanka
      LR: "LRD", // Liberia
      LS: "LSL", // Lesotho
      LT: "EUR", // Lithuania
      LU: "EUR", // Luxembourg
      LV: "EUR", // Latvia
      LY: "LYD", // Libya

      // M
      MA: "MAD", // Morocco
      MC: "EUR", // Monaco
      MD: "MDL", // Moldova
      ME: "EUR", // Montenegro
      MF: "EUR", // Saint Martin
      MG: "MGA", // Madagascar
      MH: "USD", // Marshall Islands
      MK: "MKD", // North Macedonia
      ML: "XOF", // Mali
      MM: "MMK", // Myanmar
      MN: "MNT", // Mongolia
      MO: "MOP", // Macau
      MP: "USD", // Northern Mariana Islands
      MQ: "EUR", // Martinique
      MR: "MRU", // Mauritania
      MS: "XCD", // Montserrat
      MT: "EUR", // Malta
      MU: "MUR", // Mauritius
      MV: "MVR", // Maldives
      MW: "MWK", // Malawi
      MX: "MXN", // Mexico
      MY: "MYR", // Malaysia
      MZ: "MZN", // Mozambique

      // N
      NA: "NAD", // Namibia
      NC: "XPF", // New Caledonia
      NE: "XOF", // Niger
      NF: "AUD", // Norfolk Island
      NG: "NGN", // Nigeria
      NI: "NIO", // Nicaragua
      NL: "EUR", // Netherlands
      NO: "NOK", // Norway
      NP: "NPR", // Nepal
      NR: "AUD", // Nauru
      NU: "NZD", // Niue
      NZ: "NZD", // New Zealand

      // O
      OM: "OMR", // Oman

      // P
      PA: "PAB", // Panama
      PE: "PEN", // Peru
      PF: "XPF", // French Polynesia
      PG: "PGK", // Papua New Guinea
      PH: "PHP", // Philippines
      PK: "PKR", // Pakistan
      PL: "PLN", // Poland
      PM: "EUR", // Saint Pierre and Miquelon
      PN: "NZD", // Pitcairn Islands
      PR: "USD", // Puerto Rico
      PS: "ILS", // Palestine
      PT: "EUR", // Portugal
      PW: "USD", // Palau
      PY: "PYG", // Paraguay

      // Q
      QA: "QAR", // Qatar

      // R
      RE: "EUR", // Réunion
      RO: "RON", // Romania
      RS: "RSD", // Serbia
      RU: "RUB", // Russia
      RW: "RWF", // Rwanda

      // S
      SA: "SAR", // Saudi Arabia
      SB: "SBD", // Solomon Islands
      SC: "SCR", // Seychelles
      SD: "SDG", // Sudan
      SE: "SEK", // Sweden
      SG: "SGD", // Singapore
      SH: "SHP", // Saint Helena
      SI: "EUR", // Slovenia
      SJ: "NOK", // Svalbard and Jan Mayen
      SK: "EUR", // Slovakia
      SL: "SLE", // Sierra Leone
      SM: "EUR", // San Marino
      SN: "XOF", // Senegal
      SO: "SOS", // Somalia
      SR: "SRD", // Suriname
      SS: "SSP", // South Sudan
      ST: "STN", // São Tomé and Príncipe
      SV: "USD", // El Salvador
      SX: "ANG", // Sint Maarten
      SY: "SYP", // Syria
      SZ: "SZL", // Eswatini

      // T
      TC: "USD", // Turks and Caicos Islands
      TD: "XAF", // Chad
      TF: "EUR", // French Southern and Antarctic Lands
      TG: "XOF", // Togo
      TH: "THB", // Thailand
      TJ: "TJS", // Tajikistan
      TK: "NZD", // Tokelau
      TL: "USD", // East Timor
      TM: "TMT", // Turkmenistan
      TN: "TND", // Tunisia
      TO: "TOP", // Tonga
      TR: "TRY", // Turkey
      TT: "TTD", // Trinidad and Tobago
      TV: "AUD", // Tuvalu
      TW: "TWD", // Taiwan
      TZ: "TZS", // Tanzania

      // U
      UA: "UAH", // Ukraine
      UG: "UGX", // Uganda
      UM: "USD", // United States Minor Outlying Islands
      US: "USD", // United States
      UY: "UYU", // Uruguay
      UZ: "UZS", // Uzbekistan

      // V
      VA: "EUR", // Vatican City
      VC: "XCD", // Saint Vincent and the Grenadines
      VE: "VES", // Venezuela
      VG: "USD", // British Virgin Islands
      VI: "USD", // U.S. Virgin Islands
      VN: "VND", // Vietnam
      VU: "VUV", // Vanuatu

      // W
      WF: "XPF", // Wallis and Futuna
      WS: "WST", // Samoa

      // Y
      YE: "YER", // Yemen
      YT: "EUR", // Mayotte

      // Z
      ZA: "ZAR", // South Africa
      ZM: "ZMW", // Zambia
      ZW: "ZWL", // Zimbabwe
    };

    // Return the currency code if found, null otherwise
    return countryCurrencyMap[countryCode] || "GBP";
  }

  async loadCampaignFields(campaignId) {
    try {
      const campaign = this.campaigns.find(
        (c) => c.campaign_id.toString() === campaignId
      );
      if (campaign && campaign.campaign_fields) {
        this.renderCampaignFields();
      }
    } catch (error) {
      console.error("Failed to load campaign fields:", error);
    }
  }

  populateCampaignSelect() {
    const select = document.getElementById("campaign-select");
    select.innerHTML = '<option value="">Select a campaign</option>';

    this.campaigns.forEach((campaign) => {
      const option = document.createElement("option");
      option.value = campaign.campaign_id;
      option.textContent = campaign.title;
      select.appendChild(option);
    });
	select.style.display = 'block';
  }

  populateCurrencySelect() {
    const select = document.getElementById("currency-select");
    select.innerHTML = "";

    this.enabledCurrencies.forEach((currency) => {
      const option = document.createElement("option");
      option.value = currency.code.toUpperCase();
      option.textContent = currency.code.toUpperCase();
      select.appendChild(option);
    });

    // console.log('Current currency in donationData:', this.donationData.currency);

    // Set default currency only if no currency is already set
    if (this.enabledCurrencies.length > 0 && !this.donationData.currency) {
      const defaultCurrency =
        this.enabledCurrencies.find((c) => c.code === "GBP") ||
        this.enabledCurrencies[0];
      // console.log('Setting default currency:', defaultCurrency.code);
      this.setCurrency(defaultCurrency.code.toUpperCase());
      select.value = defaultCurrency.code.toUpperCase();
    } else if (this.donationData.currency) {
      // If currency is already set (e.g., from location detection), use that
      // console.log('Using existing currency:', this.donationData.currency);
      select.value = this.donationData.currency;
    }

    console.log("Final select value:", select.value);
  }

   populateCountryCodeSelect() {
    const select = document.getElementById("country-code");
    select.innerHTML = "";

    const countries = [
      { code: "AD", name: "Andorra", dialCode: "+376", flag: "🇦🇩" },
      {
        code: "AE",
        name: "United Arab Emirates",
        dialCode: "+971",
        flag: "🇦🇪",
      },
      { code: "AF", name: "Afghanistan", dialCode: "+93", flag: "🇦🇫" },
      { code: "AG", name: "Antigua and Barbuda", dialCode: "+1", flag: "🇦🇬" },
      { code: "AI", name: "Anguilla", dialCode: "+1", flag: "🇦🇮" },
      { code: "AL", name: "Albania", dialCode: "+355", flag: "🇦🇱" },
      { code: "AM", name: "Armenia", dialCode: "+374", flag: "🇦🇲" },
      { code: "AO", name: "Angola", dialCode: "+244", flag: "🇦🇴" },
      { code: "AR", name: "Argentina", dialCode: "+54", flag: "🇦🇷" },
      { code: "AS", name: "American Samoa", dialCode: "+1", flag: "🇦🇸" },
      { code: "AT", name: "Austria", dialCode: "+43", flag: "🇦🇹" },
      { code: "AU", name: "Australia", dialCode: "+61", flag: "🇦🇺" },
      { code: "AW", name: "Aruba", dialCode: "+297", flag: "🇦🇼" },
      { code: "AX", name: "Åland Islands", dialCode: "+358", flag: "🇦🇽" },
      { code: "AZ", name: "Azerbaijan", dialCode: "+994", flag: "🇦🇿" },
      {
        code: "BA",
        name: "Bosnia and Herzegovina",
        dialCode: "+387",
        flag: "🇧🇦",
      },
      { code: "BB", name: "Barbados", dialCode: "+1", flag: "🇧🇧" },
      { code: "BD", name: "Bangladesh", dialCode: "+880", flag: "🇧🇩" },
      { code: "BE", name: "Belgium", dialCode: "+32", flag: "🇧🇪" },
      { code: "BF", name: "Burkina Faso", dialCode: "+226", flag: "🇧🇫" },
      { code: "BG", name: "Bulgaria", dialCode: "+359", flag: "🇧🇬" },
      { code: "BH", name: "Bahrain", dialCode: "+973", flag: "🇧🇭" },
      { code: "BI", name: "Burundi", dialCode: "+257", flag: "🇧🇮" },
      { code: "BJ", name: "Benin", dialCode: "+229", flag: "🇧🇯" },
      { code: "BL", name: "Saint Barthélemy", dialCode: "+590", flag: "🇧🇱" },
      { code: "BM", name: "Bermuda", dialCode: "+1", flag: "🇧🇲" },
      { code: "BN", name: "Brunei", dialCode: "+673", flag: "🇧🇳" },
      { code: "BO", name: "Bolivia", dialCode: "+591", flag: "🇧🇴" },
      {
        code: "BQ",
        name: "Bonaire, Sint Eustatius and Saba",
        dialCode: "+599",
        flag: "🇧🇶",
      },
      { code: "BR", name: "Brazil", dialCode: "+55", flag: "🇧🇷" },
      { code: "BS", name: "Bahamas", dialCode: "+1", flag: "🇧🇸" },
      { code: "BT", name: "Bhutan", dialCode: "+975", flag: "🇧🇹" },
      { code: "BV", name: "Bouvet Island", dialCode: "+47", flag: "🇧🇻" },
      { code: "BW", name: "Botswana", dialCode: "+267", flag: "🇧🇼" },
      { code: "BY", name: "Belarus", dialCode: "+375", flag: "🇧🇾" },
      { code: "BZ", name: "Belize", dialCode: "+501", flag: "🇧🇿" },
      { code: "CA", name: "Canada", dialCode: "+1", flag: "🇨🇦" },
      {
        code: "CC",
        name: "Cocos (Keeling) Islands",
        dialCode: "+61",
        flag: "🇨🇨",
      },
      { code: "CD", name: "DR Congo", dialCode: "+243", flag: "🇨🇩" },
      {
        code: "CF",
        name: "Central African Republic",
        dialCode: "+236",
        flag: "🇨🇫",
      },
      {
        code: "CG",
        name: "Republic of the Congo",
        dialCode: "+242",
        flag: "🇨🇬",
      },
      { code: "CH", name: "Switzerland", dialCode: "+41", flag: "🇨🇭" },
      { code: "CI", name: "Côte d'Ivoire", dialCode: "+225", flag: "🇨🇮" },
      { code: "CK", name: "Cook Islands", dialCode: "+682", flag: "🇨🇰" },
      { code: "CL", name: "Chile", dialCode: "+56", flag: "🇨🇱" },
      { code: "CM", name: "Cameroon", dialCode: "+237", flag: "🇨🇲" },
      { code: "CN", name: "China", dialCode: "+86", flag: "🇨🇳" },
      { code: "CO", name: "Colombia", dialCode: "+57", flag: "🇨🇴" },
      { code: "CR", name: "Costa Rica", dialCode: "+506", flag: "🇨🇷" },
      { code: "CU", name: "Cuba", dialCode: "+53", flag: "🇨🇺" },
      { code: "CV", name: "Cape Verde", dialCode: "+238", flag: "🇨🇻" },
      { code: "CW", name: "Curaçao", dialCode: "+599", flag: "🇨🇼" },
      { code: "CX", name: "Christmas Island", dialCode: "+61", flag: "🇨🇽" },
      { code: "CY", name: "Cyprus", dialCode: "+357", flag: "🇨🇾" },
      { code: "CZ", name: "Czech Republic", dialCode: "+420", flag: "🇨🇿" },
      { code: "DE", name: "Germany", dialCode: "+49", flag: "🇩🇪" },
      { code: "DJ", name: "Djibouti", dialCode: "+253", flag: "🇩🇯" },
      { code: "DK", name: "Denmark", dialCode: "+45", flag: "🇩🇰" },
      { code: "DM", name: "Dominica", dialCode: "+1", flag: "🇩🇲" },
      { code: "DO", name: "Dominican Republic", dialCode: "+1", flag: "🇩🇴" },
      { code: "DZ", name: "Algeria", dialCode: "+213", flag: "🇩🇿" },
      { code: "EC", name: "Ecuador", dialCode: "+593", flag: "🇪🇨" },
      { code: "EE", name: "Estonia", dialCode: "+372", flag: "🇪🇪" },
      { code: "EG", name: "Egypt", dialCode: "+20", flag: "🇪🇬" },
      { code: "EH", name: "Western Sahara", dialCode: "+212", flag: "🇪🇭" },
      { code: "ER", name: "Eritrea", dialCode: "+291", flag: "🇪🇷" },
      { code: "ES", name: "Spain", dialCode: "+34", flag: "🇪🇸" },
      { code: "ET", name: "Ethiopia", dialCode: "+251", flag: "🇪🇹" },
      { code: "FI", name: "Finland", dialCode: "+358", flag: "🇫🇮" },
      { code: "FJ", name: "Fiji", dialCode: "+679", flag: "🇫🇯" },
      { code: "FK", name: "Falkland Islands", dialCode: "+500", flag: "🇫🇰" },
      { code: "FM", name: "Micronesia", dialCode: "+691", flag: "🇫🇲" },
      { code: "FO", name: "Faroe Islands", dialCode: "+298", flag: "🇫🇴" },
      { code: "FR", name: "France", dialCode: "+33", flag: "🇫🇷" },
      { code: "GA", name: "Gabon", dialCode: "+241", flag: "🇬🇦" },
      { code: "GB", name: "United Kingdom", dialCode: "+44", flag: "🇬🇧" },
      { code: "GD", name: "Grenada", dialCode: "+1", flag: "🇬🇩" },
      { code: "GE", name: "Georgia", dialCode: "+995", flag: "🇬🇪" },
      { code: "GF", name: "French Guiana", dialCode: "+594", flag: "🇬🇫" },
      { code: "GG", name: "Guernsey", dialCode: "+44", flag: "🇬🇬" },
      { code: "GH", name: "Ghana", dialCode: "+233", flag: "🇬🇭" },
      { code: "GI", name: "Gibraltar", dialCode: "+350", flag: "🇬🇮" },
      { code: "GL", name: "Greenland", dialCode: "+299", flag: "🇬🇱" },
      { code: "GM", name: "Gambia", dialCode: "+220", flag: "🇬🇲" },
      { code: "GN", name: "Guinea", dialCode: "+224", flag: "🇬🇳" },
      { code: "GP", name: "Guadeloupe", dialCode: "+590", flag: "🇬🇵" },
      { code: "GQ", name: "Equatorial Guinea", dialCode: "+240", flag: "🇬🇶" },
      { code: "GR", name: "Greece", dialCode: "+30", flag: "🇬🇷" },
      {
        code: "GS",
        name: "South Georgia and the South Sandwich Islands",
        dialCode: "+500",
        flag: "🇬🇸",
      },
      { code: "GT", name: "Guatemala", dialCode: "+502", flag: "🇬🇹" },
      { code: "GU", name: "Guam", dialCode: "+1", flag: "🇬🇺" },
      { code: "GW", name: "Guinea-Bissau", dialCode: "+245", flag: "🇬🇼" },
      { code: "GY", name: "Guyana", dialCode: "+592", flag: "🇬🇾" },
      { code: "HK", name: "Hong Kong", dialCode: "+852", flag: "🇭🇰" },
      {
        code: "HM",
        name: "Heard Island and McDonald Islands",
        dialCode: "+672",
        flag: "🇭🇲",
      },
      { code: "HN", name: "Honduras", dialCode: "+504", flag: "🇭🇳" },
      { code: "HR", name: "Croatia", dialCode: "+385", flag: "🇭🇷" },
      { code: "HT", name: "Haiti", dialCode: "+509", flag: "🇭🇹" },
      { code: "HU", name: "Hungary", dialCode: "+36", flag: "🇭🇺" },
      { code: "ID", name: "Indonesia", dialCode: "+62", flag: "🇮🇩" },
      { code: "IE", name: "Ireland", dialCode: "+353", flag: "🇮🇪" },
      { code: "IL", name: "Israel", dialCode: "+972", flag: "🇮🇱" },
      { code: "IM", name: "Isle of Man", dialCode: "+44", flag: "🇮🇲" },
      { code: "IN", name: "India", dialCode: "+91", flag: "🇮🇳" },
      {
        code: "IO",
        name: "British Indian Ocean Territory",
        dialCode: "+246",
        flag: "🇮🇴",
      },
      { code: "IQ", name: "Iraq", dialCode: "+964", flag: "🇮🇶" },
      { code: "IR", name: "Iran", dialCode: "+98", flag: "🇮🇷" },
      { code: "IS", name: "Iceland", dialCode: "+354", flag: "🇮🇸" },
      { code: "IT", name: "Italy", dialCode: "+39", flag: "🇮🇹" },
      { code: "JE", name: "Jersey", dialCode: "+44", flag: "🇯🇪" },
      { code: "JM", name: "Jamaica", dialCode: "+1", flag: "🇯🇲" },
      { code: "JO", name: "Jordan", dialCode: "+962", flag: "🇯🇴" },
      { code: "JP", name: "Japan", dialCode: "+81", flag: "🇯🇵" },
      { code: "KE", name: "Kenya", dialCode: "+254", flag: "🇰🇪" },
      { code: "KG", name: "Kyrgyzstan", dialCode: "+996", flag: "🇰🇬" },
      { code: "KH", name: "Cambodia", dialCode: "+855", flag: "🇰🇭" },
      { code: "KI", name: "Kiribati", dialCode: "+686", flag: "🇰🇮" },
      { code: "KM", name: "Comoros", dialCode: "+269", flag: "🇰🇲" },
      { code: "KN", name: "Saint Kitts and Nevis", dialCode: "+1", flag: "🇰🇳" },
      { code: "KP", name: "North Korea", dialCode: "+850", flag: "🇰🇵" },
      { code: "KR", name: "South Korea", dialCode: "+82", flag: "🇰🇷" },
      { code: "KW", name: "Kuwait", dialCode: "+965", flag: "🇰🇼" },
      { code: "KY", name: "Cayman Islands", dialCode: "+1", flag: "🇰🇾" },
      { code: "KZ", name: "Kazakhstan", dialCode: "+7", flag: "🇰🇿" },
      { code: "LA", name: "Laos", dialCode: "+856", flag: "🇱🇦" },
      { code: "LB", name: "Lebanon", dialCode: "+961", flag: "🇱🇧" },
      { code: "LC", name: "Saint Lucia", dialCode: "+1", flag: "🇱🇨" },
      { code: "LI", name: "Liechtenstein", dialCode: "+423", flag: "🇱🇮" },
      { code: "LK", name: "Sri Lanka", dialCode: "+94", flag: "🇱🇰" },
      { code: "LR", name: "Liberia", dialCode: "+231", flag: "🇱🇷" },
      { code: "LS", name: "Lesotho", dialCode: "+266", flag: "🇱🇸" },
      { code: "LT", name: "Lithuania", dialCode: "+370", flag: "🇱🇹" },
      { code: "LU", name: "Luxembourg", dialCode: "+352", flag: "🇱🇺" },
      { code: "LV", name: "Latvia", dialCode: "+371", flag: "🇱🇻" },
      { code: "LY", name: "Libya", dialCode: "+218", flag: "🇱🇾" },
      { code: "MA", name: "Morocco", dialCode: "+212", flag: "🇲🇦" },
      { code: "MC", name: "Monaco", dialCode: "+377", flag: "🇲🇨" },
      { code: "MD", name: "Moldova", dialCode: "+373", flag: "🇲🇩" },
      { code: "ME", name: "Montenegro", dialCode: "+382", flag: "🇲🇪" },
      { code: "MF", name: "Saint Martin", dialCode: "+590", flag: "🇲🇫" },
      { code: "MG", name: "Madagascar", dialCode: "+261", flag: "🇲🇬" },
      { code: "MH", name: "Marshall Islands", dialCode: "+692", flag: "🇲🇭" },
      { code: "MK", name: "North Macedonia", dialCode: "+389", flag: "🇲🇰" },
      { code: "ML", name: "Mali", dialCode: "+223", flag: "🇲🇱" },
      { code: "MM", name: "Myanmar", dialCode: "+95", flag: "🇲🇲" },
      { code: "MN", name: "Mongolia", dialCode: "+976", flag: "🇲🇳" },
      { code: "MO", name: "Macau", dialCode: "+853", flag: "🇲🇴" },
      {
        code: "MP",
        name: "Northern Mariana Islands",
        dialCode: "+1",
        flag: "🇲🇵",
      },
      { code: "MQ", name: "Martinique", dialCode: "+596", flag: "🇲🇶" },
      { code: "MR", name: "Mauritania", dialCode: "+222", flag: "🇲🇷" },
      { code: "MS", name: "Montserrat", dialCode: "+1", flag: "🇲🇸" },
      { code: "MT", name: "Malta", dialCode: "+356", flag: "🇲🇹" },
      { code: "MU", name: "Mauritius", dialCode: "+230", flag: "🇲🇺" },
      { code: "MV", name: "Maldives", dialCode: "+960", flag: "🇲🇻" },
      { code: "MW", name: "Malawi", dialCode: "+265", flag: "🇲🇼" },
      { code: "MX", name: "Mexico", dialCode: "+52", flag: "🇲🇽" },
      { code: "MY", name: "Malaysia", dialCode: "+60", flag: "🇲🇾" },
      { code: "MZ", name: "Mozambique", dialCode: "+258", flag: "🇲🇿" },
      { code: "NA", name: "Namibia", dialCode: "+264", flag: "🇳🇦" },
      { code: "NC", name: "New Caledonia", dialCode: "+687", flag: "🇳🇨" },
      { code: "NE", name: "Niger", dialCode: "+227", flag: "🇳🇪" },
      { code: "NF", name: "Norfolk Island", dialCode: "+672", flag: "🇳🇫" },
      { code: "NG", name: "Nigeria", dialCode: "+234", flag: "🇳🇬" },
      { code: "NI", name: "Nicaragua", dialCode: "+505", flag: "🇳🇮" },
      { code: "NL", name: "Netherlands", dialCode: "+31", flag: "🇳🇱" },
      { code: "NO", name: "Norway", dialCode: "+47", flag: "🇳🇴" },
      { code: "NP", name: "Nepal", dialCode: "+977", flag: "🇳🇵" },
      { code: "NR", name: "Nauru", dialCode: "+674", flag: "🇳🇷" },
      { code: "NU", name: "Niue", dialCode: "+683", flag: "🇳🇺" },
      { code: "NZ", name: "New Zealand", dialCode: "+64", flag: "🇳🇿" },
      { code: "OM", name: "Oman", dialCode: "+968", flag: "🇴🇲" },
      { code: "PA", name: "Panama", dialCode: "+507", flag: "🇵🇦" },
      { code: "PE", name: "Peru", dialCode: "+51", flag: "🇵🇪" },
      { code: "PF", name: "French Polynesia", dialCode: "+689", flag: "🇵🇫" },
      { code: "PG", name: "Papua New Guinea", dialCode: "+675", flag: "🇵🇬" },
      { code: "PH", name: "Philippines", dialCode: "+63", flag: "🇵🇭" },
      { code: "PK", name: "Pakistan", dialCode: "+92", flag: "🇵🇰" },
      { code: "PL", name: "Poland", dialCode: "+48", flag: "🇵🇱" },
      {
        code: "PM",
        name: "Saint Pierre and Miquelon",
        dialCode: "+508",
        flag: "🇵🇲",
      },
      { code: "PN", name: "Pitcairn Islands", dialCode: "+64", flag: "🇵🇳" },
      { code: "PR", name: "Puerto Rico", dialCode: "+1", flag: "🇵🇷" },
      { code: "PS", name: "Palestine", dialCode: "+970", flag: "🇵🇸" },
      { code: "PT", name: "Portugal", dialCode: "+351", flag: "🇵🇹" },
      { code: "PW", name: "Palau", dialCode: "+680", flag: "🇵🇼" },
      { code: "PY", name: "Paraguay", dialCode: "+595", flag: "🇵🇾" },
      { code: "QA", name: "Qatar", dialCode: "+974", flag: "🇶🇦" },
      { code: "RE", name: "Réunion", dialCode: "+262", flag: "🇷🇪" },
      { code: "RO", name: "Romania", dialCode: "+40", flag: "🇷🇴" },
      { code: "RS", name: "Serbia", dialCode: "+381", flag: "🇷🇸" },
      { code: "RU", name: "Russia", dialCode: "+7", flag: "🇷🇺" },
      { code: "RW", name: "Rwanda", dialCode: "+250", flag: "🇷🇼" },
      { code: "SA", name: "Saudi Arabia", dialCode: "+966", flag: "🇸🇦" },
      { code: "SB", name: "Solomon Islands", dialCode: "+677", flag: "🇸🇧" },
      { code: "SC", name: "Seychelles", dialCode: "+248", flag: "🇸🇨" },
      { code: "SD", name: "Sudan", dialCode: "+249", flag: "🇸🇩" },
      { code: "SE", name: "Sweden", dialCode: "+46", flag: "🇸🇪" },
      { code: "SG", name: "Singapore", dialCode: "+65", flag: "🇸🇬" },
      { code: "SH", name: "Saint Helena", dialCode: "+290", flag: "🇸🇭" },
      { code: "SI", name: "Slovenia", dialCode: "+386", flag: "🇸🇮" },
      {
        code: "SJ",
        name: "Svalbard and Jan Mayen",
        dialCode: "+47",
        flag: "🇸🇯",
      },
      { code: "SK", name: "Slovakia", dialCode: "+421", flag: "🇸🇰" },
      { code: "SL", name: "Sierra Leone", dialCode: "+232", flag: "🇸🇱" },
      { code: "SM", name: "San Marino", dialCode: "+378", flag: "🇸🇲" },
      { code: "SN", name: "Senegal", dialCode: "+221", flag: "🇸🇳" },
      { code: "SO", name: "Somalia", dialCode: "+252", flag: "🇸🇴" },
      { code: "SR", name: "Suriname", dialCode: "+597", flag: "🇸🇷" },
      { code: "SS", name: "South Sudan", dialCode: "+211", flag: "🇸🇸" },
      {
        code: "ST",
        name: "São Tomé and Príncipe",
        dialCode: "+239",
        flag: "🇸🇹",
      },
      { code: "SV", name: "El Salvador", dialCode: "+503", flag: "🇸🇻" },
      { code: "SX", name: "Sint Maarten", dialCode: "+1", flag: "🇸🇽" },
      { code: "SY", name: "Syria", dialCode: "+963", flag: "🇸🇾" },
      { code: "SZ", name: "Eswatini", dialCode: "+268", flag: "🇸🇿" },
      {
        code: "TC",
        name: "Turks and Caicos Islands",
        dialCode: "+1",
        flag: "🇹🇨",
      },
      { code: "TD", name: "Chad", dialCode: "+235", flag: "🇹🇩" },
      {
        code: "TF",
        name: "French Southern and Antarctic Lands",
        dialCode: "+262",
        flag: "🇹🇫",
      },
      { code: "TG", name: "Togo", dialCode: "+228", flag: "🇹🇬" },
      { code: "TH", name: "Thailand", dialCode: "+66", flag: "🇹🇭" },
      { code: "TJ", name: "Tajikistan", dialCode: "+992", flag: "🇹🇯" },
      { code: "TK", name: "Tokelau", dialCode: "+690", flag: "🇹🇰" },
      { code: "TL", name: "East Timor", dialCode: "+670", flag: "🇹🇱" },
      { code: "TM", name: "Turkmenistan", dialCode: "+993", flag: "🇹🇲" },
      { code: "TN", name: "Tunisia", dialCode: "+216", flag: "🇹🇳" },
      { code: "TO", name: "Tonga", dialCode: "+676", flag: "🇹🇴" },
      { code: "TR", name: "Turkey", dialCode: "+90", flag: "🇹🇷" },
      { code: "TT", name: "Trinidad and Tobago", dialCode: "+1", flag: "🇹🇹" },
      { code: "TV", name: "Tuvalu", dialCode: "+688", flag: "🇹🇻" },
      { code: "TW", name: "Taiwan", dialCode: "+886", flag: "🇹🇼" },
      { code: "TZ", name: "Tanzania", dialCode: "+255", flag: "🇹🇿" },
      { code: "UA", name: "Ukraine", dialCode: "+380", flag: "🇺🇦" },
      { code: "UG", name: "Uganda", dialCode: "+256", flag: "🇺🇬" },
      {
        code: "UM",
        name: "United States Minor Outlying Islands",
        dialCode: "+1",
        flag: "🇺🇲",
      },
      { code: "US", name: "United States", dialCode: "+1", flag: "🇺🇸" },
      { code: "UY", name: "Uruguay", dialCode: "+598", flag: "🇺🇾" },
      { code: "UZ", name: "Uzbekistan", dialCode: "+998", flag: "🇺🇿" },
      { code: "VA", name: "Vatican City", dialCode: "+39", flag: "🇻🇦" },
      {
        code: "VC",
        name: "Saint Vincent and the Grenadines",
        dialCode: "+1",
        flag: "🇻🇨",
      },
      { code: "VE", name: "Venezuela", dialCode: "+58", flag: "🇻🇪" },
      {
        code: "VG",
        name: "British Virgin Islands",
        dialCode: "+1",
        flag: "🇻🇬",
      },
      { code: "VI", name: "U.S. Virgin Islands", dialCode: "+1", flag: "🇻🇮" },
      { code: "VN", name: "Vietnam", dialCode: "+84", flag: "🇻🇳" },
      { code: "VU", name: "Vanuatu", dialCode: "+678", flag: "🇻🇺" },
      { code: "WF", name: "Wallis and Futuna", dialCode: "+681", flag: "🇼🇫" },
      { code: "WS", name: "Samoa", dialCode: "+685", flag: "🇼🇸" },
      { code: "YE", name: "Yemen", dialCode: "+967", flag: "🇾🇪" },
      { code: "YT", name: "Mayotte", dialCode: "+262", flag: "🇾🇹" },
      { code: "ZA", name: "South Africa", dialCode: "+27", flag: "🇿🇦" },
      { code: "ZM", name: "Zambia", dialCode: "+260", flag: "🇿🇲" },
      { code: "ZW", name: "Zimbabwe", dialCode: "+263", flag: "🇿🇼" },
    ];

    // Sort countries by name
    countries.sort((a, b) => a.name.localeCompare(b.name));

    countries.forEach((country) => {
      const option = document.createElement("option");
      option.value = country.dialCode;
      option.textContent = `${country.flag} ${country.dialCode}`;
      option.dataset.countryCode = country.code;
      select.appendChild(option);
    });

    // Set default country based on user location
    if (this.userLocation && this.userLocation.country_code) {
      const defaultCountry = countries.find(
        (c) =>
          c.code.toLowerCase() === this.userLocation.country_code.toLowerCase()
      );
      if (defaultCountry) {
        select.value = defaultCountry.dialCode;
      }
    } else {
      // Default to UK if no location detected
      select.value = "+44";
    }
  }
    
  populateCountrySelect() {
    const select = document.getElementById("country");
    if (!select) return;

    // Clear existing options
    select.innerHTML = "";

    // Add all countries from react-select-country-list
    const countries = [
      { value: "AF", label: "Afghanistan" },
      { value: "AL", label: "Albania" },
      { value: "DZ", label: "Algeria" },
      { value: "AS", label: "American Samoa" },
      { value: "AD", label: "Andorra" },
      { value: "AO", label: "Angola" },
      { value: "AI", label: "Anguilla" },
      { value: "AQ", label: "Antarctica" },
      { value: "AG", label: "Antigua and Barbuda" },
      { value: "AR", label: "Argentina" },
      { value: "AM", label: "Armenia" },
      { value: "AW", label: "Aruba" },
      { value: "AU", label: "Australia" },
      { value: "AT", label: "Austria" },
      { value: "AZ", label: "Azerbaijan" },
      { value: "BS", label: "Bahamas" },
      { value: "BH", label: "Bahrain" },
      { value: "BD", label: "Bangladesh" },
      { value: "BB", label: "Barbados" },
      { value: "BY", label: "Belarus" },
      { value: "BE", label: "Belgium" },
      { value: "BZ", label: "Belize" },
      { value: "BJ", label: "Benin" },
      { value: "BM", label: "Bermuda" },
      { value: "BT", label: "Bhutan" },
      { value: "BO", label: "Bolivia" },
      { value: "BA", label: "Bosnia and Herzegovina" },
      { value: "BW", label: "Botswana" },
      { value: "BV", label: "Bouvet Island" },
      { value: "BR", label: "Brazil" },
      { value: "IO", label: "British Indian Ocean Territory" },
      { value: "BN", label: "Brunei Darussalam" },
      { value: "BG", label: "Bulgaria" },
      { value: "BF", label: "Burkina Faso" },
      { value: "BI", label: "Burundi" },
      { value: "KH", label: "Cambodia" },
      { value: "CM", label: "Cameroon" },
      { value: "CA", label: "Canada" },
      { value: "CV", label: "Cape Verde" },
      { value: "KY", label: "Cayman Islands" },
      { value: "CF", label: "Central African Republic" },
      { value: "TD", label: "Chad" },
      { value: "CL", label: "Chile" },
      { value: "CN", label: "China" },
      { value: "CX", label: "Christmas Island" },
      { value: "CC", label: "Cocos (Keeling) Islands" },
      { value: "CO", label: "Colombia" },
      { value: "KM", label: "Comoros" },
      { value: "CG", label: "Congo" },
      { value: "CD", label: "Congo, Democratic Republic of the" },
      { value: "CK", label: "Cook Islands" },
      { value: "CR", label: "Costa Rica" },
      { value: "CI", label: "Côte d'Ivoire" },
      { value: "HR", label: "Croatia" },
      { value: "CU", label: "Cuba" },
      { value: "CY", label: "Cyprus" },
      { value: "CZ", label: "Czech Republic" },
      { value: "DK", label: "Denmark" },
      { value: "DJ", label: "Djibouti" },
      { value: "DM", label: "Dominica" },
      { value: "DO", label: "Dominican Republic" },
      { value: "EC", label: "Ecuador" },
      { value: "EG", label: "Egypt" },
      { value: "SV", label: "El Salvador" },
      { value: "GQ", label: "Equatorial Guinea" },
      { value: "ER", label: "Eritrea" },
      { value: "EE", label: "Estonia" },
      { value: "ET", label: "Ethiopia" },
      { value: "FK", label: "Falkland Islands (Malvinas)" },
      { value: "FO", label: "Faroe Islands" },
      { value: "FJ", label: "Fiji" },
      { value: "FI", label: "Finland" },
      { value: "FR", label: "France" },
      { value: "GF", label: "French Guiana" },
      { value: "PF", label: "French Polynesia" },
      { value: "TF", label: "French Southern Territories" },
      { value: "GA", label: "Gabon" },
      { value: "GM", label: "Gambia" },
      { value: "GE", label: "Georgia" },
      { value: "DE", label: "Germany" },
      { value: "GH", label: "Ghana" },
      { value: "GI", label: "Gibraltar" },
      { value: "GR", label: "Greece" },
      { value: "GL", label: "Greenland" },
      { value: "GD", label: "Grenada" },
      { value: "GP", label: "Guadeloupe" },
      { value: "GU", label: "Guam" },
      { value: "GT", label: "Guatemala" },
      { value: "GG", label: "Guernsey" },
      { value: "GN", label: "Guinea" },
      { value: "GW", label: "Guinea-Bissau" },
      { value: "GY", label: "Guyana" },
      { value: "HT", label: "Haiti" },
      { value: "HM", label: "Heard Island and McDonald Islands" },
      { value: "VA", label: "Holy See (Vatican City State)" },
      { value: "HN", label: "Honduras" },
      { value: "HK", label: "Hong Kong" },
      { value: "HU", label: "Hungary" },
      { value: "IS", label: "Iceland" },
      { value: "IN", label: "India" },
      { value: "ID", label: "Indonesia" },
      { value: "IR", label: "Iran, Islamic Republic of" },
      { value: "IQ", label: "Iraq" },
      { value: "IE", label: "Ireland" },
      { value: "IM", label: "Isle of Man" },
      { value: "IL", label: "Israel" },
      { value: "IT", label: "Italy" },
      { value: "JM", label: "Jamaica" },
      { value: "JP", label: "Japan" },
      { value: "JE", label: "Jersey" },
      { value: "JO", label: "Jordan" },
      { value: "KZ", label: "Kazakhstan" },
      { value: "KE", label: "Kenya" },
      { value: "KI", label: "Kiribati" },
      { value: "KP", label: "Korea, Democratic People's Republic of" },
      { value: "KR", label: "Korea, Republic of" },
      { value: "KW", label: "Kuwait" },
      { value: "KG", label: "Kyrgyzstan" },
      { value: "LA", label: "Lao People's Democratic Republic" },
      { value: "LV", label: "Latvia" },
      { value: "LB", label: "Lebanon" },
      { value: "LS", label: "Lesotho" },
      { value: "LR", label: "Liberia" },
      { value: "LY", label: "Libya" },
      { value: "LI", label: "Liechtenstein" },
      { value: "LT", label: "Lithuania" },
      { value: "LU", label: "Luxembourg" },
      { value: "MO", label: "Macao" },
      { value: "MK", label: "Macedonia, the former Yugoslav Republic of" },
      { value: "MG", label: "Madagascar" },
      { value: "MW", label: "Malawi" },
      { value: "MY", label: "Malaysia" },
      { value: "MV", label: "Maldives" },
      { value: "ML", label: "Mali" },
      { value: "MT", label: "Malta" },
      { value: "MH", label: "Marshall Islands" },
      { value: "MQ", label: "Martinique" },
      { value: "MR", label: "Mauritania" },
      { value: "MU", label: "Mauritius" },
      { value: "YT", label: "Mayotte" },
      { value: "MX", label: "Mexico" },
      { value: "FM", label: "Micronesia, Federated States of" },
      { value: "MD", label: "Moldova, Republic of" },
      { value: "MC", label: "Monaco" },
      { value: "MN", label: "Mongolia" },
      { value: "ME", label: "Montenegro" },
      { value: "MS", label: "Montserrat" },
      { value: "MA", label: "Morocco" },
      { value: "MZ", label: "Mozambique" },
      { value: "MM", label: "Myanmar" },
      { value: "NA", label: "Namibia" },
      { value: "NR", label: "Nauru" },
      { value: "NP", label: "Nepal" },
      { value: "NL", label: "Netherlands" },
      { value: "NC", label: "New Caledonia" },
      { value: "NZ", label: "New Zealand" },
      { value: "NI", label: "Nicaragua" },
      { value: "NE", label: "Niger" },
      { value: "NG", label: "Nigeria" },
      { value: "NU", label: "Niue" },
      { value: "NF", label: "Norfolk Island" },
      { value: "MP", label: "Northern Mariana Islands" },
      { value: "NO", label: "Norway" },
      { value: "OM", label: "Oman" },
      { value: "PK", label: "Pakistan" },
      { value: "PW", label: "Palau" },
      { value: "PS", label: "Palestinian Territory, Occupied" },
      { value: "PA", label: "Panama" },
      { value: "PG", label: "Papua New Guinea" },
      { value: "PY", label: "Paraguay" },
      { value: "PE", label: "Peru" },
      { value: "PH", label: "Philippines" },
      { value: "PN", label: "Pitcairn" },
      { value: "PL", label: "Poland" },
      { value: "PT", label: "Portugal" },
      { value: "PR", label: "Puerto Rico" },
      { value: "QA", label: "Qatar" },
      { value: "RE", label: "Réunion" },
      { value: "RO", label: "Romania" },
      { value: "RU", label: "Russian Federation" },
      { value: "RW", label: "Rwanda" },
      { value: "BL", label: "Saint Barthélemy" },
      { value: "SH", label: "Saint Helena, Ascension and Tristan da Cunha" },
      { value: "KN", label: "Saint Kitts and Nevis" },
      { value: "LC", label: "Saint Lucia" },
      { value: "MF", label: "Saint Martin (French part)" },
      { value: "PM", label: "Saint Pierre and Miquelon" },
      { value: "VC", label: "Saint Vincent and the Grenadines" },
      { value: "WS", label: "Samoa" },
      { value: "SM", label: "San Marino" },
      { value: "ST", label: "Sao Tome and Principe" },
      { value: "SA", label: "Saudi Arabia" },
      { value: "SN", label: "Senegal" },
      { value: "RS", label: "Serbia" },
      { value: "SC", label: "Seychelles" },
      { value: "SL", label: "Sierra Leone" },
      { value: "SG", label: "Singapore" },
      { value: "SX", label: "Sint Maarten (Dutch part)" },
      { value: "SK", label: "Slovakia" },
      { value: "SI", label: "Slovenia" },
      { value: "SB", label: "Solomon Islands" },
      { value: "SO", label: "Somalia" },
      { value: "ZA", label: "South Africa" },
      { value: "GS", label: "South Georgia and the South Sandwich Islands" },
      { value: "SS", label: "South Sudan" },
      { value: "ES", label: "Spain" },
      { value: "LK", label: "Sri Lanka" },
      { value: "SD", label: "Sudan" },
      { value: "SR", label: "Suriname" },
      { value: "SJ", label: "Svalbard and Jan Mayen" },
      { value: "SZ", label: "Swaziland" },
      { value: "SE", label: "Sweden" },
      { value: "CH", label: "Switzerland" },
      { value: "SY", label: "Syrian Arab Republic" },
      { value: "TW", label: "Taiwan, Province of China" },
      { value: "TJ", label: "Tajikistan" },
      { value: "TZ", label: "Tanzania, United Republic of" },
      { value: "TH", label: "Thailand" },
      { value: "TL", label: "Timor-Leste" },
      { value: "TG", label: "Togo" },
      { value: "TK", label: "Tokelau" },
      { value: "TO", label: "Tonga" },
      { value: "TT", label: "Trinidad and Tobago" },
      { value: "TN", label: "Tunisia" },
      { value: "TR", label: "Turkey" },
      { value: "TM", label: "Turkmenistan" },
      { value: "TC", label: "Turks and Caicos Islands" },
      { value: "TV", label: "Tuvalu" },
      { value: "UG", label: "Uganda" },
      { value: "UA", label: "Ukraine" },
      { value: "AE", label: "United Arab Emirates" },
      { value: "GB", label: "United Kingdom" },
      { value: "US", label: "United States" },
      { value: "UM", label: "United States Minor Outlying Islands" },
      { value: "UY", label: "Uruguay" },
      { value: "UZ", label: "Uzbekistan" },
      { value: "VU", label: "Vanuatu" },
      { value: "VE", label: "Venezuela, Bolivarian Republic of" },
      { value: "VN", label: "Viet Nam" },
      { value: "VG", label: "Virgin Islands, British" },
      { value: "VI", label: "Virgin Islands, U.S." },
      { value: "WF", label: "Wallis and Futuna" },
      { value: "EH", label: "Western Sahara" },
      { value: "YE", label: "Yemen" },
      { value: "ZM", label: "Zambia" },
      { value: "ZW", label: "Zimbabwe" },
    ];

    // Sort countries alphabetically by label
    countries.sort((a, b) => a.label.localeCompare(b.label));

    // Add countries to select
    countries.forEach((country) => {
      const option = document.createElement("option");
      option.value = country.label;
      option.textContent = country.label;
      select.appendChild(option);
    });

    // Set default country based on user location
    if (this.userLocation && this.userLocation.country_code) {
      const countryCode = this.userLocation.country_code.toUpperCase();
      const defaultCountry = countries.find((c) => c.value === countryCode);
      if (defaultCountry) {
        select.value = defaultCountry.label;
      }
    } else {
      // Default to United Kingdom
      select.value = "United Kingdom";
    }
  }

  updateGiftAidVisibility() {
    const giftAidSection = document.getElementById("gift-aid-section");
    const countrySelect = document.getElementById("country");
    if (!giftAidSection || !countrySelect) return;

    // Check if UK is selected in the country dropdown
    const selectedCountry = countrySelect.value;
    const isUK = selectedCountry === "United Kingdom";

    // Show Gift Aid section only for UK users
    giftAidSection.style.display = isUK ? "block" : "none";
  }

  async initializeStripe() {
    try {
      // Get publishable key from environment or config
      const publishableKey = "pk_test_51I0kvfIOA3YxcRKLAQOiZyjG1UWossfPW6yIs5M365JWpMGiO3SukOwHkuV51oqP05dRkTPwRvHb2Eyo97aoRxy400KbThrniu";
      
      // Get client_secret from the payment intent response stored in separate variable
      const clientSecret = this.paymentIntentResponse?.client_secret;
      console.log("🚀 ~ DonationWidget ~ initializeStripe ~ paymentIntentResponse:", this.paymentIntentResponse);
      console.log("🚀 ~ DonationWidget ~ initializeStripe ~ clientSecret:", clientSecret);
      
      if (!publishableKey || !clientSecret) {
        throw new Error("Missing Stripe credentials");
      }

      const amount =
        this.donationData.type === "multi"
          ? this.donationData.multiDonations.reduce(
              (sum, d) => sum + d.amount,
              0
            )
          : this.donationData.amount;

      const fees = this.donationData.coverFees ? this.calculateFees(amount) : 0;
      const totalAmount = amount + fees;

      await window.initializeStripe(publishableKey, clientSecret, {
        amount: totalAmount,
        currency: this.donationData.currency,
      });
    } catch (error) {
      console.error("Failed to initialize Stripe:", error);
      this.showError("Failed to initialize payment. Please try again.");
    }
  }

  async submitPayment() {
    try {
      this.showLoading("Processing payment...");
      
      // Use the global Stripe confirmation function
      const success = await window.confirmStripePayment();
      
      if (success) {
        // Payment successful - show confirmation
        this.showStep(4);
        this.updateConfirmationDetails();
      } else {
        this.showError("Payment failed. Please try again.");
      }
    } catch (error) {
      console.error("Payment submission failed:", error);
      this.showError("Payment failed. Please try again.");
    } finally {
      this.hideLoading();
    }
  }

  updateConfirmationDetails() {
    // Update confirmation page with donation details
    const confirmationName = document.getElementById('confirmation-name');
    const confirmationEmail = document.getElementById('confirmation-email');
    const confirmationCampaign = document.getElementById('confirmation-campaign');
    const confirmationType = document.getElementById('confirmation-type');
    const confirmationDate = document.getElementById('confirmation-date');
    const confirmationTotal = document.getElementById('confirmation-total');

    if (confirmationName) {
      confirmationName.textContent = `${this.donationData.personalInfo.firstName} ${this.donationData.personalInfo.lastName}`;
    }

    if (confirmationEmail) {
      confirmationEmail.textContent = this.donationData.personalInfo.email;
    }

    if (confirmationCampaign) {
      const selectedCampaign = this.campaigns.find(
        c => c.campaign_id.toString() === this.donationData.selectedCampaignId
      );
      confirmationCampaign.textContent = selectedCampaign ? selectedCampaign.title : "General Donation";
    }

    if (confirmationType) {
      const typeMap = {
        "once": "One-off Donation",
        "multi": "Multi Donation",
        "recurring": "Recurring Donation"
      };
      confirmationType.textContent = typeMap[this.donationData.type] || "Donation";
    }

    if (confirmationDate) {
      confirmationDate.textContent = new Date().toLocaleDateString('en-GB', {
        day: 'numeric',
        month: 'short',
        year: 'numeric'
      });
    }

    if (confirmationTotal) {
      const amount = this.donationData.type === "multi"
        ? this.donationData.multiDonations.reduce((sum, d) => sum + d.amount, 0)
        : this.donationData.amount;
      
      const fees = this.donationData.coverFees ? this.calculateFees(amount) : 0;
      const totalAmount = amount + fees;
      
      const symbol = this.getCurrencySymbol(this.donationData.currency);
      confirmationTotal.textContent = `${symbol}${totalAmount.toFixed(2)}`;
    }
  }

  async handlePaymentCompletion(paymentIntent, redirectStatus) {
    try {
      console.log("🚀 ~ DonationWidget ~ handlePaymentCompletion ~ paymentIntent:", paymentIntent);
      console.log("🚀 ~ DonationWidget ~ handlePaymentCompletion ~ redirectStatus:", redirectStatus);
      
      // Load campaigns first (needed for confirmation page)
      await this.loadCampaigns();
      
      // Fetch payment details
      const paymentDetails = await this.getPaymentDetails(paymentIntent);
      
      if (paymentDetails) {
        // Store payment details
        this.paymentDetails = paymentDetails;
        
        // Show confirmation page
        this.showStep(4);
        this.updateConfirmationDetailsFromPaymentDetails();
      } else {
        throw new Error("Failed to fetch payment details");
      }
    } catch (error) {
      console.error("Payment completion handling failed:", error);
      this.showError("Failed to load payment confirmation. Please try again.");
    } finally {
      this.hideLoading();
    }
  }

  async getPaymentDetails(paymentIntentId) {
    try {
      const response = await this.apiCall(`/donations/payment-intent/${paymentIntentId}`);
      return response.data;
    } catch (error) {
      console.error("Failed to fetch payment details:", error);
      throw error;
    }
  }

  updateConfirmationDetailsFromPaymentDetails() {
    if (!this.paymentDetails) return;

    const paymentIntent = this.paymentDetails.paymentIntent;
    const paymentMethod = this.paymentDetails.paymentMethod;
    const metadata = paymentIntent.metadata;

    // Update confirmation page with payment details
    const confirmationName = document.getElementById('confirmation-name');
    const confirmationEmail = document.getElementById('confirmation-email');
    const confirmationCampaign = document.getElementById('confirmation-campaign');
    const confirmationType = document.getElementById('confirmation-type');
    const confirmationDate = document.getElementById('confirmation-date');
    const confirmationPaymentMethod = document.getElementById('confirmation-payment-method');
    const confirmationTotal = document.getElementById('confirmation-total');

    if (confirmationName) {
      confirmationName.textContent = `${metadata.first_name} ${metadata.last_name}`;
    }

    if (confirmationEmail) {
      confirmationEmail.textContent = metadata.email;
    }

    if (confirmationCampaign) {
      confirmationCampaign.textContent = paymentIntent.description || "General Donation";
    }

    if (confirmationType) {
      const typeMap = {
        "1": "One-off Donation",
        "2": "Multiple Donations",
        "3": metadata.frequency === "1" ? "Weekly" : 
             metadata.frequency === "2" ? "Monthly" : 
             metadata.frequency === "3" ? "Quarterly" : 
             metadata.frequency === "4" ? "Yearly" : "Recurring Donation"
      };
      confirmationType.textContent = typeMap[metadata.type] || "Donation";
    }

    if (confirmationDate) {
      const created = paymentIntent.created;
      const isSeconds = created < 10000000000;
      const timestamp = isSeconds ? created * 1000 : created;
      const date = new Date(timestamp);
      
      confirmationDate.textContent = date.toLocaleDateString('en-GB', {
        day: 'numeric',
        month: 'short',
        year: 'numeric'
      });
    }

    if (confirmationPaymentMethod && paymentMethod) {
      let paymentMethodText = "";
      if (paymentMethod.type === "card") {
        if (paymentMethod.card.wallet) {
          paymentMethodText = paymentMethod.card.wallet.type;
        } else {
          paymentMethodText = `${paymentMethod.card.funding} card`;
        }
      } else {
        paymentMethodText = paymentMethod.type;
      }
      confirmationPaymentMethod.textContent = paymentMethodText.replace("_", " ");
    }

    if (confirmationTotal) {
      const amount = paymentIntent.amount / 100; // Convert from cents
      const currency = paymentIntent.currency.toUpperCase();
      const symbol = this.getCurrencySymbol(currency);
      confirmationTotal.textContent = `${symbol}${amount.toFixed(2)}`;
    }
  }

  setupConfirmationEventListeners() {
    console.log("🚀 ~ Setting up confirmation event listeners");
    
    // Remove existing event listeners to avoid duplicates
    const shareBtn = document.getElementById("share-btn");
    const homeBtn = document.getElementById("home-btn");
    const closeModalBtn = document.getElementById("close-share-modal");
    
    if (shareBtn) {
      // Remove existing listeners
      shareBtn.replaceWith(shareBtn.cloneNode(true));
      // Add new listener
      document.getElementById("share-btn").addEventListener("click", () => {
        console.log("🚀 ~ Share button clicked from confirmation setup!");
        this.showShareModal();
      });
    }
    
    if (homeBtn) {
      homeBtn.replaceWith(homeBtn.cloneNode(true));
      document.getElementById("home-btn").addEventListener("click", () => {
        this.goHome();
      });
    }
    
    if (closeModalBtn) {
      closeModalBtn.replaceWith(closeModalBtn.cloneNode(true));
      document.getElementById("close-share-modal").addEventListener("click", () => {
        this.hideShareModal();
      });
    }
    
    // Social share buttons
    document.querySelectorAll(".social-btn").forEach((btn) => {
      btn.replaceWith(btn.cloneNode(true));
    });
    
    document.querySelectorAll(".social-btn").forEach((btn) => {
      btn.addEventListener("click", (e) => {
        this.shareOnSocial(e.target.dataset.platform);
      });
    });
  }

  showShareModal() {
    const modal = document.getElementById('share-modal');
    if (modal) {
      modal.style.display = 'flex';
    } else {
      console.error("Share modal element not found!");
    }
  }

  hideShareModal() {
    const modal = document.getElementById('share-modal');
    if (modal) {
      modal.style.display = 'none';
    }
  }

  shareOnSocial(platform) {
    const shareData = this.generateShareData();
    
    const shareLinks = {
      whatsapp: `https://api.whatsapp.com/send?text=${encodeURIComponent(shareData.text)}`,
      facebook: `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareData.url)}`,
      twitter: `https://twitter.com/intent/tweet?text=${encodeURIComponent(shareData.text)}`,
      linkedin: `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(shareData.url)}`,
      email: `mailto:?subject=${encodeURIComponent(shareData.subject)}&body=${encodeURIComponent(shareData.text)}`
    };

    const url = shareLinks[platform];
    if (url) {
      if (platform === 'email') {
        window.location.href = url;
      } else {
        window.open(url, '_blank', 'width=600,height=500,scrollbars=yes,resizable=yes');
      }
    }
    
    this.hideShareModal();
  }

  generateShareData() {
    let campaignTitle = "General Donation";
    let campaignDescription = "Support our cause with a donation";
    let campaignUrl = window.location.origin;

    // Get campaign data from payment details or current selection
    if (this.paymentDetails && this.paymentDetails.paymentIntent) {
      const paymentIntent = this.paymentDetails.paymentIntent;
      campaignTitle = paymentIntent.description || "General Donation";
      
      // Try to get campaign from metadata
      if (paymentIntent.metadata && paymentIntent.metadata.campaign_id) {
        const campaignId = paymentIntent.metadata.campaign_id;
        const campaign = this.campaigns.find(c => c.campaign_id.toString() === campaignId.toString());
        if (campaign) {
          campaignTitle = campaign.title;
          campaignDescription = campaign.description || campaignTitle;
          campaignUrl = `${window.location.origin}/?id=${campaign.campaign_id}&name=${campaign.title.replace(/\s+/g, "-")}`;
        }
      }
    } else if (this.donationData.selectedCampaignId) {
      const campaign = this.campaigns.find(c => c.campaign_id.toString() === this.donationData.selectedCampaignId);
      if (campaign) {
        campaignTitle = campaign.title;
        campaignDescription = campaign.description || campaignTitle;
        campaignUrl = `${window.location.origin}/?id=${campaign.campaign_id}&name=${campaign.title.replace(/\s+/g, "-")}`;
      }
    }

    const text = `Please donate to ${campaignTitle} campaign. ${campaignDescription} ${campaignUrl}`;
    const subject = campaignTitle;

    return {
      text,
      subject,
      url: campaignUrl
    };
  }

  // Campaign Field Management Functions
  renderCampaignFields() {
    const campaignFieldsContainer = document.getElementById("campaign-fields");
    if (!campaignFieldsContainer) return;

    const selectedCampaign = this.campaigns.find(
      (campaign) => campaign.campaign_id.toString() === this.donationData.selectedCampaignId
    );

    if (!selectedCampaign || !selectedCampaign.campaign_fields || selectedCampaign.campaign_fields.length === 0) {
      campaignFieldsContainer.style.display = "none";
      return;
    }

    campaignFieldsContainer.style.display = "block";
    campaignFieldsContainer.innerHTML = "";

    selectedCampaign.campaign_fields.forEach((field) => {
      const fieldContainer = document.createElement("div");
      fieldContainer.className = "campaign-field";
      fieldContainer.innerHTML = `
        <div class="campaign-field-header">
          <label class="campaign-field-label">${field.title}</label>
          ${!field.is_single_field ? `
            <button type="button" class="add-field-btn" onclick="app.addFieldInput('${field.campaign_field_id}')">
              +
            </button>
          ` : ''}
        </div>
        <div class="campaign-field-inputs" id="field-${field.campaign_field_id}">
          <!-- Field inputs will be added here -->
        </div>
      `;
      campaignFieldsContainer.appendChild(fieldContainer);

      // Initialize with one empty field
      this.addFieldInput(field.campaign_field_id.toString());
    });
  }

  addFieldInput(fieldId) {
    const fieldContainer = document.getElementById(`field-${fieldId}`);
    if (!fieldContainer) return;

    const fieldIndex = fieldContainer.children.length;
    const fieldInput = document.createElement("div");
    fieldInput.className = "field-input-group";
    fieldInput.innerHTML = `
      <input 
        type="text" 
        class="field-input" 
        placeholder="Enter ${this.getFieldTitle(fieldId)} ${fieldIndex + 1}"
        data-field-id="${fieldId}"
        data-field-index="${fieldIndex}"
        onchange="app.updateFieldValue('${fieldId}', ${fieldIndex}, this.value)"
        onblur="app.validateField('${fieldId}', ${fieldIndex}, this.value)"
      />
      ${fieldContainer.children.length > 0 ? `
        <button type="button" class="remove-field-btn" onclick="app.removeFieldInput('${fieldId}', ${fieldIndex})">
          ×
        </button>
      ` : ''}
    `;

    fieldContainer.appendChild(fieldInput);

    // Update the campaignFieldValues
    if (!this.donationData.campaignFieldValues[fieldId]) {
      this.donationData.campaignFieldValues[fieldId] = [];
    }
    this.donationData.campaignFieldValues[fieldId].push("");
  }

  removeFieldInput(fieldId, fieldIndex) {
    const fieldContainer = document.getElementById(`field-${fieldId}`);
    if (!fieldContainer || fieldContainer.children.length <= 1) return;

    // Remove from DOM
    const fieldInput = fieldContainer.children[fieldIndex];
    if (fieldInput) {
      fieldInput.remove();
    }

    // Update the campaignFieldValues
    if (this.donationData.campaignFieldValues[fieldId]) {
      this.donationData.campaignFieldValues[fieldId].splice(fieldIndex, 1);
    }

    // Re-index remaining fields
    this.reindexFieldInputs(fieldId);
  }

  reindexFieldInputs(fieldId) {
    const fieldContainer = document.getElementById(`field-${fieldId}`);
    if (!fieldContainer) return;

    Array.from(fieldContainer.children).forEach((fieldInput, index) => {
      const input = fieldInput.querySelector('.field-input');
      const removeBtn = fieldInput.querySelector('.remove-field-btn');
      
      if (input) {
        input.setAttribute('data-field-index', index);
        input.setAttribute('onchange', `app.updateFieldValue('${fieldId}', ${index}, this.value)`);
        input.setAttribute('onblur', `app.validateField('${fieldId}', ${index}, this.value)`);
        input.placeholder = `Enter ${this.getFieldTitle(fieldId)} ${index + 1}`;
      }
      
      if (removeBtn) {
        removeBtn.setAttribute('onclick', `app.removeFieldInput('${fieldId}', ${index})`);
      }
    });
  }

  updateFieldValue(fieldId, fieldIndex, value) {
    if (!this.donationData.campaignFieldValues[fieldId]) {
      this.donationData.campaignFieldValues[fieldId] = [];
    }
    this.donationData.campaignFieldValues[fieldId][fieldIndex] = value;
  }

  validateField(fieldId, fieldIndex, value) {
    // Basic validation - can be extended
    const error = value.trim() === "" ? "This field is required" : "";
    
    // You can add error display logic here
    const fieldInput = document.querySelector(`[data-field-id="${fieldId}"][data-field-index="${fieldIndex}"]`);
    if (fieldInput) {
      if (error) {
        fieldInput.classList.add('error');
      } else {
        fieldInput.classList.remove('error');
      }
    }
    
    return error;
  }

  getFieldTitle(fieldId) {
    const selectedCampaign = this.campaigns.find(
      (campaign) => campaign.campaign_id.toString() === this.donationData.selectedCampaignId
    );
    
    if (selectedCampaign && selectedCampaign.campaign_fields) {
      const field = selectedCampaign.campaign_fields.find(
        (f) => f.campaign_field_id.toString() === fieldId
      );
      return field ? field.title : "Field";
    }
    return "Field";
  }

  validateAllCampaignFields() {
    const selectedCampaign = this.campaigns.find(
      (campaign) => campaign.campaign_id.toString() === this.donationData.selectedCampaignId
    );

    if (!selectedCampaign || !selectedCampaign.campaign_fields) return true;

    let isValid = true;
    selectedCampaign.campaign_fields.forEach((field) => {
      const fieldId = field.campaign_field_id.toString();
      const fieldValues = this.donationData.campaignFieldValues[fieldId] || [];
      
      fieldValues.forEach((value, index) => {
        const error = this.validateField(fieldId, index, value);
        if (error) {
          isValid = false;
        }
      });
    });

    return isValid;
  }

  async apiCall(url, options = {}) {
    const defaultOptions = {
      headers: {
        "Content-Type": "application/json",
      },
    };

    const response = await fetch(
      `https://backend-wf-donate.tecocraft.us${url}`,
      { ...defaultOptions, ...options }
    );

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    return await response.json();
  }
}

// Initialize the app when DOM is loaded
document.addEventListener("DOMContentLoaded", () => {
  window.app = new DonationWidget();
});

// To show the overlay
document.querySelector('.backdrop-overlay').style.display = 'flex';

// To hide the overlay
document.querySelector('.backdrop-overlay').style.display = 'none';

// Show
document.querySelector('.backdrop-overlay').classList.add('active');

// Hide
document.querySelector('.backdrop-overlay').classList.remove('active');


// // Select the overlays and dropdowns
// const backdropTitle = document.querySelector(".title-group .backdrop-overlay");
// const backdropCurrency = document.querySelector(".custom-amount-section .backdrop-overlay");
// const backdropCountry = document.querySelector(".country-group .backdrop-overlay"); // Added for country

// const titleSelect = document.getElementById("title");
// const currencySelect = document.getElementById("currency-select");
// const countrySelect = document.getElementById("country"); // Added for country

// // -------- Title Dropdown Events --------
// titleSelect.addEventListener("click", () => {
//   backdropTitle.classList.add("active");
// });

// titleSelect.addEventListener("change", () => {
//   backdropTitle.classList.remove("active");
// });

// titleSelect.addEventListener("blur", () => {
//   backdropTitle.classList.remove("active");
// });

// // -------- Currency Dropdown Events --------
// currencySelect.addEventListener("click", () => {
//   backdropCurrency.classList.add("active");
// });

// currencySelect.addEventListener("change", () => {
//   backdropCurrency.classList.remove("active");
// });

// currencySelect.addEventListener("blur", () => {
//   backdropCurrency.classList.remove("active");
// });

// // -------- Country Dropdown Events --------
// countrySelect.addEventListener("click", () => {
//   backdropCountry.classList.add("active");
// });

// countrySelect.addEventListener("change", () => {
//   backdropCountry.classList.remove("active");
// });

// countrySelect.addEventListener("blur", () => {
//   backdropCountry.classList.remove("active");
// });




const backdropTitle = document.querySelector(".title-group .backdrop-overlay");
const backdropCurrency = document.querySelector(".custom-amount-section .backdrop-overlay");
const backdropCountry = document.querySelector(".country-group .backdrop-overlay");

const titleSelect = document.getElementById("title");
const currencySelect = document.getElementById("currency-select");
const countrySelect = document.getElementById("country");

// UI handlers (click/change/blur) - same as before
titleSelect.addEventListener("click", () => backdropTitle.classList.add("active"));
titleSelect.addEventListener("change", () => {
  backdropTitle.classList.remove("active");
  backdropCountry.classList.remove("active");
});
titleSelect.addEventListener("blur", () => backdropTitle.classList.remove("active"));

currencySelect.addEventListener("click", () => backdropCurrency.classList.add("active"));
currencySelect.addEventListener("change", () => backdropCurrency.classList.remove("active"));
currencySelect.addEventListener("blur", () => backdropCurrency.classList.remove("active"));

countrySelect.addEventListener("click", () => backdropCountry.classList.add("active"));
countrySelect.addEventListener("change", () => backdropCountry.classList.remove("active"));
countrySelect.addEventListener("blur", () => backdropCountry.classList.remove("active"));

// Polling watchers — catches programmatic .value changes too
const stopTitleWatcher = watchSelectValuePolling(titleSelect, () => {
  backdropTitle.classList.remove("active");
  backdropCountry.classList.remove("active"); // keep your extra logic
}, 100);

const stopCurrencyWatcher = watchSelectValuePolling(currencySelect, () => {
  backdropCurrency.classList.remove("active");
}, 100);

const stopCountryWatcher = watchSelectValuePolling(countrySelect, () => {
  backdropCountry.classList.remove("active");
}, 100);

function watchSelectValuePolling(select, callback, interval = 100) {
  let last = select.value;
  const id = setInterval(() => {
    if (select.value !== last) {
      last = select.value;
      callback(select.value);
    }
  }, interval);
  // returns a stop function in case you want to stop watching later
  return () => clearInterval(id);
}

