// Stripe Integration
class StripeIntegration {
    constructor() {
        this.stripe = null;
        this.elements = null;
        this.paymentElement = null;
        this.paymentRequest = null;
        this.isInitialized = false;
    }
    
    async initialize(publishableKey) {
        if (this.isInitialized) return;
        
        try {
            this.stripe = Stripe(publishableKey);
            this.isInitialized = true;
        } catch (error) {
            console.error('Failed to initialize Stripe:', error);
            throw error;
        }
    }
    
    async createPaymentElement(clientSecret, options = {}) {
        if (!this.stripe) {
            throw new Error('Stripe not initialized');
        }
        
        try {
            const elements = this.stripe.elements({
                clientSecret: clientSecret,
                appearance: {
                    theme: 'stripe',
                    variables: {
                        colorPrimary: '#133D72',
                        colorBackground: '#ffffff',
                        colorText: '#333333',
                        colorDanger: '#FF0000',
                        fontFamily: 'Roboto, sans-serif',
                        spacingUnit: '4px',
                        borderRadius: '8px'
                    }
                }
            });
            
            this.elements = elements;
            
            // Create payment element
            this.paymentElement = elements.create('payment', {
                layout: 'tabs',
                wallets: {
                    applePay: 'auto',
                    googlePay: 'auto'
                }
            });
            
            // Mount payment element
            const container = document.getElementById('payment-element');
            if (container) {
                this.paymentElement.mount(container);
            }
            
            // Create payment request for Apple Pay/Google Pay
            await this.createPaymentRequest(clientSecret, options);
            
        } catch (error) {
            console.error('Failed to create payment element:', error);
            throw error;
        }
    }
    
    async createPaymentRequest(clientSecret, options) {
        if (!this.stripe || !options.amount || !options.currency) return;
        
        try {
            this.paymentRequest = this.stripe.paymentRequest({
                country: 'US',
                currency: options.currency.toLowerCase(),
                total: {
                    label: 'Donation',
                    amount: Math.round(options.amount * 100) // Convert to cents
                },
                requestPayerName: true,
                requestPayerEmail: true,
                requestPayerPhone: true
            });
            
            // Check if payment request is available
            const canMakePayment = await this.paymentRequest.canMakePayment();
            if (canMakePayment) {
                this.mountPaymentRequestButton();
            }
            
            // Handle payment method
            this.paymentRequest.on('paymentmethod', async (ev) => {
                await this.handlePaymentMethod(ev, clientSecret);
            });
            
        } catch (error) {
            console.error('Failed to create payment request:', error);
        }
    }
    
    mountPaymentRequestButton() {
        if (!this.paymentRequest) return;
        
        const paymentRequestButton = this.stripe.elements().create('paymentRequestButton', {
            paymentRequest: this.paymentRequest,
            style: {
                paymentRequestButton: {
                    type: 'default',
                    theme: 'dark',
                    height: '48px'
                }
            }
        });
        
        const container = document.getElementById('payment-element');
        if (container) {
            // Insert payment request button before payment element
            const buttonContainer = document.createElement('div');
            buttonContainer.id = 'payment-request-button';
            buttonContainer.style.marginBottom = '16px';
            container.parentNode.insertBefore(buttonContainer, container);
            
            paymentRequestButton.mount('#payment-request-button');
        }
    }
    
    async handlePaymentMethod(ev, clientSecret) {
        try {
            // Confirm the payment
            const { error, paymentIntent } = await this.stripe.confirmCardPayment(
                clientSecret,
                {
                    payment_method: ev.paymentMethod.id
                },
                {
                    handleActions: false
                }
            );
            
            if (error) {
                ev.complete('fail');
                this.showPaymentError(error.message);
                return;
            }
            
            ev.complete('success');
            
            // Handle additional authentication if required
            if (paymentIntent.status === 'requires_action') {
                const { error: confirmError } = await this.stripe.confirmCardPayment(clientSecret);
                if (confirmError) {
                    this.showPaymentError(confirmError.message);
                    return;
                }
            }
            
            // Payment successful
            this.handlePaymentSuccess(paymentIntent);
            
        } catch (error) {
            console.error('Payment method handling failed:', error);
            ev.complete('fail');
            this.showPaymentError('Payment failed. Please try again.');
        }
    }
    
    async confirmPayment() {
        if (!this.stripe || !this.elements) {
            throw new Error('Stripe not initialized');
        }
        
        try {
            const { error, paymentIntent } = await this.stripe.confirmPayment({
                elements: this.elements,
                confirmParams: {
                    return_url: window.location.origin
                }
            });
            
            if (error) {
                this.handlePaymentError(error);
                return false;
            }
            
            if (paymentIntent.status === 'succeeded') {
                this.handlePaymentSuccess(paymentIntent);
                return true;
            }
            
            return false;
            
        } catch (error) {
            console.error('Payment confirmation failed:', error);
            this.handlePaymentError(error);
            return false;
        }
    }
    
    handlePaymentSuccess(paymentIntent) {
        // Update URL with payment intent details
        const url = new URL(window.location);
        url.searchParams.set('payment_intent', paymentIntent.id);
        url.searchParams.set('payment_intent_client_secret', paymentIntent.client_secret);
        url.searchParams.set('redirect_status', paymentIntent.status);
        
        // Redirect to confirmation page
        window.location.href = url.toString();
    }
    
    handlePaymentError(error) {
        let errorMessage = 'Payment failed. Please try again.';
        
        if (error.code) {
            switch (error.code) {
                case 'incomplete_number':
                    errorMessage = 'Card number is incomplete.';
                    break;
                case 'incomplete_cvc':
                    errorMessage = 'CVC code is incomplete.';
                    break;
                case 'incomplete_expiry':
                    errorMessage = 'Card expiry date is incomplete.';
                    break;
                case 'card_declined':
                    errorMessage = 'Your card was declined. Please use a different card.';
                    break;
                case 'expired_card':
                    errorMessage = 'This card has expired.';
                    break;
                case 'incorrect_cvc':
                    errorMessage = 'Incorrect CVC code.';
                    break;
                case 'processing_error':
                    errorMessage = 'A processing error occurred. Please try again.';
                    break;
                case 'authentication_required':
                    errorMessage = 'Additional authentication required. Please complete the verification.';
                    break;
                default:
                    errorMessage = error.message || errorMessage;
            }
        }
        
        this.showPaymentError(errorMessage);
    }
    
    showPaymentError(message) {
        // Remove existing error messages
        const existingError = document.querySelector('.payment-error');
        if (existingError) {
            existingError.remove();
        }
        
        // Create error message element
        const errorDiv = document.createElement('div');
        errorDiv.className = 'payment-error';
        errorDiv.style.cssText = `
            background-color: #ffebee;
            color: #c62828;
            padding: 12px 16px;
            border-radius: 8px;
            margin-bottom: 16px;
            border: 1px solid #ffcdd2;
            font-family: 'Roboto', sans-serif;
            font-size: 14px;
        `;
        errorDiv.textContent = message;
        
        // Insert error message before payment element
        const paymentElement = document.getElementById('payment-element');
        if (paymentElement && paymentElement.parentNode) {
            paymentElement.parentNode.insertBefore(errorDiv, paymentElement);
        }
        
        // Auto-remove after 5 seconds
        setTimeout(() => {
            if (errorDiv.parentNode) {
                errorDiv.parentNode.removeChild(errorDiv);
            }
        }, 5000);
    }
    
    destroy() {
        if (this.paymentElement) {
            this.paymentElement.destroy();
            this.paymentElement = null;
        }
        
        if (this.elements) {
            this.elements = null;
        }
        
        if (this.paymentRequest) {
            this.paymentRequest = null;
        }
        
        // Remove payment request button
        const buttonContainer = document.getElementById('payment-request-button');
        if (buttonContainer) {
            buttonContainer.remove();
        }
        
        // Remove error messages
        const errorMessages = document.querySelectorAll('.payment-error');
        errorMessages.forEach(error => error.remove());
    }
    
    // Utility method to check if Stripe is supported
    isSupported() {
        return typeof Stripe !== 'undefined';
    }
    
    // Get supported payment methods
    getSupportedPaymentMethods() {
        return [
            'card',
            'apple_pay',
            'google_pay'
        ];
    }
}

// Global Stripe integration instance
window.stripeIntegration = new StripeIntegration();

// Helper function to initialize Stripe in the main app
window.initializeStripe = async function(publishableKey, clientSecret, options = {}) {
    try {
        await window.stripeIntegration.initialize(publishableKey);
        await window.stripeIntegration.createPaymentElement(clientSecret, options);
    } catch (error) {
        console.error('Stripe initialization failed:', error);
        throw error;
    }
};

// Helper function to confirm payment
window.confirmStripePayment = async function() {
    try {
        return await window.stripeIntegration.confirmPayment();
    } catch (error) {
        console.error('Payment confirmation failed:', error);
        throw error;
    }
};

// Helper function to destroy Stripe elements
window.destroyStripe = function() {
    window.stripeIntegration.destroy();
};
