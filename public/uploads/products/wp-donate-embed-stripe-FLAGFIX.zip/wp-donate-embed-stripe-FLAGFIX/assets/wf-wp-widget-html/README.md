# WF Donation Widget - Pure HTML/CSS/JavaScript

A pure HTML, CSS, and JavaScript implementation of the World Federation donation widget, replicating all functionality from the original React/TypeScript version.

## Features

- **Multiple Donation Types**: One-off, Multiple campaigns, and Recurring subscriptions
- **Campaign Selection**: Dynamic campaign loading with custom fields support
- **Currency Support**: Multi-currency with real-time exchange rates
- **Payment Processing**: Stripe integration with Apple Pay/Google Pay support
- **Gift Aid**: UK-specific Gift Aid functionality with address validation
- **Form Validation**: Comprehensive client-side validation
- **Responsive Design**: Mobile-first responsive design
- **Social Sharing**: Share campaigns on social media platforms
- **Multi-language Support**: Ready for internationalization

## File Structure

```
wf-wp-widget-html/
├── index.html              # Main HTML file
├── config.js               # Configuration file
├── README.md               # This file
├── css/
│   ├── styles.css          # Main stylesheet
│   └── responsive.css      # Responsive styles
├── js/
│   ├── app.js              # Main application logic
│   ├── api.js              # API integration
│   ├── stripe.js           # Stripe payment integration
│   └── validation.js       # Form validation utilities
├── assets/
│   ├── images/             # Image assets
│   └── icons/              # Icon assets
└── api/                    # API mock files (for development)
```

## Setup Instructions

### 1. Basic Setup

1. Clone or download this repository
2. Place the files on your web server
3. Ensure your server supports serving static files

### 2. Configuration

1. Open `config.js` and update the configuration:
   ```javascript
   stripe: {
       publishableKey: 'pk_live_your_actual_stripe_key_here'
   }
   ```

2. Update API endpoints in `js/api.js` to point to your backend:
   ```javascript
   this.baseURL = 'https://your-api-domain.com';
   ```

### 3. Backend API Requirements

Your backend should provide the following endpoints:

#### Campaigns
- `GET /api/v1/campaigns` - Get all active campaigns
- `GET /api/v1/campaigns/{id}` - Get specific campaign
- `GET /api/v1/campaigns/{id}/fields` - Get campaign custom fields

#### Currencies
- `GET /api/v1/currencies` - Get all currencies
- `GET /api/v1/currencies/enabled` - Get enabled currencies
- `GET /api/v1/currencies/exchange-rates` - Get exchange rates

#### Payments
- `POST /api/v1/donations/single-payment-intent` - Create single payment
- `POST /api/v1/donations/multi-payment-intent` - Create multi payment
- `POST /api/v1/donations/subscription-payment-intent` - Create subscription
- `GET /api/v1/donations/payment-intent/{id}` - Get payment details

#### Other
- `POST /api/v1/address/verify` - Verify UK addresses for Gift Aid
- `POST /api/v1/newsletter/subscribe` - Newsletter subscription

### 4. Stripe Setup

1. Create a Stripe account at https://stripe.com
2. Get your publishable key from the Stripe dashboard
3. Update the `publishableKey` in `config.js`
4. Set up webhook endpoints for payment confirmation

### 5. Testing

1. Use Stripe test keys for development
2. Test with Stripe test card numbers:
   - Success: 4242 4242 4242 4242
   - Decline: 4000 0000 0000 0002
   - Requires authentication: 4000 0025 0000 3155

## Usage

### Basic Integration

Include the widget in your HTML page:

```html
<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="path/to/css/styles.css">
    <link rel="stylesheet" href="path/to/css/responsive.css">
    <script src="https://js.stripe.com/v3/"></script>
</head>
<body>
    <div id="donation-widget"></div>
    
    <script src="path/to/config.js"></script>
    <script src="path/to/js/validation.js"></script>
    <script src="path/to/js/api.js"></script>
    <script src="path/to/js/stripe.js"></script>
    <script src="path/to/js/app.js"></script>
</body>
</html>
```

### URL Parameters

The widget supports URL parameters for pre-configuration:

- `?id=123` - Pre-select campaign with ID 123
- `?name=khums` - Pre-select campaign by name
- `?amount=50` - Pre-set donation amount
- `?currency=USD` - Pre-set currency
- `?type=subscription` - Pre-set donation type

### API Integration

The widget automatically loads campaigns and currencies on initialization. Make sure your API endpoints return data in the expected format:

```javascript
// Campaigns response format
{
    "success": true,
    "data": [
        {
            "campaign_id": 1,
            "title": "General Donation",
            "description": "Support our general fund",
            "imageUrl": "https://example.com/image.jpg",
            "is_active": true,
            "fields": [
                {
                    "campaign_field_id": 1,
                    "title": "Student Name",
                    "is_single_field": true
                }
            ]
        }
    ]
}
```

## Customization

### Styling

The widget uses CSS custom properties for easy theming. Update the theme colors in `config.js`:

```javascript
ui: {
    theme: {
        primaryColor: '#133D72',
        secondaryColor: '#0D294B',
        // ... other colors
    }
}
```

### Validation Rules

Customize validation rules in `js/validation.js` or update the configuration in `config.js`.

### Features

Enable/disable features in `config.js`:

```javascript
features: {
    giftAid: { enabled: true },
    multiDonation: { enabled: true },
    subscription: { enabled: true },
    socialSharing: { enabled: true }
}
```

## Browser Support

- Chrome 60+
- Firefox 55+
- Safari 12+
- Edge 79+
- Mobile browsers (iOS Safari, Chrome Mobile)

## Security Considerations

1. **API Keys**: Never expose secret keys in client-side code
2. **HTTPS**: Always serve the widget over HTTPS in production
3. **CORS**: Configure proper CORS headers for your API
4. **Validation**: Always validate data on the server side
5. **Rate Limiting**: Implement rate limiting on your API endpoints

## Performance

- **Lazy Loading**: Images and non-critical resources are loaded on demand
- **Minification**: Minify CSS and JavaScript files for production
- **Caching**: Set appropriate cache headers for static assets
- **CDN**: Consider using a CDN for better global performance

## Troubleshooting

### Common Issues

1. **Stripe not loading**: Check your publishable key and network connectivity
2. **API errors**: Verify your API endpoints and CORS configuration
3. **Validation errors**: Check browser console for JavaScript errors
4. **Styling issues**: Ensure CSS files are loaded in the correct order

### Debug Mode

Enable debug mode in `config.js`:

```javascript
development: {
    debug: true,
    logLevel: 'debug'
}
```

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Support

For support and questions, please contact the development team or create an issue in the repository.
