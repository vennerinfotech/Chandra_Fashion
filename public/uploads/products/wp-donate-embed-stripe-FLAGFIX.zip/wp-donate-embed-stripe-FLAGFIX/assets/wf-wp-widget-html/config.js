// Configuration file for the donation widget
window.DONATION_CONFIG = {
    // API Configuration
    api: {
        baseURL: window.location.origin,
        version: '/api/v1',
        timeout: 30000
    },
    
    // Stripe Configuration
    stripe: {
        publishableKey: 'pk_test_your_stripe_publishable_key_here', // Replace with your actual key
        supportedCurrencies: ['gbp', 'usd', 'eur', 'cad', 'aud'],
        supportedCountries: ['US', 'GB', 'CA', 'AU', 'DE', 'FR', 'IT', 'ES']
    },
    
    // Widget Configuration
    widget: {
        defaultCurrency: 'GBP',
        defaultAmount: 20,
        minimumAmount: 0.5,
        maximumAmount: 10000,
        supportedDonationTypes: ['once', 'multi', 'subscription'],
        maxMultiDonations: 5,
        supportedSubscriptionFrequencies: ['weekly', 'monthly', 'quarterly', 'yearly']
    },
    
    // UI Configuration
    ui: {
        theme: {
            primaryColor: '#133D72',
            secondaryColor: '#0D294B',
            tertiaryColor: '#4B88B2',
            successColor: '#1BCD32',
            errorColor: '#FF0000',
            warningColor: '#EC841A'
        },
        fonts: {
            primary: 'Roboto, sans-serif',
            secondary: 'Lato, sans-serif',
            accent: 'Montserrat, sans-serif'
        },
        animations: {
            enabled: true,
            duration: 300
        }
    },
    
    // Features Configuration
    features: {
        giftAid: {
            enabled: true,
            supportedCountries: ['GB'],
            rate: 0.25 // 25%
        },
        multiDonation: {
            enabled: true,
            maxCampaigns: 5
        },
        subscription: {
            enabled: true,
            supportedFrequencies: ['weekly', 'monthly', 'quarterly', 'yearly']
        },
        socialSharing: {
            enabled: true,
            platforms: ['whatsapp', 'facebook', 'twitter', 'linkedin', 'email']
        },
        analytics: {
            enabled: true,
            trackEvents: true
        }
    },
    
    // Validation Configuration
    validation: {
        email: {
            required: true,
            pattern: /^[^\s@]+@[^\s@]+\.[^\s@]+$/
        },
        phone: {
            required: true,
            minLength: 7,
            pattern: /^\+?[\d\s\-\(\)]+$/
        },
        name: {
            required: true,
            minLength: 2,
            pattern: /^[a-zA-Z\s]+$/
        },
        postcode: {
            pattern: /^[A-Za-z0-9]{2,4} [A-Za-z0-9]{3}$/
        }
    },
    
    // Error Messages
    messages: {
        errors: {
            required: 'This field is required',
            invalidEmail: 'Please enter a valid email address',
            invalidPhone: 'Please enter a valid phone number',
            invalidAmount: 'Please enter a valid donation amount',
            minimumAmount: 'Minimum donation amount is £0.50',
            maximumAmount: 'Maximum donation amount is £10,000',
            campaignRequired: 'Please select a campaign',
            multiDonationRequired: 'Please add at least one campaign to your donation',
            maxMultiDonations: 'You can add up to 5 campaigns to your donation',
            paymentFailed: 'Payment failed. Please try again.',
            networkError: 'Network error. Please check your connection and try again.',
            serverError: 'Server error. Please try again later.'
        },
        success: {
            paymentSuccess: 'Payment successful! Thank you for your donation.',
            formSubmitted: 'Form submitted successfully'
        },
        info: {
            loading: 'Loading...',
            processing: 'Processing...',
            creatingPayment: 'Creating payment...',
            verifyingAddress: 'Verifying address...'
        }
    },
    
    // Currency Configuration
    currencies: {
        GBP: { symbol: '£', name: 'British Pound', decimal: 2 },
        USD: { symbol: '$', name: 'US Dollar', decimal: 2 },
        EUR: { symbol: '€', name: 'Euro', decimal: 2 },
        CAD: { symbol: 'C$', name: 'Canadian Dollar', decimal: 2 },
        AUD: { symbol: 'A$', name: 'Australian Dollar', decimal: 2 },
        INR: { symbol: '₹', name: 'Indian Rupee', decimal: 2 },
        PKR: { symbol: '₨', name: 'Pakistani Rupee', decimal: 2 }
    },
    
    // Country Configuration
    countries: {
        'United Kingdom': 'GB',
        'United States': 'US',
        'Canada': 'CA',
        'Australia': 'AU',
        'Germany': 'DE',
        'France': 'FR',
        'Italy': 'IT',
        'Spain': 'ES',
        'India': 'IN',
        'Pakistan': 'PK'
    },
    
    // Development Configuration
    development: {
        debug: false,
        logLevel: 'error', // 'debug', 'info', 'warn', 'error'
        mockAPI: false,
        mockStripe: false
    }
};

// Helper function to get configuration value
window.getConfig = function(path, defaultValue = null) {
    const keys = path.split('.');
    let value = window.DONATION_CONFIG;
    
    for (const key of keys) {
        if (value && typeof value === 'object' && key in value) {
            value = value[key];
        } else {
            return defaultValue;
        }
    }
    
    return value;
};

// Helper function to check if feature is enabled
window.isFeatureEnabled = function(feature) {
    return window.getConfig(`features.${feature}.enabled`, false);
};

// Helper function to get currency symbol
window.getCurrencySymbol = function(currency = null) {
    const curr = currency || window.getConfig('widget.defaultCurrency', 'GBP');
    return window.getConfig(`currencies.${curr}.symbol`, '£');
};

// Helper function to get error message
window.getErrorMessage = function(key) {
    return window.getConfig(`messages.errors.${key}`, 'An error occurred');
};

// Helper function to get success message
window.getSuccessMessage = function(key) {
    return window.getConfig(`messages.success.${key}`, 'Success');
};

// Helper function to get info message
window.getInfoMessage = function(key) {
    return window.getConfig(`messages.info.${key}`, 'Loading...');
};
