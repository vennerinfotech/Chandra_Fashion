// API Integration
class APIClient {
  constructor() {
    this.baseURL = "https://backend-wf-donate.tecocraft.us";
    this.apiVersion = ""; // keep empty unless backend requires version like '/v1'
    this.timeout = 30000; // 30 seconds
  }

  async request(endpoint, options = {}) {
    const url = `${this.baseURL}${this.apiVersion}${endpoint}`;

    const def = {
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
      },
    };

    const cfg = {
      ...def,
      ...options,
      headers: { ...def.headers, ...(options.headers || {}) },
    };

    const ctl = new AbortController();
    const id = setTimeout(() => ctl.abort(), this.timeout);

    try {
      const res = await fetch(url, { ...cfg, signal: ctl.signal });
      clearTimeout(id);

      if (!res.ok) {
        throw new Error(`HTTP error! status: ${res.status}`);
      }

      return await res.json();
    } catch (err) {
      clearTimeout(id);
      throw err;
    }
  }

  // Campaigns API
async getCampaigns() {
  try {
    const resp = await this.request("/campaigns?search=" + encodeURIComponent(""), { method: "GET" });

    if (!resp) return []; // ✅ handle 204

    if (Array.isArray(resp)) return resp;
    if (resp && Array.isArray(resp.data)) return resp.data;
    if (resp && Array.isArray(resp.campaigns)) return resp.campaigns;
    return [];
  } catch (e1) {
    console.warn("GET /campaigns failed, trying POST fallback:", e1);
    try {
      const resp2 = await this.request("/campaigns", {
        method: "POST",
        body: JSON.stringify({ search: "" }),
      });

      if (!resp2) return []; // ✅ handle 204
      if (Array.isArray(resp2)) return resp2;
      if (resp2 && Array.isArray(resp2.data)) return resp2.data;
      if (resp2 && Array.isArray(resp2.campaigns)) return resp2.campaigns;
      return [];
    } catch (e2) {
      console.error("Failed to fetch campaigns:", e2);
      return [];
    }
  }
}


  // Payment API
  async createSinglePaymentIntent(payload) {
    const r = await this.request("/donations/single-payment-intent", {
      method: "POST",
      body: JSON.stringify(payload),
    });

    if (!r || r.success === false) {
      throw new Error(
        r && r.message ? r.message : "Failed to create payment intent"
      );
    }

    return r.data;
  }
}

// Global instance
window.apiClient = new APIClient();
