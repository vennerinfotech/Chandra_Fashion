(function(){
  if (window.WPD_FLAGS_BASE) return;
  function flagVisible(){
    var el=document.querySelector('.iti__flag'); if(!el) return null;
    var bg=getComputedStyle(el).backgroundImage||'';
    return !!bg && bg!=='none';
  }
  function inject(base){
    var css='.iti__flag{background-image:url('+base+'flags.png)}'+
            '@media (-webkit-min-device-pixel-ratio:2),(min-resolution:192dpi){.iti__flag{background-image:url('+base+'flags@2x.png)}}';
    var s=document.createElement('style'); s.appendChild(document.createTextNode(css)); document.head.appendChild(s);
  }
  function tryBases(b, i){
    if(i>=b.length) return;
    var base=b[i], img=new Image();
    img.onload=function(){ inject(base); };
    img.onerror=function(){ tryBases(b, i+1); };
    img.src=base+'flags.png';
  }
  function boot(){
    if(flagVisible()) return;
    var candidates=[ (window.WPD_PLUGIN_URL||'')+'assets/flags/', window.location.origin+'/flags/' ];
    tryBases(candidates,0);
  }
  if(document.readyState==='loading'){ document.addEventListener('DOMContentLoaded', boot); } else { boot(); }
})();