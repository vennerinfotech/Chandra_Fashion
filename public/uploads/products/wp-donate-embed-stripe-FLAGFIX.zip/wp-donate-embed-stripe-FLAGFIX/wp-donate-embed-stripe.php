<?php
/**
 * Plugin Name: WP Donate Embed (Stripe Only) – Path Fix
 * Description: Renders your full form package with normalized asset paths; Stripe + campaigns wired.
 * Version: 1.0.2
 * Author: Your Name
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'WPD_PLUGIN_DIR', plugin_dir_path(__FILE__) );
define( 'WPD_PLUGIN_URL', plugin_dir_url(__FILE__) );
define( 'WPD_STRIPE_PUBLISHABLE_KEY', 'pk_test_51I0kvfIOA3YxcRKLAQOiZyjG1UWossfPW6yIs5M365JWpMGiO3SukOwHkuV51oqP05dRkTPwRvHb2Eyo97aoRxy400KbThrniu' );
if ( ! defined('WPD_FLAGS_BASE') ) { define( 'WPD_FLAGS_BASE', '' ); }

function wpd_render_form_sc($atts=array()){
    ob_start();
    include WPD_PLUGIN_DIR . 'templates/form-template.php';
    return ob_get_clean();
}
add_shortcode('php_form_embed_api','wpd_render_form_sc');

function wpd_enqueue_user_assets(){
    $base = WPD_PLUGIN_DIR . 'assets';
    if ( ! is_dir($base) ) return;
    $rii = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($base));
    foreach ($rii as $file) {
        if ($file->isDir()) continue;
        $path = $file->getPathname();
        $rel  = str_replace(WPD_PLUGIN_DIR, '', $path);
        $url  = WPD_PLUGIN_URL . str_replace(DIRECTORY_SEPARATOR, '/', $rel);
        $ext  = strtolower(pathinfo($path, PATHINFO_EXTENSION));
        $baseName = basename($path);
        if (in_array($baseName, array('apiClient.js','donation.js','campaigns.js'), true)) continue;
        $handle = 'wpd-auto-' . md5($rel);
        if ($ext === 'css') { wp_enqueue_style($handle, $url, array(), '1.0.0'); }
        elseif ($ext === 'js') { wp_enqueue_script($handle, $url, array('jquery'), '1.0.0', true); }
    }
}

function wpd_enqueue_assets(){
    wp_enqueue_script('stripe-js','https://js.stripe.com/v3/', array(), null, true);
    wpd_enqueue_user_assets();
    wp_enqueue_script('wpd-flags-fix', WPD_PLUGIN_URL . 'assets/flags-fix.js', array(), '1.0.0', true);
    wp_enqueue_script('wpd-api-client', WPD_PLUGIN_URL . 'assets/apiClient.js', array(), '1.0.0', true);
    wp_enqueue_script('wpd-campaigns',  WPD_PLUGIN_URL . 'assets/campaigns.js', array('wpd-api-client'), '1.0.0', true);
    wp_enqueue_script('wpd-donation',   WPD_PLUGIN_URL . 'assets/donation.js',  array('stripe-js','wpd-api-client','wpd-campaigns'), '1.0.0', true);
    wp_add_inline_script('wpd-donation', 'window.WPD_STRIPE_PUBLISHABLE = ' . json_encode(constant('WPD_STRIPE_PUBLISHABLE_KEY')) . ';', 'before');
}

function wpd_inline_flags_css(){
    if ( defined('WPD_FLAGS_BASE') && WPD_FLAGS_BASE ){
        $css = '.iti__flag{background-image:url(' . WPD_FLAGS_BASE . 'flags.png)}'
             . '@media (-webkit-min-device-pixel-ratio:2),(min-resolution:192dpi){.iti__flag{background-image:url(' . WPD_FLAGS_BASE . 'flags@2x.png)}}';
        wp_register_style('wpd-flags-inline', false);
        wp_enqueue_style('wpd-flags-inline');
        wp_add_inline_style('wpd-flags-inline', $css);
    }
}
add_action('wp_enqueue_scripts','wpd_inline_flags_css', 5);

add_action('wp_enqueue_scripts','wpd_enqueue_assets');
