<?php /* Template with normalized asset paths */ ?>
	
    <div class="app-container">
        <!-- Loading Screen -->
        <div id="loading-screen" class="loading-screen">
            <div class="loader">
                <div class="loader-spinner"></div>
                <p id="loading-text">Loading...</p>
            </div>
        </div>

		<div id="payment-request-wrapper" style="display:none;">
		  <div id="payment-request-button"></div>
		  <div>…Apple Pay / Google Pay…</div>
		</div>

        <!-- Main App -->
        <div id="app" class="app" style="display: none;">
            <!-- Step 1: Donation Form -->
            <div id="donation-form" class="step-container">
                <div class="form-card">
                    <h1 class="form-title">Make a secure donation</h1>

                    <!-- Donation Type Selection -->
                    <div class="donation-type-section">
                        <div class="donation-type-buttons">
                            <button class="donation-type-btn active" data-type="once">One-off</button>
                            <button class="donation-type-btn" data-type="multi">Multiple</button>
                            <button class="donation-type-btn" data-type="subscription">Recurring</button>
                        </div>
                    </div>

                    <!-- Quick Donation Options -->
                    <div class="quick-donation-section">
                        <div class="quick-donation-options">
                            <div class="quick-option" data-campaign="khums">
                                <div class="quick-option-icon khums-icon">
                                    <svg width="60" height="60" viewBox="0 0 60 60" fill="none"
                                        xmlns="http://www.w3.org/2000/svg">
                                        <rect x="0.25" width="60" height="60" rx="4.36364" fill="#554A2E" />
                                        <g clip-path="url(#clip0_2199_419)">
                                            <path
                                                d="M31.8523 12.585C31.6252 12.585 31.4409 12.7693 31.4409 12.9964V28.3979C31.4409 28.625 31.6252 28.8093 31.8523 28.8093H47.2538C47.481 28.8093 47.6652 28.625 47.6652 28.3979C47.6652 19.6786 40.5716 12.585 31.8523 12.585ZM32.2636 27.9865V13.4133C40.2025 13.6284 46.6217 20.0473 46.837 27.9865H32.2636V27.9865Z"
                                                fill="white" />
                                            <path
                                                d="M28.6478 47.415C37.3671 47.415 44.4607 40.3214 44.4607 31.6021C44.4607 31.375 44.2764 31.1907 44.0493 31.1907H29.0592V16.2006C29.0592 15.9735 28.8749 15.7892 28.6478 15.7892C19.9152 15.7893 12.835 22.8678 12.835 31.6021C12.835 40.3378 19.9077 47.415 28.6478 47.415ZM28.6478 46.5923C24.782 46.5923 21.1391 45.138 18.3435 42.4881L28.8181 32.0135H43.6325C43.4135 40.0895 36.7757 46.5923 28.6478 46.5923ZM28.2365 16.6176V30.6091L18.3451 20.7178C21.0422 18.1611 24.526 16.717 28.2365 16.6176ZM17.7634 21.2997L28.0661 31.6021L17.7618 41.9064C15.112 39.1115 13.6577 35.4685 13.6577 31.6021C13.6577 27.739 15.1125 24.0966 17.7634 21.2997Z"
                                                fill="white" />
                                        </g>
                                        <defs>
                                            <clipPath id="clip0_2199_419">
                                                <rect width="36" height="36" fill="white"
                                                    transform="translate(12.25 12)" />
                                            </clipPath>
                                        </defs>
                                    </svg>
                                </div>
                                <span>Khums</span>
                            </div>
                            <div class="quick-option" data-campaign="sadaqah">
                                <div class="quick-option-icon sadaqah-icon">
                                    <svg width="60" height="60" viewBox="0 0 60 60" fill="none"
                                        xmlns="http://www.w3.org/2000/svg">
                                        <rect x="0.75" width="60" height="60" rx="4.36364" fill="#00C7BE" />
                                        <path
                                            d="M32.2463 20.2479C32.2453 19.8357 32.0839 19.4462 31.7895 19.1493C31.5589 18.9199 31.2665 18.7707 30.9518 18.7191C30.9055 18.7051 30.8566 18.6975 30.8059 18.6975H30.7981C30.79 18.6967 30.7823 18.696 30.7742 18.6957C30.4785 18.6807 30.2463 18.4367 30.2453 18.1409C30.245 17.9918 30.3026 17.8515 30.4077 17.746C30.5053 17.648 30.6331 17.5903 30.768 17.5838C30.7816 17.5832 30.7884 17.5836 30.802 17.5818L31.7429 17.5796C32.0172 17.5789 32.2391 17.3559 32.2385 17.0816C32.2378 16.8075 32.0156 16.5859 31.7416 16.5859C31.7413 16.5859 31.741 16.5859 31.7404 16.5859L31.2397 16.5871L31.239 16.3156C31.2383 16.0416 31.0161 15.8201 30.7421 15.8201C30.7418 15.8201 30.7412 15.8201 30.7409 15.8201C30.4666 15.8207 30.2447 16.0437 30.2453 16.3182L30.2463 16.6968C30.0455 16.7741 29.8591 16.8886 29.7032 17.0451C29.4111 17.3387 29.2507 17.7287 29.2517 18.1435C29.2539 18.9061 29.8077 19.544 30.5423 19.6682C30.5901 19.6829 30.6403 19.6854 30.6933 19.6907L30.6997 19.6913C30.7088 19.6923 30.7182 19.693 30.7276 19.6933C30.8622 19.6991 30.9903 19.756 31.086 19.8513C31.1931 19.9592 31.2523 20.1008 31.2525 20.2503C31.2532 20.5465 31.0223 20.7912 30.6959 20.8094L29.755 20.8117C29.4807 20.8123 29.2588 21.0354 29.2594 21.3096C29.26 21.5838 29.4823 21.8053 29.7562 21.8053C29.7566 21.8053 29.7569 21.8053 29.7575 21.8053L30.2583 21.8042L30.2589 22.0753C30.2595 22.3494 30.4818 22.5711 30.7557 22.5711C30.7561 22.5711 30.7564 22.5711 30.7567 22.5711C31.0313 22.5705 31.2533 22.3476 31.2525 22.0733L31.2517 21.6921C31.8355 21.4665 32.2478 20.9057 32.2463 20.2479ZM24.5181 43.721H36.9821C38.0107 43.721 38.8478 42.8841 38.8478 41.8552V32.5012C38.8478 31.4723 38.0107 30.6353 36.9821 30.6353H24.5181C23.4895 30.6353 22.6523 31.4723 22.6523 32.5012V41.8553C22.6523 42.8841 23.4895 43.721 24.5181 43.721ZM23.646 32.5012C23.646 32.0202 24.0371 31.629 24.5181 31.629H36.9821C37.4631 31.629 37.8542 32.0202 37.8542 32.5012V41.8553C37.8542 42.3361 37.4631 42.7274 36.9821 42.7274H24.5181C24.0371 42.7274 23.646 42.3362 23.646 41.8553V32.5012Z"
                                            fill="white" />
                                        <path
                                            d="M17.7339 25.2282V26.4259C17.7339 27.2736 18.3026 27.9897 19.0779 28.2162V45.1924C19.0779 46.2214 19.9151 47.0583 20.9437 47.0583H40.5562C41.5848 47.0583 42.4219 46.2214 42.4219 45.1924V28.2162C43.1973 27.9897 43.766 27.2736 43.766 26.4259V25.2282C43.766 24.1992 42.9288 23.3623 41.9002 23.3623H35.5798C36.6726 22.1364 37.1469 20.5986 37.0971 19.0814C36.9904 15.8116 34.2454 13.0593 30.9778 12.9459C27.3749 12.8153 24.3921 15.702 24.4008 19.3081C24.4042 20.8573 24.9842 22.258 25.9953 23.3623H19.5996C18.571 23.3622 17.7339 24.1992 17.7339 25.2282ZM41.4282 45.1924C41.4282 45.6734 41.0371 46.0647 40.5561 46.0647H20.9436C20.4626 46.0647 20.0715 45.6734 20.0715 45.1924V28.2918H41.4282V45.1924ZM25.3944 19.3058C25.3871 16.2918 27.8332 13.9355 30.7506 13.9355C30.8147 13.9355 30.879 13.9366 30.9434 13.9389C33.699 14.0346 36.014 16.3559 36.1039 19.1138C36.1566 20.7216 35.5123 22.3108 34.1264 23.3622H27.4545C26.2081 22.4278 25.3988 20.9854 25.3944 19.3058ZM18.7275 25.2282C18.7275 24.7472 19.1186 24.3559 19.5996 24.3559H41.9002C42.3812 24.3559 42.7722 24.7472 42.7722 25.2282V26.4259C42.7722 26.907 42.3812 27.2982 41.9002 27.2982H19.5996C19.1186 27.2982 18.7275 26.907 18.7275 26.4259L18.7275 25.2282Z"
                                            fill="white" />
                                        <path
                                            d="M30.7687 41.8207C33.106 41.8207 35.0918 40.0749 35.3878 37.7598C35.4165 37.5334 35.2875 37.3163 35.0743 37.2337C34.8621 37.1511 34.6198 37.2241 34.4885 37.4111C33.9561 38.1679 33.0854 38.6195 32.1589 38.6195C30.5875 38.6195 29.3092 37.3412 29.3092 35.7698C29.3092 34.8436 29.7611 33.9729 30.5177 33.4406C30.7043 33.3091 30.7774 33.0673 30.695 32.8545C30.6125 32.6416 30.3974 32.5121 30.1687 32.5414C27.8536 32.837 26.1079 34.8226 26.1079 37.1601C26.1079 39.73 28.1988 41.8207 30.7687 41.8207ZM28.6723 34.1533C28.4407 34.6532 28.3156 35.2038 28.3156 35.7698C28.3156 37.8891 30.0396 39.6132 32.159 39.6132C32.7251 39.6132 33.2756 39.4882 33.7753 39.2564C33.1084 40.2108 32.0008 40.827 30.7688 40.827C28.7468 40.827 27.1017 39.182 27.1017 37.1601C27.1016 35.928 27.7178 34.8201 28.6723 34.1533Z"
                                            fill="white" />
                                        <path
                                            d="M30.9996 36.6362C31.0966 36.7333 31.2237 36.7818 31.3508 36.7818C31.478 36.7818 31.6051 36.7333 31.7021 36.6362L32.126 36.2123L32.5499 36.6362C32.647 36.7333 32.7741 36.7818 32.9012 36.7818C33.0283 36.7818 33.1555 36.7333 33.2525 36.6362C33.4466 36.4423 33.4466 36.1276 33.2525 35.9337L32.8286 35.5098L33.2525 35.0858C33.4466 34.8919 33.4466 34.5772 33.2525 34.3833C33.0584 34.1892 32.744 34.1892 32.5499 34.3833L32.126 34.8072L31.7021 34.3833C31.5081 34.1892 31.1936 34.1892 30.9996 34.3833C30.8055 34.5772 30.8055 34.8919 30.9996 35.0858L31.4235 35.5098L30.9996 35.9337C30.8055 36.1275 30.8055 36.4423 30.9996 36.6362Z"
                                            fill="white" />
                                    </svg>
                                </div>
                                <span>Sadaqah</span>
                            </div>
                            <div class="quick-option" data-campaign="zakat">
                                <div class="quick-option-icon zakat-icon">
                                    <svg width="60" height="60" viewBox="0 0 60 60" fill="none"
                                        xmlns="http://www.w3.org/2000/svg">
                                        <rect x="0.25" width="60" height="60" rx="4.36364" fill="#AF52DE" />
                                        <path
                                            d="M19.4612 43.1832H32.0158C32.0903 43.1832 32.1632 43.1758 32.2371 43.1729C32.4722 43.4149 32.6983 43.6357 32.904 43.8274C34.8186 45.6109 37.1578 47.062 38.1182 47.0618C39.7608 47.0617 47.3085 41.9946 47.3085 36.6457C47.3085 33.4121 44.6778 30.7815 41.4444 30.7815C40.2386 30.7815 39.0964 31.1386 38.1179 31.8179C37.4202 31.3342 36.6391 31.0174 35.8126 30.873L33.5419 26.7959C33.5862 26.8205 33.6293 26.8437 33.6742 26.8688C35.0098 27.6146 36.4822 28.437 38.8062 28.437C39.5046 28.437 40.2799 28.3627 41.1514 28.1898C41.4205 28.1364 41.5955 27.8749 41.5421 27.6058C41.4887 27.3368 41.2277 27.1626 40.9579 27.2152C37.5431 27.8919 35.8229 26.9309 34.1587 26.0013C33.6819 25.7349 33.1976 25.4678 32.679 25.2467L32.2382 24.4553C32.5789 24.2006 32.8406 23.8472 32.9801 23.4365C33.3018 23.5947 33.6232 23.7704 33.9571 23.957C35.2927 24.7029 36.7651 25.5252 39.0892 25.5252C39.7875 25.5252 40.5629 25.4509 41.4343 25.278C41.7034 25.2247 41.8784 24.9632 41.825 24.694C41.772 24.4251 41.5106 24.2504 41.2409 24.3034C37.8257 24.9802 36.1059 24.0189 34.4417 23.0895C33.9953 22.8401 33.5399 22.5931 33.0584 22.3806C32.8802 21.3895 32.0133 20.6346 30.9715 20.6346H30.1231L31.7429 15.1593C31.7888 15.0042 31.7562 14.8364 31.6556 14.7096C31.555 14.5828 31.3978 14.5151 31.2374 14.5225C28.9195 14.6588 24.739 14.702 22.7791 13.4692C21.3254 12.5557 19.482 12.7699 18.4523 14.5109C18.3721 14.6466 18.3611 14.812 18.4222 14.9571L20.8199 20.6344H20.5054C19.3351 20.6344 18.3831 21.5863 18.3831 22.7565C18.3831 23.4517 18.7206 24.0679 19.2388 24.4552L13.9918 33.8761C12.9004 35.836 12.9272 38.1605 14.0639 40.0945C15.2002 42.0286 17.218 43.1832 19.4612 43.1832ZM38.4271 32.8254C39.2927 32.1383 40.3359 31.7751 41.4444 31.7751C44.1297 31.7751 46.3148 33.9601 46.3148 36.6457C46.3148 41.2938 39.2216 46.0679 38.1182 46.0682C37.6599 46.0682 35.6427 45.0208 33.5813 43.1004C32.2144 41.8271 29.9213 39.2955 29.9213 36.6457C29.9213 33.9601 32.1054 31.7752 34.7901 31.7752C35.8977 31.7752 36.9418 32.1384 37.8096 32.8258C37.9911 32.9692 38.2463 32.9688 38.4271 32.8254ZM19.4392 14.8114C20.1459 13.7992 21.2869 13.7043 22.2501 14.3103C24.1741 15.5203 27.7176 15.6709 30.5913 15.5497L29.0872 20.6344H21.8986L19.4392 14.8114ZM20.5054 21.628C21.8482 21.6296 30.9262 21.628 30.9717 21.628C31.594 21.628 32.1003 22.1343 32.1003 22.7564C32.1003 23.3786 31.594 23.8848 30.9717 23.8848H20.5054C19.883 23.8848 19.3768 23.3785 19.3768 22.7564C19.3768 22.1343 19.883 21.628 20.5054 21.628ZM14.8599 34.3597L20.1404 24.8785C22.7536 24.8785 28.7529 24.8785 31.3364 24.8785L34.6286 30.7896C31.471 30.8762 28.9276 33.4667 28.9276 36.6457C28.9276 38.7412 30.1224 40.7143 31.3504 42.1895H19.4612C17.5741 42.1895 15.8766 41.2181 14.9204 39.5911C13.9643 37.9641 13.9416 36.0084 14.8599 34.3597Z"
                                            fill="white" />
                                        <path
                                            d="M31.916 36.6458C31.916 36.9202 32.1386 37.1426 32.4128 37.1426C32.6871 37.1426 32.9097 36.9202 32.9097 36.6458C32.9097 35.6078 33.7533 34.7632 34.7903 34.7632C35.0646 34.7632 35.2871 34.5409 35.2871 34.2664C35.2871 33.992 35.0646 33.7696 34.7903 33.7696C33.2053 33.7696 31.916 35.0598 31.916 36.6458Z"
                                            fill="white" />
                                    </svg>

                                </div>
                                <span>Zakat</span>
                            </div>
                            <div class="quick-option" data-campaign="orphans">
                                <div class="quick-option-icon orphans-icon">
                                    <svg width="60" height="60" viewBox="0 0 60 60" fill="none"
                                        xmlns="http://www.w3.org/2000/svg">
                                        <rect x="0.75" width="60" height="60" rx="4.36364" fill="#FF9500" />
                                        <g clip-path="url(#clip0_2199_449)">
                                            <path
                                                d="M44.7451 33.1779L37.3962 35.053C37.1821 33.8497 36.1283 32.9331 34.8644 32.9331H29.749C29.5109 32.9331 29.2731 32.8763 29.0609 32.7685L25.5548 30.9894C24.4962 30.4523 23.3094 30.1684 22.1226 30.1684H20.078V30.122C20.078 29.2485 19.3674 28.5379 18.4939 28.5379H14.7571C13.8836 28.5379 13.1729 29.2485 13.1729 30.122V41.4678C13.1729 42.3413 13.8836 43.0519 14.7571 43.0519H18.494C19.3675 43.0519 20.078 42.3413 20.078 41.4678V41.3776H20.9903C21.1506 41.3776 21.3074 41.407 21.4564 41.4653L29.7487 44.7012C30.2148 44.8831 30.7013 44.9739 31.1871 44.9739C31.7252 44.9739 32.2624 44.8625 32.7702 44.6404L46.6053 38.5898C48.059 37.9541 48.7212 36.2624 48.0846 34.8082C47.5181 33.5142 46.1143 32.8287 44.7451 33.1779ZM19.3606 41.4679C19.3606 41.9457 18.9717 42.3346 18.4939 42.3346H14.7571C14.2791 42.3346 13.8902 41.9457 13.8902 41.4679V30.1221C13.8902 29.6442 14.2791 29.2554 14.7571 29.2554H18.494C18.9718 29.2554 19.3606 29.6442 19.3606 30.1221V30.5271V41.0189V41.4679H19.3606ZM46.3177 37.9326L32.4827 43.9833C31.6922 44.3293 30.8136 44.3469 30.0096 44.0329L21.7173 40.797C21.4848 40.7063 21.2403 40.6602 20.9903 40.6602H20.078V30.8859H22.1226C23.1972 30.8859 24.2718 31.1429 25.2304 31.6292L28.7363 33.4083C29.0485 33.5668 29.3988 33.6506 29.7491 33.6506H34.8645C35.8843 33.6506 36.7145 34.4783 36.7185 35.4972C36.7184 35.502 36.7184 35.5069 36.7185 35.5117C36.7147 36.5308 35.8846 37.3587 34.8645 37.3587H29.4211C29.2229 37.3587 29.0624 37.5193 29.0624 37.7174C29.0624 37.9156 29.2229 38.0762 29.4211 38.0762H34.8645C36.1869 38.0762 37.2794 37.0727 37.4205 35.7873L44.9226 33.8731C45.9492 33.6106 47.0025 34.1253 47.4276 35.096C47.905 36.1865 47.4086 37.4554 46.3177 37.9326ZM31.4923 18.0017C31.4923 16.3608 30.1575 15.026 28.5167 15.026C26.8758 15.026 25.541 16.3608 25.541 18.0017C25.541 19.6425 26.8758 20.9773 28.5167 20.9773C30.1575 20.9773 31.4923 19.6425 31.4923 18.0017ZM26.2585 18.0017C26.2585 16.7566 27.2716 15.7435 28.5167 15.7435C29.7618 15.7435 30.7748 16.7566 30.7748 18.0017C30.7748 19.2468 29.7618 20.2598 28.5167 20.2598C27.2716 20.2598 26.2585 19.2468 26.2585 18.0017ZM46.5562 27.3079C46.5562 24.2223 44.0467 21.7119 40.9621 21.7119C39.2965 21.7119 37.8029 22.4462 36.7785 23.6053C36.1459 23.3564 35.4597 23.215 34.7398 23.215C34.019 23.215 33.3318 23.3567 32.6984 23.6061C31.6734 22.4476 30.1821 21.7119 28.5176 21.7119C25.432 21.7119 22.9216 24.2223 22.9216 27.3079C22.9216 27.506 23.0822 27.6666 23.2803 27.6666H29.2624C29.1853 28.0362 29.1438 28.4188 29.1438 28.8109C29.1438 29.0091 29.3044 29.1697 29.5026 29.1697H39.9755C40.1736 29.1697 40.3342 29.0091 40.3342 28.8109C40.3342 28.4187 40.2928 28.0362 40.2157 27.6666H46.1977C46.3956 27.6666 46.5562 27.506 46.5562 27.3079ZM23.652 26.9491C23.8363 24.426 25.9481 22.4293 28.5176 22.4293C29.8929 22.4293 31.1338 23.0045 32.0207 23.9241C30.8403 24.5835 29.9264 25.6585 29.469 26.9491H23.652ZM29.8742 28.4522C30.0585 25.929 32.1703 23.9324 34.7397 23.9324C37.3083 23.9324 39.4193 25.9291 39.6036 28.4522H29.8742ZM40.009 26.9491C39.5517 25.6585 38.638 24.5836 37.4581 23.9241C38.3447 23.0042 39.5861 22.4292 40.962 22.4292C43.5304 22.4292 45.6415 24.426 45.8258 26.9491H40.009V26.9491ZM43.9367 18.0017C43.9367 16.3608 42.6019 15.026 40.9611 15.026C39.3204 15.026 37.9856 16.3608 37.9856 18.0017C37.9856 19.6425 39.3204 20.9773 40.9611 20.9773C42.6019 20.9772 43.9367 19.6425 43.9367 18.0017ZM38.703 18.0017C38.703 16.7566 39.716 15.7435 40.9611 15.7435C42.2061 15.7435 43.2192 16.7566 43.2192 18.0017C43.2192 19.2468 42.2061 20.2598 40.9611 20.2598C39.716 20.2598 38.703 19.2468 38.703 18.0017Z"
                                                fill="white" />
                                            <path
                                                d="M34.7388 22.4803C36.3796 22.4803 37.7144 21.1455 37.7144 19.5046C37.7144 17.8638 36.3796 16.529 34.7388 16.529C33.098 16.529 31.7632 17.8638 31.7632 19.5046C31.7632 21.1455 33.098 22.4803 34.7388 22.4803ZM34.7388 17.2465C35.9839 17.2465 36.997 18.2596 36.997 19.5046C36.997 20.7497 35.9839 21.7628 34.7388 21.7628C33.4937 21.7628 32.4807 20.7497 32.4807 19.5046C32.4807 18.2596 33.4937 17.2465 34.7388 17.2465Z"
                                                fill="white" />
                                        </g>
                                        <defs>
                                            <clipPath id="clip0_2199_449">
                                                <rect width="36" height="36" fill="white"
                                                    transform="translate(12.75 12)" />
                                            </clipPath>
                                        </defs>
                                    </svg>

                                </div>
                                <span>Orphans</span>
                            </div>
                        </div>
                    </div>
					<style>
						.my-select{
							display: none !important;
						}
					</style>
                    <!-- Campaign Selection -->
                    <div class="campaign-section">
                        <label class="section-label">Campaigns</label>
                        <div class="campaign-selector">
                            <select id="campaign-select" class="campaign-select">
                                <option value="">Select a campaign</option>
                            </select>
                        </div>
                    </div>

                    <!-- Campaign Fields (Dynamic) -->
                    <div id="campaign-fields" class="campaign-fields">
                        <!-- Dynamic fields will be inserted here -->
                    </div>

                    <!-- Amount Selection -->
                    <div class="amount-section">
                        <h2 class="amount-title">Choose a donation amount</h2>
                        <p class="amount-description">
                            Registered with Fundraising Regulator, we make sure your donation goes directly to
                            supporting our cause.
                        </p>

                        <!-- Predefined Amounts -->
                        <div class="amount-buttons">
                            <button class="amount-btn" data-amount="100">£100</button>
                            <button class="amount-btn" data-amount="50">£50</button>
                            <button class="amount-btn" data-amount="30">£30</button>
                            <button class="amount-btn" data-amount="20">£20</button>
                            <button class="amount-btn" data-amount="10">£10</button>
                            <button class="amount-btn" data-amount="5">£5</button>
                        </div>

                        <!-- Custom Amount Input -->
						
                        <div class="custom-amount-section">
							<div class="backdrop-overlay"></div>
                            <label class="custom-amount-label">Enter a custom donation amount</label>
                            <div class="custom-amount-input">
                                <span class="currency-symbol">£</span>
                                <input type="number" id="custom-amount" placeholder="0" min="0" step="0.01">
                                <select id="currency-select" class="currency-select">
                                    <!-- Currency options will be populated by JavaScript -->
                                </select>
                            </div>
                            <div id="amount-error" class="error-message" style="display: none;"></div>
                        </div>

                        <!-- Exchange Rate Info -->
                        <div id="exchange-rate-info" class="exchange-rate-info" style="display: none;">
                            <p>The current exchange rate is 1.00 GBP equals <span id="exchange-rate-amount"></span>
                                <span id="exchange-rate-currency"></span>.
                            </p>
                        </div>
                    </div>

                    <!-- Multi Donation Section -->
                    <div id="multi-donation-section" class="multi-donation-section" style="display: none;">
                        <div id="multi-donations-list" class="multi-donations-list">
                            <!-- Multi donations will be listed here -->
                        </div>
                        <div class="multi-total">
                            <span>Total: <span id="multi-total-amount"></span></span>
                        </div>
                    </div>

                    <!-- Subscription Frequency (for recurring donations) -->
                    <div id="subscription-frequency" class="subscription-frequency" style="display: none;">
                        <label class="section-label">Frequency</label>
                        <div class="frequency-buttons">
                            <button class="frequency-btn active" data-frequency="weekly">Weekly</button>
                            <button class="frequency-btn" data-frequency="monthly">Monthly</button>
                            <button class="frequency-btn" data-frequency="quarterly">Quarterly</button>
                            <button class="frequency-btn" data-frequency="yearly">Yearly</button>
                        </div>
                    </div>

                    <!-- Cover Fees Option -->
                    <div class="cover-fees-section">
                        <label class="checkbox-label">
                            <input type="checkbox" id="cover-fees">
                            <span class="checkmark"></span>
                            <span class="checkbox-text">
                                I'd like to help cover the transaction fees of <span id="fee-amount">£0.00</span> for my
                                donation(s).
                            </span>
                        </label>
                    </div>

                    <!-- Multi Donation Info -->
                    <div id="multi-info" class="info-section" style="display: none;">
                        <div class="info-icon">ℹ</div>
                        <p>You can add up to 5 campaigns to your donation.</p>
                    </div>

                    <!-- Action Buttons -->
                    <div class="action-buttons">
                        <button id="add-campaign-btn" class="add-campaign-btn" style="display: none;">+ Add
                            campaign</button>
                        <button id="donate-btn" class="donate-btn primary">Donate</button>
                    </div>
                </div>
            </div>

            <!-- Step 2: Personal Details Form -->
            <div id="personal-details-form" class="step-container" style="display: none;">
                <div class="form-card">
                    <h1 class="form-title" id="donation-summary-title">You're making a One-off donation of £20.00</h1>
                    <h2 class="form-subtitle">Enter your personal details</h2>

                    <form id="personal-form">
                        <div class="form-row">
                            <div class="form-group title-group">
								<div class="backdrop-overlay"></div>
                                <select id="title" name="title" class="form-select" required>
                                    <option value="">Title</option>
                                    <option value="Mr.">Mr.</option>
                                    <option value="Mrs.">Mrs.</option>
                                    <option value="Ms.">Ms.</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <input type="text" id="firstName" name="firstName" placeholder="First Name"
                                    class="form-input" required>
                            </div>
                            <div class="form-group">
                                <input type="text" id="lastName" name="lastName" placeholder="Last Name"
                                    class="form-input" required>
                            </div>
                        </div>

                        <div class="checkbox-section">
                            <label class="checkbox-label">
                                <input type="checkbox" id="as-organisation">
                                <span class="checkmark"></span>
                                <span class="checkbox-text"><strong>I am donating on behalf of an
                                        organisation.</strong></span>
                            </label>
                        </div>

                        <div id="organisation-field" class="form-group" style="display: none;">
                            <input type="text" id="company" name="company" placeholder="Organisation Name"
                                class="form-input">
                            <p class="form-note">Gift Aid cannot be claimed on donations made by an organisation.</p>
                        </div>



<!-- <div class="custom-select-container">
  <div class="selected-option" id="selectedOption">Select a country</div>
  <ul class="options-list" id="optionsList">
    
  </ul>
</div> -->






<!--                         <div class="form-row phone-input-email-group">
                            <div class="form-group phone-input-group">
                                <div class="phone-input-container"> -->
<!--                                     <select id="country-code" class="country-code-select"> -->
                                        <!-- Countries will be populated by JavaScript -->
<!--                                     </select> -->
<!-- 		<div id="container"></div>
<p>Selected: <span id="selectedOutput"></span></p> -->

<!--                                     <input type="tel" id="mobile" name="mobile" placeholder="Mobile No"
                                        class="form-input phone-input" required>
                                </div>
                            </div>
                            <div class="form-group">
                                <input type="email" id="email" name="email" placeholder="Email Address"
                                    class="form-input" required>
                            </div>
                        </div> -->




						<div class="form-row phone-input-email-group">
                            <div class="form-group phone-input-group">
                                <div class="phone-input-container">
								 <div class="custom-select-container">
									<div class="selected-option" id="selectedOption">🇮🇳</div>
									<ul class="options-list" id="optionsList"></ul>
								 </div>
                                    <input type="tel" id="mobile" name="mobile" placeholder="Mobile No"
                                        class="form-input phone-input" required>
                                </div>
                            </div>
                            <div class="form-group">
                                <input type="email" id="email" name="email" placeholder="Email Address"
                                    class="form-input" required>
                            </div>
                        </div>


                       <div class="form-group country-group">
    						<div class="backdrop-overlay"></div>
                            <label class="form-label">Country</label>
                            <select id="country" name="country" class="form-select" required>
                                <!-- Countries will be populated by JavaScript -->
                            </select>
                        </div>

                        <!-- Gift Aid Section (UK only) -->
                        <div id="gift-aid-section" class="gift-aid-section" style="display: none;">
                            <div class="gift-aid-info">
                                <img src="<?php echo WPD_PLUGIN_URL; ?>assets/wf-wp-widget-html/assets/images/gift_aid.png" alt="Gift Aid" class="gift-aid-image">
                                <p>If you are a UK taxpayer the value of your gift can increase by 25% at no extra cost
                                    to you!</p>
                            </div>
                            <div class="gift-aid-amount">
                                <span class="current-amount">£20.00</span>
                                <span class="arrow">→</span>
                                <span class="gift-aid-amount">£25.00</span>
                            </div>
                            <label class="checkbox-label">
                                <input type="checkbox" id="gift-aid">
                                <span class="checkmark"></span>
                                <span class="checkbox-text">
                                    <strong>I am a UK taxpayer, donating as an individual and would like The World
                                        Federation to claim Gift Aid on my donation</strong>
                                </span>
                            </label>
                        </div>

                        <!-- Gift Aid Address Fields -->
                        <div id="gift-aid-fields" class="gift-aid-fields" style="display: none;">
                            <p class="gift-aid-note">
                                By clicking the "Yes" box, I agree I would like The World Federation of KSIMC to reclaim
                                the tax on all qualifying donations I have made. I understand that if I pay less Income
                                Tax and/or Capital Gains Tax than the amount of Gift Aid claimed on all my donations in
                                that tax year, I may be asked to pay any difference.
                            </p>
                            <h3 class="address-title">Address details</h3>
                            <div class="form-group">
                                <input type="text" id="addressLine1" name="addressLine1" placeholder="Address Line 1"
                                    class="form-input">
                            </div>
                            <div class="form-group">
                                <input type="text" id="addressLine2" name="addressLine2" placeholder="Address Line 2"
                                    class="form-input">
                            </div>
                            <div class="form-row giftaid-address-row">
                                <div class="form-group">
                                    <input type="text" id="city" name="city" placeholder="City" class="form-input">
                                </div>
                                <div class="form-group">
                                    <input type="text" id="postCode" name="postCode" placeholder="Postcode"
                                        class="form-input">
                                </div>
                            </div>
                        </div>

                        <div class="checkbox-section">
                            <label class="checkbox-label">
                                <input type="checkbox" id="subscribe-newsletter">
                                <span class="checkmark"></span>
                                <span class="checkbox-text"><strong>Subscribe to our newsletter.</strong></span>
                            </label>
                        </div>

                        <div class="action-buttons">
                            <button type="button" id="back-btn" class="back-btn">←</button>
                            <button type="submit" id="continue-btn" class="continue-btn primary">Donate</button>
                        </div>
                    
</form>
                </div>
            </div>

            <!-- Step 3: Payment Form -->
            <div id="payment-form" class="step-container" style="display: none;">
                <div class="form-card">
                    <div class="payment-warning">
<!--                         <span class="warning-icon">⚠</span> -->
                        <span>WF Donate saying it is in the live mode so require actual card details.</span>
                    </div>

                    <form id="stripe-form">
                        <div id="payment-element">
                            <!-- Stripe Elements will be inserted here -->
                        </div>

                        <div class="action-buttons">
                            <button type="button" id="payment-back-btn" class="back-btn">←</button>
                            <button type="submit" id="payment-submit-btn"
                                class="payment-submit-btn primary">Donate</button>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Step 4: Payment Confirmation -->
            <div id="payment-confirmation" class="step-container" style="display: none;">
                <div class="form-card">
                    <div class="confirmation-content">
                        <div class="confirmation-icon">
                            <img src="<?php echo WPD_PLUGIN_URL; ?>assets/wf-wp-widget-html/assets/icons/TWF_logo_Left_KSIMC_Grey.svg" alt="TWF Logo" class="logo">
                        </div>

                        <h1 class="confirmation-title" id="confirmation-title">We appreciate your donation!</h1>

                        <div class="confirmation-details">
                            <div class="detail-row">
                                <strong>Name:</strong>
                                <span id="confirmation-name">John Doe</span>
                            </div>
                            <div class="detail-row">
                                <strong>Email:</strong>
                                <span id="confirmation-email">john@example.com</span>
                            </div>
                            <div class="detail-row">
                                <strong>Campaign Name(s):</strong>
                                <span id="confirmation-campaign">General Donation</span>
                            </div>
                            <div class="detail-row">
                                <strong>Donation type:</strong>
                                <span id="confirmation-type">One-off Donation</span>
                            </div>
                            <div class="detail-row">
                                <strong>Date:</strong>
                                <span id="confirmation-date">Dec 15, 2024</span>
                            </div>
                            <div class="detail-row">
                                <strong>Payment method:</strong>
                                <span id="confirmation-payment-method">Card</span>
                            </div>
                            <div class="detail-row total-row">
                                <strong>Total:</strong>
                                <span id="confirmation-total">£20.00</span>
                            </div>
                        </div>

                        <div class="confirmation-actions">
                            <button id="share-btn" class="share-btn primary">Invite Friends</button>
                            <button id="home-btn" class="home-btn">Back to Homepage</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Share Modal -->
        <div id="share-modal" class="modal" style="display: none;">
            <div class="modal-content">
                <div class="modal-header">
                    <h3>Share this campaign</h3>
                    <button id="close-share-modal" class="close-btn">×</button>
                </div>
                <div class="modal-body">
                    <p>Help us reach more people by sharing this campaign</p>
                    <div class="social-share-buttons">
                        <button class="social-btn whatsapp" data-platform="whatsapp">📱</button>
                        <button class="social-btn facebook" data-platform="facebook">📘</button>
                        <button class="social-btn twitter" data-platform="twitter">🐦</button>
                        <button class="social-btn linkedin" data-platform="linkedin">💼</button>
                        <button class="social-btn email" data-platform="email">📧</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
	
	<script>
		document.addEventListener("DOMContentLoaded", () => {
		  const countries = [
			  { code: "AD", name: "Andorra", dialCode: "+376", flag: "🇦🇩" },
			  {
				code: "AE",
				name: "United Arab Emirates",
				dialCode: "+971",
				flag: "🇦🇪",
			  },
			  { code: "AF", name: "Afghanistan", dialCode: "+93", flag: "🇦🇫" },
			  { code: "AG", name: "Antigua and Barbuda", dialCode: "+1", flag: "🇦🇬" },
			  { code: "AI", name: "Anguilla", dialCode: "+1", flag: "🇦🇮" },
			  { code: "AL", name: "Albania", dialCode: "+355", flag: "🇦🇱" },
			  { code: "AM", name: "Armenia", dialCode: "+374", flag: "🇦🇲" },
			  { code: "AO", name: "Angola", dialCode: "+244", flag: "🇦🇴" },
			  { code: "AR", name: "Argentina", dialCode: "+54", flag: "🇦🇷" },
			  { code: "AS", name: "American Samoa", dialCode: "+1", flag: "🇦🇸" },
			  { code: "AT", name: "Austria", dialCode: "+43", flag: "🇦🇹" },
			  { code: "AU", name: "Australia", dialCode: "+61", flag: "🇦🇺" },
			  { code: "AW", name: "Aruba", dialCode: "+297", flag: "🇦🇼" },
			  { code: "AX", name: "Åland Islands", dialCode: "+358", flag: "🇦🇽" },
			  { code: "AZ", name: "Azerbaijan", dialCode: "+994", flag: "🇦🇿" },
			  {
				code: "BA",
				name: "Bosnia and Herzegovina",
				dialCode: "+387",
				flag: "🇧🇦",
			  },
			  { code: "BB", name: "Barbados", dialCode: "+1", flag: "🇧🇧" },
			  { code: "BD", name: "Bangladesh", dialCode: "+880", flag: "🇧🇩" },
			  { code: "BE", name: "Belgium", dialCode: "+32", flag: "🇧🇪" },
			  { code: "BF", name: "Burkina Faso", dialCode: "+226", flag: "🇧🇫" },
			  { code: "BG", name: "Bulgaria", dialCode: "+359", flag: "🇧🇬" },
			  { code: "BH", name: "Bahrain", dialCode: "+973", flag: "🇧🇭" },
			  { code: "BI", name: "Burundi", dialCode: "+257", flag: "🇧🇮" },
			  { code: "BJ", name: "Benin", dialCode: "+229", flag: "🇧🇯" },
			  { code: "BL", name: "Saint Barthélemy", dialCode: "+590", flag: "🇧🇱" },
			  { code: "BM", name: "Bermuda", dialCode: "+1", flag: "🇧🇲" },
			  { code: "BN", name: "Brunei", dialCode: "+673", flag: "🇧🇳" },
			  { code: "BO", name: "Bolivia", dialCode: "+591", flag: "🇧🇴" },
			  {
				code: "BQ",
				name: "Bonaire, Sint Eustatius and Saba",
				dialCode: "+599",
				flag: "🇧🇶",
			  },
			  { code: "BR", name: "Brazil", dialCode: "+55", flag: "🇧🇷" },
			  { code: "BS", name: "Bahamas", dialCode: "+1", flag: "🇧🇸" },
			  { code: "BT", name: "Bhutan", dialCode: "+975", flag: "🇧🇹" },
			  { code: "BV", name: "Bouvet Island", dialCode: "+47", flag: "🇧🇻" },
			  { code: "BW", name: "Botswana", dialCode: "+267", flag: "🇧🇼" },
			  { code: "BY", name: "Belarus", dialCode: "+375", flag: "🇧🇾" },
			  { code: "BZ", name: "Belize", dialCode: "+501", flag: "🇧🇿" },
			  { code: "CA", name: "Canada", dialCode: "+1", flag: "🇨🇦" },
			  {
				code: "CC",
				name: "Cocos (Keeling) Islands",
				dialCode: "+61",
				flag: "🇨🇨",
			  },
			  { code: "CD", name: "DR Congo", dialCode: "+243", flag: "🇨🇩" },
			  {
				code: "CF",
				name: "Central African Republic",
				dialCode: "+236",
				flag: "🇨🇫",
			  },
			  {
				code: "CG",
				name: "Republic of the Congo",
				dialCode: "+242",
				flag: "🇨🇬",
			  },
			  { code: "CH", name: "Switzerland", dialCode: "+41", flag: "🇨🇭" },
			  { code: "CI", name: "Côte d'Ivoire", dialCode: "+225", flag: "🇨🇮" },
			  { code: "CK", name: "Cook Islands", dialCode: "+682", flag: "🇨🇰" },
			  { code: "CL", name: "Chile", dialCode: "+56", flag: "🇨🇱" },
			  { code: "CM", name: "Cameroon", dialCode: "+237", flag: "🇨🇲" },
			  { code: "CN", name: "China", dialCode: "+86", flag: "🇨🇳" },
			  { code: "CO", name: "Colombia", dialCode: "+57", flag: "🇨🇴" },
			  { code: "CR", name: "Costa Rica", dialCode: "+506", flag: "🇨🇷" },
			  { code: "CU", name: "Cuba", dialCode: "+53", flag: "🇨🇺" },
			  { code: "CV", name: "Cape Verde", dialCode: "+238", flag: "🇨🇻" },
			  { code: "CW", name: "Curaçao", dialCode: "+599", flag: "🇨🇼" },
			  { code: "CX", name: "Christmas Island", dialCode: "+61", flag: "🇨🇽" },
			  { code: "CY", name: "Cyprus", dialCode: "+357", flag: "🇨🇾" },
			  { code: "CZ", name: "Czech Republic", dialCode: "+420", flag: "🇨🇿" },
			  { code: "DE", name: "Germany", dialCode: "+49", flag: "🇩🇪" },
			  { code: "DJ", name: "Djibouti", dialCode: "+253", flag: "🇩🇯" },
			  { code: "DK", name: "Denmark", dialCode: "+45", flag: "🇩🇰" },
			  { code: "DM", name: "Dominica", dialCode: "+1", flag: "🇩🇲" },
			  { code: "DO", name: "Dominican Republic", dialCode: "+1", flag: "🇩🇴" },
			  { code: "DZ", name: "Algeria", dialCode: "+213", flag: "🇩🇿" },
			  { code: "EC", name: "Ecuador", dialCode: "+593", flag: "🇪🇨" },
			  { code: "EE", name: "Estonia", dialCode: "+372", flag: "🇪🇪" },
			  { code: "EG", name: "Egypt", dialCode: "+20", flag: "🇪🇬" },
			  { code: "EH", name: "Western Sahara", dialCode: "+212", flag: "🇪🇭" },
			  { code: "ER", name: "Eritrea", dialCode: "+291", flag: "🇪🇷" },
			  { code: "ES", name: "Spain", dialCode: "+34", flag: "🇪🇸" },
			  { code: "ET", name: "Ethiopia", dialCode: "+251", flag: "🇪🇹" },
			  { code: "FI", name: "Finland", dialCode: "+358", flag: "🇫🇮" },
			  { code: "FJ", name: "Fiji", dialCode: "+679", flag: "🇫🇯" },
			  { code: "FK", name: "Falkland Islands", dialCode: "+500", flag: "🇫🇰" },
			  { code: "FM", name: "Micronesia", dialCode: "+691", flag: "🇫🇲" },
			  { code: "FO", name: "Faroe Islands", dialCode: "+298", flag: "🇫🇴" },
			  { code: "FR", name: "France", dialCode: "+33", flag: "🇫🇷" },
			  { code: "GA", name: "Gabon", dialCode: "+241", flag: "🇬🇦" },
			  { code: "GB", name: "United Kingdom", dialCode: "+44", flag: "🇬🇧" },
			  { code: "GD", name: "Grenada", dialCode: "+1", flag: "🇬🇩" },
			  { code: "GE", name: "Georgia", dialCode: "+995", flag: "🇬🇪" },
			  { code: "GF", name: "French Guiana", dialCode: "+594", flag: "🇬🇫" },
			  { code: "GG", name: "Guernsey", dialCode: "+44", flag: "🇬🇬" },
			  { code: "GH", name: "Ghana", dialCode: "+233", flag: "🇬🇭" },
			  { code: "GI", name: "Gibraltar", dialCode: "+350", flag: "🇬🇮" },
			  { code: "GL", name: "Greenland", dialCode: "+299", flag: "🇬🇱" },
			  { code: "GM", name: "Gambia", dialCode: "+220", flag: "🇬🇲" },
			  { code: "GN", name: "Guinea", dialCode: "+224", flag: "🇬🇳" },
			  { code: "GP", name: "Guadeloupe", dialCode: "+590", flag: "🇬🇵" },
			  { code: "GQ", name: "Equatorial Guinea", dialCode: "+240", flag: "🇬🇶" },
			  { code: "GR", name: "Greece", dialCode: "+30", flag: "🇬🇷" },
			  {
				code: "GS",
				name: "South Georgia and the South Sandwich Islands",
				dialCode: "+500",
				flag: "🇬🇸",
			  },
			  { code: "GT", name: "Guatemala", dialCode: "+502", flag: "🇬🇹" },
			  { code: "GU", name: "Guam", dialCode: "+1", flag: "🇬🇺" },
			  { code: "GW", name: "Guinea-Bissau", dialCode: "+245", flag: "🇬🇼" },
			  { code: "GY", name: "Guyana", dialCode: "+592", flag: "🇬🇾" },
			  { code: "HK", name: "Hong Kong", dialCode: "+852", flag: "🇭🇰" },
			  {
				code: "HM",
				name: "Heard Island and McDonald Islands",
				dialCode: "+672",
				flag: "🇭🇲",
			  },
			  { code: "HN", name: "Honduras", dialCode: "+504", flag: "🇭🇳" },
			  { code: "HR", name: "Croatia", dialCode: "+385", flag: "🇭🇷" },
			  { code: "HT", name: "Haiti", dialCode: "+509", flag: "🇭🇹" },
			  { code: "HU", name: "Hungary", dialCode: "+36", flag: "🇭🇺" },
			  { code: "ID", name: "Indonesia", dialCode: "+62", flag: "🇮🇩" },
			  { code: "IE", name: "Ireland", dialCode: "+353", flag: "🇮🇪" },
			  { code: "IL", name: "Israel", dialCode: "+972", flag: "🇮🇱" },
			  { code: "IM", name: "Isle of Man", dialCode: "+44", flag: "🇮🇲" },
			  { code: "IN", name: "India", dialCode: "+91", flag: "🇮🇳" },
			  {
				code: "IO",
				name: "British Indian Ocean Territory",
				dialCode: "+246",
				flag: "🇮🇴",
			  },
			  { code: "IQ", name: "Iraq", dialCode: "+964", flag: "🇮🇶" },
			  { code: "IR", name: "Iran", dialCode: "+98", flag: "🇮🇷" },
			  { code: "IS", name: "Iceland", dialCode: "+354", flag: "🇮🇸" },
			  { code: "IT", name: "Italy", dialCode: "+39", flag: "🇮🇹" },
			  { code: "JE", name: "Jersey", dialCode: "+44", flag: "🇯🇪" },
			  { code: "JM", name: "Jamaica", dialCode: "+1", flag: "🇯🇲" },
			  { code: "JO", name: "Jordan", dialCode: "+962", flag: "🇯🇴" },
			  { code: "JP", name: "Japan", dialCode: "+81", flag: "🇯🇵" },
			  { code: "KE", name: "Kenya", dialCode: "+254", flag: "🇰🇪" },
			  { code: "KG", name: "Kyrgyzstan", dialCode: "+996", flag: "🇰🇬" },
			  { code: "KH", name: "Cambodia", dialCode: "+855", flag: "🇰🇭" },
			  { code: "KI", name: "Kiribati", dialCode: "+686", flag: "🇰🇮" },
			  { code: "KM", name: "Comoros", dialCode: "+269", flag: "🇰🇲" },
			  { code: "KN", name: "Saint Kitts and Nevis", dialCode: "+1", flag: "🇰🇳" },
			  { code: "KP", name: "North Korea", dialCode: "+850", flag: "🇰🇵" },
			  { code: "KR", name: "South Korea", dialCode: "+82", flag: "🇰🇷" },
			  { code: "KW", name: "Kuwait", dialCode: "+965", flag: "🇰🇼" },
			  { code: "KY", name: "Cayman Islands", dialCode: "+1", flag: "🇰🇾" },
			  { code: "KZ", name: "Kazakhstan", dialCode: "+7", flag: "🇰🇿" },
			  { code: "LA", name: "Laos", dialCode: "+856", flag: "🇱🇦" },
			  { code: "LB", name: "Lebanon", dialCode: "+961", flag: "🇱🇧" },
			  { code: "LC", name: "Saint Lucia", dialCode: "+1", flag: "🇱🇨" },
			  { code: "LI", name: "Liechtenstein", dialCode: "+423", flag: "🇱🇮" },
			  { code: "LK", name: "Sri Lanka", dialCode: "+94", flag: "🇱🇰" },
			  { code: "LR", name: "Liberia", dialCode: "+231", flag: "🇱🇷" },
			  { code: "LS", name: "Lesotho", dialCode: "+266", flag: "🇱🇸" },
			  { code: "LT", name: "Lithuania", dialCode: "+370", flag: "🇱🇹" },
			  { code: "LU", name: "Luxembourg", dialCode: "+352", flag: "🇱🇺" },
			  { code: "LV", name: "Latvia", dialCode: "+371", flag: "🇱🇻" },
			  { code: "LY", name: "Libya", dialCode: "+218", flag: "🇱🇾" },
			  { code: "MA", name: "Morocco", dialCode: "+212", flag: "🇲🇦" },
			  { code: "MC", name: "Monaco", dialCode: "+377", flag: "🇲🇨" },
			  { code: "MD", name: "Moldova", dialCode: "+373", flag: "🇲🇩" },
			  { code: "ME", name: "Montenegro", dialCode: "+382", flag: "🇲🇪" },
			  { code: "MF", name: "Saint Martin", dialCode: "+590", flag: "🇲🇫" },
			  { code: "MG", name: "Madagascar", dialCode: "+261", flag: "🇲🇬" },
			  { code: "MH", name: "Marshall Islands", dialCode: "+692", flag: "🇲🇭" },
			  { code: "MK", name: "North Macedonia", dialCode: "+389", flag: "🇲🇰" },
			  { code: "ML", name: "Mali", dialCode: "+223", flag: "🇲🇱" },
			  { code: "MM", name: "Myanmar", dialCode: "+95", flag: "🇲🇲" },
			  { code: "MN", name: "Mongolia", dialCode: "+976", flag: "🇲🇳" },
			  { code: "MO", name: "Macau", dialCode: "+853", flag: "🇲🇴" },
			  {
				code: "MP",
				name: "Northern Mariana Islands",
				dialCode: "+1",
				flag: "🇲🇵",
			  },
			  { code: "MQ", name: "Martinique", dialCode: "+596", flag: "🇲🇶" },
			  { code: "MR", name: "Mauritania", dialCode: "+222", flag: "🇲🇷" },
			  { code: "MS", name: "Montserrat", dialCode: "+1", flag: "🇲🇸" },
			  { code: "MT", name: "Malta", dialCode: "+356", flag: "🇲🇹" },
			  { code: "MU", name: "Mauritius", dialCode: "+230", flag: "🇲🇺" },
			  { code: "MV", name: "Maldives", dialCode: "+960", flag: "🇲🇻" },
			  { code: "MW", name: "Malawi", dialCode: "+265", flag: "🇲🇼" },
			  { code: "MX", name: "Mexico", dialCode: "+52", flag: "🇲🇽" },
			  { code: "MY", name: "Malaysia", dialCode: "+60", flag: "🇲🇾" },
			  { code: "MZ", name: "Mozambique", dialCode: "+258", flag: "🇲🇿" },
			  { code: "NA", name: "Namibia", dialCode: "+264", flag: "🇳🇦" },
			  { code: "NC", name: "New Caledonia", dialCode: "+687", flag: "🇳🇨" },
			  { code: "NE", name: "Niger", dialCode: "+227", flag: "🇳🇪" },
			  { code: "NF", name: "Norfolk Island", dialCode: "+672", flag: "🇳🇫" },
			  { code: "NG", name: "Nigeria", dialCode: "+234", flag: "🇳🇬" },
			  { code: "NI", name: "Nicaragua", dialCode: "+505", flag: "🇳🇮" },
			  { code: "NL", name: "Netherlands", dialCode: "+31", flag: "🇳🇱" },
			  { code: "NO", name: "Norway", dialCode: "+47", flag: "🇳🇴" },
			  { code: "NP", name: "Nepal", dialCode: "+977", flag: "🇳🇵" },
			  { code: "NR", name: "Nauru", dialCode: "+674", flag: "🇳🇷" },
			  { code: "NU", name: "Niue", dialCode: "+683", flag: "🇳🇺" },
			  { code: "NZ", name: "New Zealand", dialCode: "+64", flag: "🇳🇿" },
			  { code: "OM", name: "Oman", dialCode: "+968", flag: "🇴🇲" },
			  { code: "PA", name: "Panama", dialCode: "+507", flag: "🇵🇦" },
			  { code: "PE", name: "Peru", dialCode: "+51", flag: "🇵🇪" },
			  { code: "PF", name: "French Polynesia", dialCode: "+689", flag: "🇵🇫" },
			  { code: "PG", name: "Papua New Guinea", dialCode: "+675", flag: "🇵🇬" },
			  { code: "PH", name: "Philippines", dialCode: "+63", flag: "🇵🇭" },
			  { code: "PK", name: "Pakistan", dialCode: "+92", flag: "🇵🇰" },
			  { code: "PL", name: "Poland", dialCode: "+48", flag: "🇵🇱" },
			  {
				code: "PM",
				name: "Saint Pierre and Miquelon",
				dialCode: "+508",
				flag: "🇵🇲",
			  },
			  { code: "PN", name: "Pitcairn Islands", dialCode: "+64", flag: "🇵🇳" },
			  { code: "PR", name: "Puerto Rico", dialCode: "+1", flag: "🇵🇷" },
			  { code: "PS", name: "Palestine", dialCode: "+970", flag: "🇵🇸" },
			  { code: "PT", name: "Portugal", dialCode: "+351", flag: "🇵🇹" },
			  { code: "PW", name: "Palau", dialCode: "+680", flag: "🇵🇼" },
			  { code: "PY", name: "Paraguay", dialCode: "+595", flag: "🇵🇾" },
			  { code: "QA", name: "Qatar", dialCode: "+974", flag: "🇶🇦" },
			  { code: "RE", name: "Réunion", dialCode: "+262", flag: "🇷🇪" },
			  { code: "RO", name: "Romania", dialCode: "+40", flag: "🇷🇴" },
			  { code: "RS", name: "Serbia", dialCode: "+381", flag: "🇷🇸" },
			  { code: "RU", name: "Russia", dialCode: "+7", flag: "🇷🇺" },
			  { code: "RW", name: "Rwanda", dialCode: "+250", flag: "🇷🇼" },
			  { code: "SA", name: "Saudi Arabia", dialCode: "+966", flag: "🇸🇦" },
			  { code: "SB", name: "Solomon Islands", dialCode: "+677", flag: "🇸🇧" },
			  { code: "SC", name: "Seychelles", dialCode: "+248", flag: "🇸🇨" },
			  { code: "SD", name: "Sudan", dialCode: "+249", flag: "🇸🇩" },
			  { code: "SE", name: "Sweden", dialCode: "+46", flag: "🇸🇪" },
			  { code: "SG", name: "Singapore", dialCode: "+65", flag: "🇸🇬" },
			  { code: "SH", name: "Saint Helena", dialCode: "+290", flag: "🇸🇭" },
			  { code: "SI", name: "Slovenia", dialCode: "+386", flag: "🇸🇮" },
			  {
				code: "SJ",
				name: "Svalbard and Jan Mayen",
				dialCode: "+47",
				flag: "🇸🇯",
			  },
			  { code: "SK", name: "Slovakia", dialCode: "+421", flag: "🇸🇰" },
			  { code: "SL", name: "Sierra Leone", dialCode: "+232", flag: "🇸🇱" },
			  { code: "SM", name: "San Marino", dialCode: "+378", flag: "🇸🇲" },
			  { code: "SN", name: "Senegal", dialCode: "+221", flag: "🇸🇳" },
			  { code: "SO", name: "Somalia", dialCode: "+252", flag: "🇸🇴" },
			  { code: "SR", name: "Suriname", dialCode: "+597", flag: "🇸🇷" },
			  { code: "SS", name: "South Sudan", dialCode: "+211", flag: "🇸🇸" },
			  {
				code: "ST",
				name: "São Tomé and Príncipe",
				dialCode: "+239",
				flag: "🇸🇹",
			  },
			  { code: "SV", name: "El Salvador", dialCode: "+503", flag: "🇸🇻" },
			  { code: "SX", name: "Sint Maarten", dialCode: "+1", flag: "🇸🇽" },
			  { code: "SY", name: "Syria", dialCode: "+963", flag: "🇸🇾" },
			  { code: "SZ", name: "Eswatini", dialCode: "+268", flag: "🇸🇿" },
			  {
				code: "TC",
				name: "Turks and Caicos Islands",
				dialCode: "+1",
				flag: "🇹🇨",
			  },
			  { code: "TD", name: "Chad", dialCode: "+235", flag: "🇹🇩" },
			  {
				code: "TF",
				name: "French Southern and Antarctic Lands",
				dialCode: "+262",
				flag: "🇹🇫",
			  },
			  { code: "TG", name: "Togo", dialCode: "+228", flag: "🇹🇬" },
			  { code: "TH", name: "Thailand", dialCode: "+66", flag: "🇹🇭" },
			  { code: "TJ", name: "Tajikistan", dialCode: "+992", flag: "🇹🇯" },
			  { code: "TK", name: "Tokelau", dialCode: "+690", flag: "🇹🇰" },
			  { code: "TL", name: "East Timor", dialCode: "+670", flag: "🇹🇱" },
			  { code: "TM", name: "Turkmenistan", dialCode: "+993", flag: "🇹🇲" },
			  { code: "TN", name: "Tunisia", dialCode: "+216", flag: "🇹🇳" },
			  { code: "TO", name: "Tonga", dialCode: "+676", flag: "🇹🇴" },
			  { code: "TR", name: "Turkey", dialCode: "+90", flag: "🇹🇷" },
			  { code: "TT", name: "Trinidad and Tobago", dialCode: "+1", flag: "🇹🇹" },
			  { code: "TV", name: "Tuvalu", dialCode: "+688", flag: "🇹🇻" },
			  { code: "TW", name: "Taiwan", dialCode: "+886", flag: "🇹🇼" },
			  { code: "TZ", name: "Tanzania", dialCode: "+255", flag: "🇹🇿" },
			  { code: "UA", name: "Ukraine", dialCode: "+380", flag: "🇺🇦" },
			  { code: "UG", name: "Uganda", dialCode: "+256", flag: "🇺🇬" },
			  {
				code: "UM",
				name: "United States Minor Outlying Islands",
				dialCode: "+1",
				flag: "🇺🇲",
			  },
			  { code: "US", name: "United States", dialCode: "+1", flag: "🇺🇸" },
			  { code: "UY", name: "Uruguay", dialCode: "+598", flag: "🇺🇾" },
			  { code: "UZ", name: "Uzbekistan", dialCode: "+998", flag: "🇺🇿" },
			  { code: "VA", name: "Vatican City", dialCode: "+39", flag: "🇻🇦" },
			  {
				code: "VC",
				name: "Saint Vincent and the Grenadines",
				dialCode: "+1",
				flag: "🇻🇨",
			  },
			  { code: "VE", name: "Venezuela", dialCode: "+58", flag: "🇻🇪" },
			  {
				code: "VG",
				name: "British Virgin Islands",
				dialCode: "+1",
				flag: "🇻🇬",
			  },
			  { code: "VI", name: "U.S. Virgin Islands", dialCode: "+1", flag: "🇻🇮" },
			  { code: "VN", name: "Vietnam", dialCode: "+84", flag: "🇻🇳" },
			  { code: "VU", name: "Vanuatu", dialCode: "+678", flag: "🇻🇺" },
			  { code: "WF", name: "Wallis and Futuna", dialCode: "+681", flag: "🇼🇫" },
			  { code: "WS", name: "Samoa", dialCode: "+685", flag: "🇼🇸" },
			  { code: "YE", name: "Yemen", dialCode: "+967", flag: "🇾🇪" },
			  { code: "YT", name: "Mayotte", dialCode: "+262", flag: "🇾🇹" },
			  { code: "ZA", name: "South Africa", dialCode: "+27", flag: "🇿🇦" },
			  { code: "ZM", name: "Zambia", dialCode: "+260", flag: "🇿🇲" },
			  { code: "ZW", name: "Zimbabwe", dialCode: "+263", flag: "🇿🇼" },
			];
		  const optionsList = document.getElementById("optionsList");
		  const selectedOption = document.getElementById("selectedOption");
		  const mobileInput = document.getElementById("mobile");

		  let currentDialCode = "+91"; // default

		const getFlagImage = (emoji) => {
			const codePoints = [...emoji].map(ch => ch.codePointAt(0).toString(16));
			return `https://s.w.org/images/core/emoji/16.0.1/svg/${codePoints.join("-")}.svg`;
		  };

		  const setDialCode = (country) => {
			currentDialCode = country.dialCode;
			mobileInput.value = currentDialCode;
			selectedOption.innerHTML = `<img draggable="false" role="img" class="emoji" 
				alt="${country.flag}" 
				src="${getFlagImage(country.flag)}">`;
			mobileInput.focus();
			mobileInput.setSelectionRange(currentDialCode.length, currentDialCode.length);
		  };

		  // Populate dropdown
		  countries.forEach(country => {
			const li = document.createElement("li");
			li.textContent = `${country.flag} ${country.name} (${country.dialCode})`;
			li.classList.add("option-item");

			li.addEventListener("click", () => {
			  setDialCode(country);
			  optionsList.style.display = "none";
			});

			optionsList.appendChild(li);
		  });

		 // Toggle dropdown
  selectedOption.addEventListener("click", () => {
    optionsList.style.display = optionsList.style.display === "block" ? "none" : "block";
  });

  // Hide dropdown on outside click
  document.addEventListener("click", (e) => {
    if (!e.target.closest(".custom-select-container")) {
      optionsList.style.display = "none";
    }
  });

	
  // Prevent deleting dial code
  mobileInput.addEventListener("keydown", (e) => {
    const cursorPos = mobileInput.selectionStart;
    if ((e.key === "Backspace" && cursorPos <= currentDialCode.length) ||
        (e.key === "Delete" && cursorPos < currentDialCode.length)) {
      e.preventDefault();
    }
  });

  // Keep dial code on input change
  mobileInput.addEventListener("input", () => {
    if (!mobileInput.value.startsWith(currentDialCode)) {
      mobileInput.value = currentDialCode + mobileInput.value.slice(currentDialCode.length);
    }
  });

  // Cursor always after dial code on focus
  mobileInput.addEventListener("focus", () => {
    if (mobileInput.selectionStart < currentDialCode.length) {
      mobileInput.setSelectionRange(currentDialCode.length, currentDialCode.length);
    }
  });

  // Initialize with India
  const defaultCountry = countries.find(c => c.code === "IN");
  setDialCode(defaultCountry);
		});




     document.addEventListener("DOMContentLoaded", function () {
      const select = document.getElementById("country");

   const countries = [
      { value: "AF", label: "Afghanistan" },
      { value: "AL", label: "Albania" },
      { value: "DZ", label: "Algeria" },
      { value: "AS", label: "American Samoa" },
      { value: "AD", label: "Andorra" },
      { value: "AO", label: "Angola" },
      { value: "AI", label: "Anguilla" },
      { value: "AQ", label: "Antarctica" },
      { value: "AG", label: "Antigua and Barbuda" },
      { value: "AR", label: "Argentina" },
      { value: "AM", label: "Armenia" },
      { value: "AW", label: "Aruba" },
      { value: "AU", label: "Australia" },
      { value: "AT", label: "Austria" },
      { value: "AZ", label: "Azerbaijan" },
      { value: "BS", label: "Bahamas" },
      { value: "BH", label: "Bahrain" },
      { value: "BD", label: "Bangladesh" },
      { value: "BB", label: "Barbados" },
      { value: "BY", label: "Belarus" },
      { value: "BE", label: "Belgium" },
      { value: "BZ", label: "Belize" },
      { value: "BJ", label: "Benin" },
      { value: "BM", label: "Bermuda" },
      { value: "BT", label: "Bhutan" },
      { value: "BO", label: "Bolivia" },
      { value: "BA", label: "Bosnia and Herzegovina" },
      { value: "BW", label: "Botswana" },
      { value: "BV", label: "Bouvet Island" },
      { value: "BR", label: "Brazil" },
      { value: "IO", label: "British Indian Ocean Territory" },
      { value: "BN", label: "Brunei Darussalam" },
      { value: "BG", label: "Bulgaria" },
      { value: "BF", label: "Burkina Faso" },
      { value: "BI", label: "Burundi" },
      { value: "KH", label: "Cambodia" },
      { value: "CM", label: "Cameroon" },
      { value: "CA", label: "Canada" },
      { value: "CV", label: "Cape Verde" },
      { value: "KY", label: "Cayman Islands" },
      { value: "CF", label: "Central African Republic" },
      { value: "TD", label: "Chad" },
      { value: "CL", label: "Chile" },
      { value: "CN", label: "China" },
      { value: "CX", label: "Christmas Island" },
      { value: "CC", label: "Cocos (Keeling) Islands" },
      { value: "CO", label: "Colombia" },
      { value: "KM", label: "Comoros" },
      { value: "CG", label: "Congo" },
      { value: "CD", label: "Congo, Democratic Republic of the" },
      { value: "CK", label: "Cook Islands" },
      { value: "CR", label: "Costa Rica" },
      { value: "CI", label: "Côte d'Ivoire" },
      { value: "HR", label: "Croatia" },
      { value: "CU", label: "Cuba" },
      { value: "CY", label: "Cyprus" },
      { value: "CZ", label: "Czech Republic" },
      { value: "DK", label: "Denmark" },
      { value: "DJ", label: "Djibouti" },
      { value: "DM", label: "Dominica" },
      { value: "DO", label: "Dominican Republic" },
      { value: "EC", label: "Ecuador" },
      { value: "EG", label: "Egypt" },
      { value: "SV", label: "El Salvador" },
      { value: "GQ", label: "Equatorial Guinea" },
      { value: "ER", label: "Eritrea" },
      { value: "EE", label: "Estonia" },
      { value: "ET", label: "Ethiopia" },
      { value: "FK", label: "Falkland Islands (Malvinas)" },
      { value: "FO", label: "Faroe Islands" },
      { value: "FJ", label: "Fiji" },
      { value: "FI", label: "Finland" },
      { value: "FR", label: "France" },
      { value: "GF", label: "French Guiana" },
      { value: "PF", label: "French Polynesia" },
      { value: "TF", label: "French Southern Territories" },
      { value: "GA", label: "Gabon" },
      { value: "GM", label: "Gambia" },
      { value: "GE", label: "Georgia" },
      { value: "DE", label: "Germany" },
      { value: "GH", label: "Ghana" },
      { value: "GI", label: "Gibraltar" },
      { value: "GR", label: "Greece" },
      { value: "GL", label: "Greenland" },
      { value: "GD", label: "Grenada" },
      { value: "GP", label: "Guadeloupe" },
      { value: "GU", label: "Guam" },
      { value: "GT", label: "Guatemala" },
      { value: "GG", label: "Guernsey" },
      { value: "GN", label: "Guinea" },
      { value: "GW", label: "Guinea-Bissau" },
      { value: "GY", label: "Guyana" },
      { value: "HT", label: "Haiti" },
      { value: "HM", label: "Heard Island and McDonald Islands" },
      { value: "VA", label: "Holy See (Vatican City State)" },
      { value: "HN", label: "Honduras" },
      { value: "HK", label: "Hong Kong" },
      { value: "HU", label: "Hungary" },
      { value: "IS", label: "Iceland" },
      { value: "IN", label: "India" },
      { value: "ID", label: "Indonesia" },
      { value: "IR", label: "Iran, Islamic Republic of" },
      { value: "IQ", label: "Iraq" },
      { value: "IE", label: "Ireland" },
      { value: "IM", label: "Isle of Man" },
      { value: "IL", label: "Israel" },
      { value: "IT", label: "Italy" },
      { value: "JM", label: "Jamaica" },
      { value: "JP", label: "Japan" },
      { value: "JE", label: "Jersey" },
      { value: "JO", label: "Jordan" },
      { value: "KZ", label: "Kazakhstan" },
      { value: "KE", label: "Kenya" },
      { value: "KI", label: "Kiribati" },
      { value: "KP", label: "Korea, Democratic People's Republic of" },
      { value: "KR", label: "Korea, Republic of" },
      { value: "KW", label: "Kuwait" },
      { value: "KG", label: "Kyrgyzstan" },
      { value: "LA", label: "Lao People's Democratic Republic" },
      { value: "LV", label: "Latvia" },
      { value: "LB", label: "Lebanon" },
      { value: "LS", label: "Lesotho" },
      { value: "LR", label: "Liberia" },
      { value: "LY", label: "Libya" },
      { value: "LI", label: "Liechtenstein" },
      { value: "LT", label: "Lithuania" },
      { value: "LU", label: "Luxembourg" },
      { value: "MO", label: "Macao" },
      { value: "MK", label: "Macedonia, the former Yugoslav Republic of" },
      { value: "MG", label: "Madagascar" },
      { value: "MW", label: "Malawi" },
      { value: "MY", label: "Malaysia" },
      { value: "MV", label: "Maldives" },
      { value: "ML", label: "Mali" },
      { value: "MT", label: "Malta" },
      { value: "MH", label: "Marshall Islands" },
      { value: "MQ", label: "Martinique" },
      { value: "MR", label: "Mauritania" },
      { value: "MU", label: "Mauritius" },
      { value: "YT", label: "Mayotte" },
      { value: "MX", label: "Mexico" },
      { value: "FM", label: "Micronesia, Federated States of" },
      { value: "MD", label: "Moldova, Republic of" },
      { value: "MC", label: "Monaco" },
      { value: "MN", label: "Mongolia" },
      { value: "ME", label: "Montenegro" },
      { value: "MS", label: "Montserrat" },
      { value: "MA", label: "Morocco" },
      { value: "MZ", label: "Mozambique" },
      { value: "MM", label: "Myanmar" },
      { value: "NA", label: "Namibia" },
      { value: "NR", label: "Nauru" },
      { value: "NP", label: "Nepal" },
      { value: "NL", label: "Netherlands" },
      { value: "NC", label: "New Caledonia" },
      { value: "NZ", label: "New Zealand" },
      { value: "NI", label: "Nicaragua" },
      { value: "NE", label: "Niger" },
      { value: "NG", label: "Nigeria" },
      { value: "NU", label: "Niue" },
      { value: "NF", label: "Norfolk Island" },
      { value: "MP", label: "Northern Mariana Islands" },
      { value: "NO", label: "Norway" },
      { value: "OM", label: "Oman" },
      { value: "PK", label: "Pakistan" },
      { value: "PW", label: "Palau" },
      { value: "PS", label: "Palestinian Territory, Occupied" },
      { value: "PA", label: "Panama" },
      { value: "PG", label: "Papua New Guinea" },
      { value: "PY", label: "Paraguay" },
      { value: "PE", label: "Peru" },
      { value: "PH", label: "Philippines" },
      { value: "PN", label: "Pitcairn" },
      { value: "PL", label: "Poland" },
      { value: "PT", label: "Portugal" },
      { value: "PR", label: "Puerto Rico" },
      { value: "QA", label: "Qatar" },
      { value: "RE", label: "Réunion" },
      { value: "RO", label: "Romania" },
      { value: "RU", label: "Russian Federation" },
      { value: "RW", label: "Rwanda" },
      { value: "BL", label: "Saint Barthélemy" },
      { value: "SH", label: "Saint Helena, Ascension and Tristan da Cunha" },
      { value: "KN", label: "Saint Kitts and Nevis" },
      { value: "LC", label: "Saint Lucia" },
      { value: "MF", label: "Saint Martin (French part)" },
      { value: "PM", label: "Saint Pierre and Miquelon" },
      { value: "VC", label: "Saint Vincent and the Grenadines" },
      { value: "WS", label: "Samoa" },
      { value: "SM", label: "San Marino" },
      { value: "ST", label: "Sao Tome and Principe" },
      { value: "SA", label: "Saudi Arabia" },
      { value: "SN", label: "Senegal" },
      { value: "RS", label: "Serbia" },
      { value: "SC", label: "Seychelles" },
      { value: "SL", label: "Sierra Leone" },
      { value: "SG", label: "Singapore" },
      { value: "SX", label: "Sint Maarten (Dutch part)" },
      { value: "SK", label: "Slovakia" },
      { value: "SI", label: "Slovenia" },
      { value: "SB", label: "Solomon Islands" },
      { value: "SO", label: "Somalia" },
      { value: "ZA", label: "South Africa" },
      { value: "GS", label: "South Georgia and the South Sandwich Islands" },
      { value: "SS", label: "South Sudan" },
      { value: "ES", label: "Spain" },
      { value: "LK", label: "Sri Lanka" },
      { value: "SD", label: "Sudan" },
      { value: "SR", label: "Suriname" },
      { value: "SJ", label: "Svalbard and Jan Mayen" },
      { value: "SZ", label: "Swaziland" },
      { value: "SE", label: "Sweden" },
      { value: "CH", label: "Switzerland" },
      { value: "SY", label: "Syrian Arab Republic" },
      { value: "TW", label: "Taiwan, Province of China" },
      { value: "TJ", label: "Tajikistan" },
      { value: "TZ", label: "Tanzania, United Republic of" },
      { value: "TH", label: "Thailand" },
      { value: "TL", label: "Timor-Leste" },
      { value: "TG", label: "Togo" },
      { value: "TK", label: "Tokelau" },
      { value: "TO", label: "Tonga" },
      { value: "TT", label: "Trinidad and Tobago" },
      { value: "TN", label: "Tunisia" },
      { value: "TR", label: "Turkey" },
      { value: "TM", label: "Turkmenistan" },
      { value: "TC", label: "Turks and Caicos Islands" },
      { value: "TV", label: "Tuvalu" },
      { value: "UG", label: "Uganda" },
      { value: "UA", label: "Ukraine" },
      { value: "AE", label: "United Arab Emirates" },
      { value: "GB", label: "United Kingdom" },
      { value: "US", label: "United States" },
      { value: "UM", label: "United States Minor Outlying Islands" },
      { value: "UY", label: "Uruguay" },
      { value: "UZ", label: "Uzbekistan" },
      { value: "VU", label: "Vanuatu" },
      { value: "VE", label: "Venezuela, Bolivarian Republic of" },
      { value: "VN", label: "Viet Nam" },
      { value: "VG", label: "Virgin Islands, British" },
      { value: "VI", label: "Virgin Islands, U.S." },
      { value: "WF", label: "Wallis and Futuna" },
      { value: "EH", label: "Western Sahara" },
      { value: "YE", label: "Yemen" },
      { value: "ZM", label: "Zambia" },
      { value: "ZW", label: "Zimbabwe" },
    ];

  countries.sort((a, b) => a.label.localeCompare(b.label));

      // Clear and populate
      select.innerHTML = "";
      countries.forEach(country => {
        const option = document.createElement("option");
        option.value = country.value;
        option.textContent = country.label;
        select.appendChild(option);
      });

      // Default: UK
      select.value = "GB";
    });
	</script>
    <script src="<?php echo WPD_PLUGIN_URL; ?>assets/wf-wp-widget-html/js/app.js"></script>
    <script src="<?php echo WPD_PLUGIN_URL; ?>assets/wf-wp-widget-html/js/api.js"></script>
    <script src="<?php echo WPD_PLUGIN_URL; ?>assets/wf-wp-widget-html/js/validation.js"></script>
    <script src="<?php echo WPD_PLUGIN_URL; ?>assets/wf-wp-widget-html/js/stripe.js"></script>
